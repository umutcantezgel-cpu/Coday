# Handoff Report: `__dirname` ESM error in Playwright a11y audit

## 1. Observation
- The file `/Users/umurey/agency-domination/e2e/a11y-audit/a11y.spec.ts` uses `__dirname` on line 17:
  `const reportsDir = path.join(__dirname, 'reports');`
- The project `package.json` specifies `"type": "module"` (line 5), which causes Node.js (and thereby tools like Playwright configured to run TypeScript files directly) to execute this code as an ES Module (ESM).
- In ESM, the global variables `__dirname` and `__filename` are undefined, resulting in a ReferenceError when the test script is run.
- The milestone document `.agents/sub_orch_m3/SCOPE.md` correctly indicates the required fix: "Replace `__dirname` with `dirname(fileURLToPath(import.meta.url))` in `e2e/a11y-audit/a11y.spec.ts`".

## 2. Logic Chain
1. Since the project uses ESM (`"type": "module"`), we must use standard ESM replacements for CommonJS directory variables.
2. The Node.js native way to get the current file directory in ESM is to import `fileURLToPath` from the `url` module, get the file path via `import.meta.url`, and pass that to `path.dirname()`.
3. The current imports in `a11y.spec.ts` are:
   ```typescript
   import { test, expect } from '@playwright/test';
   import AxeBuilder from '@axe-core/playwright';
   import * as fs from 'fs';
   import * as path from 'path';
   ```
4. To fix the issue, we need to add the `fileURLToPath` import and update line 17 to use it.

## 3. Caveats
- No caveats. This is a standard and direct fix for Node ESM environment errors regarding `__dirname`. 
- Assumes that `a11y.config.ts` (the playwright config for this suite) is also ESM compatible, but since the scope specifically isolates `a11y.spec.ts`, we stick to modifying just that file.

## 4. Conclusion
The `__dirname` ReferenceError is confirmed to be caused by the project's `"type": "module"` setting. The implementer should modify `/Users/umurey/agency-domination/e2e/a11y-audit/a11y.spec.ts` to replace `__dirname` with the ESM equivalent.

**Proposed Changes:**

1. **Add import:**
```typescript
import { fileURLToPath } from 'url';
```

2. **Replace line 17:**
From:
```typescript
const reportsDir = path.join(__dirname, 'reports');
```
To:
```typescript
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const reportsDir = path.join(__dirname, 'reports');
```
*(Alternatively, it can be combined into a single line: `const reportsDir = path.join(path.dirname(fileURLToPath(import.meta.url)), 'reports');`)*

## 5. Verification Method
1. Run the test command for this suite: `npm run test:a11y`
2. It should successfully compile and execute without throwing `ReferenceError: __dirname is not defined`.
3. Check the `e2e/a11y-audit/reports` directory to ensure JSON reports are created properly.
