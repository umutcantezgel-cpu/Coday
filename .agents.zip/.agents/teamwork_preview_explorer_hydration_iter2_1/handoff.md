# Handoff Report: Hydration Fixes Iteration 2

## 1. Observation
- **CRITICAL INTEGRITY VIOLATION**: Running `npm run typecheck` and `npx tsc --noEmit` yields widespread `TS2345: Argument of type 'string' is not assignable to parameter of type 'Record<string, string | number | Date>'`. This occurs because `next-intl`'s `t(key, variables)` function does not accept string fallbacks as its second argument, but a regex replacement mistakenly injected them (e.g., `t('sections.templates.title', 'The Vault')` in `TemplateVault.tsx` line 24, and `InProgressSection.tsx` line 26).
- **Syntax Errors**: In `src/widgets/home/HeroSection.tsx`, `npx tsc --noEmit` fails at lines 153-158 with `TS1003: Identifier expected` and `TS1381: Unexpected token`. The regex created invalid props like `ctaText={t('buttons.contact', { ns: 'common', defaultValue: t('buttons.view_work', { ns: 'common' }) })}`. `useTranslations(['home', 'common'])` is also invalid for `next-intl`.
- **Undeclared variables/Imports**: `src/widgets/navigation/LanguageSwitcher.tsx` line 17 refers to `currentLang` which is undefined. `src/shared/lib/formatService.ts` attempts to import `i18n` from `@/i18n` which does not exist, and uses an undefined `locale` variable.
- **Tailwind Purge Bug**: In `src/widgets/home/ServicesSection.tsx` at line 92: `className={"text-3xl ${service.color.replace('bg-', 'text-')}"}`. Dynamic string interpolation hides the `text-*` classes from Tailwind's scanner, causing them to be purged.
- **GlobalErrorBoundary**: In `src/shared/GlobalErrorBoundary.tsx` at line 42, `navigator.language.startsWith('de')` is called without ensuring `navigator.language` is defined, risking a crash.

## 2. Logic Chain
1. To fix `TS2345` in all affected files (`InProgressSection.tsx`, `TemplateVault.tsx`, `WorkHero.tsx`, `StickyCTA.tsx`, `CookieSettingsModal.tsx`, `PortfolioTeaserSection.tsx`, etc.), the string fallbacks must be removed so the calls become `t('key')`.
2. To fix `HeroSection.tsx`, `useTranslations` must be split: `const t = useTranslations('home');` and `const tCommon = useTranslations('common');`. The `ctaText` should simply use `tCommon('buttons.contact')` instead of the broken nested object/fallback structure.
3. To fix `LanguageSwitcher.tsx`, `currentLang` should be evaluated correctly, for example: `const currentLang = locale as 'de' | 'en';`.
4. To fix `formatService.ts`, since it's practically dead code or unused, removing the `@/i18n` import and returning `'de-DE'` natively resolves the compiler errors.
5. To fix the Tailwind purge bug in `ServicesSection.tsx`, provide explicit text classes statically (e.g., passing `iconColor: 'text-emerald-500'` in the array), or define a mapping object `const colorMap: Record<string, string> = { 'bg-emerald-500': 'text-emerald-500', ... }` inside the component.
6. To fix the ErrorBoundary bug, the check should be defensive: `navigator.language?.startsWith('de')`.

## 3. Caveats
- I did not fix the files myself, as my role is strictly read-only investigation.
- I assumed `FormatService` is unused based on a grep search, so a minimal patch is recommended to satisfy the compiler without refactoring its logic.
- The list of files with `TS2345` is quite long (found in typecheck output). The implementer will need to apply the fallback removal across all of them (mostly in `src/widgets/` and `src/features/`).

## 4. Conclusion
The implementation team should execute a series of targeted `replace_file_content` or `multi_replace_file_content` calls to fix the invalid `t()` calls, correct the syntax errors in `HeroSection.tsx`, fix the broken variable in `LanguageSwitcher.tsx`, correct the Tailwind dynamic string in `ServicesSection.tsx`, and add optional chaining in `GlobalErrorBoundary.tsx`.

## 5. Verification Method
- Run `npm run typecheck` to ensure no `TS2345` or `TS1003` errors remain.
- Run `npx eslint src` to ensure no unresolved imports.
- Run `npm run build` to verify the Tailwind classes are compiled correctly and the Next.js build completes successfully without syntax errors.
