# Iteration 4 Investigation & Fix Strategy

## 1. Observation
- **`vite-plugin-image-optimizer` ENOENT**: The Vite build fails trying to optimize `coday-icon.svg` inside `build/client/images/brand`. `vite.config.ts` currently only excludes `\.(webp|avif)$`.
- **`copyfile` MP4 error**: Vercel preset (`vercelPreset`) in React Router v7 fails during build with an error copying `Die_Ultimative_SEO_Strategie.mp4`. The file is 25MB (`public/videos/academy/Die_Ultimative_SEO_Strategie.mp4`).
- **`generate-images.js` try-catch**: The script `scripts/generate-images.js` fails on corrupted/invalid images (like `00-bad-image.png`). The `try/catch` block only surrounds the `fs.stat` check, but the actual `sharp(...).toFile()` calls (lines 37 and 51) are exposed and crash the process if Sharp encounters an unreadable file.
- **`MetaBalls.tsx` Safari & INP**: 
  - `MetaBalls.tsx` uses an SVG `<filter id="goo">` housed in an `<svg className="absolute hidden">` tag. The Tailwind `hidden` class maps to `display: none`, causing Safari/Firefox to ignore the filter definitions entirely.
  - The gooey filter is applied to a full-screen `inset-0` container with multiple continuously animating child divs. SVG `feColorMatrix` and `feGaussianBlur` filters on large, continuously changing DOM elements force massive main-thread re-rasterization on every frame, killing INP and FPS.

## 2. Logic Chain
1. **SVG Optimizer Crash**: The Vite builder likely moves or deletes `coday-icon.svg` during a late build phase (e.g. React Router static generation), causing a race condition with `ViteImageOptimizer`. Excluding `.svg` from the optimizer resolves this, as SVGs are usually already optimized and vector-based anyway.
2. **MP4 Build Choke**: The `vercelPreset` uses `fs.copyFileSync` under the hood to move the `public/` folder to the `.vercel/output/static` directory. 25MB+ video files often cause memory spikes, timeouts, or hit Vercel's static asset limits. Removing large media from the build pipeline and serving them externally is the standard architectural fix.
3. **Sharp Generation Crash**: Sharp throws a hard error when processing an invalid buffer/file. Wrapping the `await sharp(...)` conversion calls in their own `try/catch` will allow the script to log the error and continue processing the rest of the valid images.
4. **MetaBalls Compatibility & Performance**: 
   - Safari needs the SVG definition to be visually hidden but still strictly part of the render tree (not `display: none`).
   - For INP: CSS/SVG filters on animating DOM elements are fundamentally slow. Porting the animation to HTML5 `<canvas>` (2D or WebGL) isolates the animation from the DOM, running it efficiently without layout thrashing or massive main-thread repaints. Alternatively, substituting the `feColorMatrix` with a simpler CSS `blur()` fallback removes the CPU bottleneck.

## 3. Conclusion (Proposed Fix Strategy)
I recommend the following concrete implementation steps:
1. **Fix Vite Image Optimizer**: In `vite.config.ts`, update `ViteImageOptimizer`'s exclude regex to `exclude: /\.(webp|avif|svg)$/i`.
2. **Fix MP4 Vercel Build**: Remove the large MP4 files from `public/videos/academy/`. Update `src/shared/data/academy.ts` to replace local `/videos/...` paths with external CDN URLs or YouTube IDs. (If external hosting is impossible right now, add them to Vite's `publicDir` ignore list or `.vercelignore` to bypass the copy step).
3. **Fix Image Generator**: In `scripts/generate-images.js`, wrap `sharp(filePath).webp(...)` and `sharp(filePath).avif(...)` in `try { ... } catch (e) { console.warn(...) }` blocks.
4. **Fix MetaBalls**: 
   - Change the `<svg>` container in `src/shared/ui/MetaBalls.tsx` from `className="absolute hidden"` to `style={{ position: 'absolute', width: 0, height: 0, pointerEvents: 'none' }}`.
   - **For INP**: Refactor `MetaBalls.tsx` to render the floating orbs on a `<canvas>` element using `requestAnimationFrame`, or remove the `filter: 'url(#goo)'` and use standard CSS `filter: blur(15px)` on the individual balls to achieve a performant soft-orb aesthetic without the `feColorMatrix` CPU cost.

## 4. Caveats
- Moving the MP4 to an external CDN means updating the UI component (e.g., Academy page) to handle external links or iframes instead of a native `<video src="/...">` tag.
- Replacing the gooey effect with CSS `blur()` will change the visual style slightly (balls won't "stick" together as much), but it guarantees 60fps. If the exact gooey effect is strictly required, a Canvas implementation is mandatory but will take more effort to implement.

## 5. Verification Method
1. Run `npm run build` to verify the `coday-icon.svg` ENOENT error is gone and the `copyfile` MP4 error does not block the build.
2. Run `node scripts/generate-images.js` to ensure it completes successfully without crashing, even if a dummy bad image (`echo "bad" > public/00-bad-image.png`) is present.
3. Open the app in Safari to verify the `MetaBalls` effect is visible. Profile with Chrome DevTools Performance tab to ensure INP/Main Thread blocking time is reduced during the animation.
