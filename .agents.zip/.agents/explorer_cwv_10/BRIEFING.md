# BRIEFING — 2026-05-23T10:56:00Z

## Mission
Analyze the codebase and propose a strategy to achieve LCP < 1.5s, CLS < 0.1, and optimized INP by fixing specific Vite, generation, and UI performance issues.

## 🔒 My Identity
- Archetype: Explorer
- Roles: Read-only investigation, Code analysis, Strategy formulation
- Working directory: /Users/umurey/agency-domination/.agents/explorer_cwv_10
- Original parent: 3a8af03b-ff34-43e0-bbfb-67a537702fa8
- Milestone: Core Web Vitals Optimization (Iteration 4)

## 🔒 Key Constraints
- Read-only investigation — do NOT implement
- Analyze build and performance issues, propose architectural and code-level fixes

## Current Parent
- Conversation ID: 3a8af03b-ff34-43e0-bbfb-67a537702fa8
- Updated: 2026-05-23T10:56:00Z

## Investigation State
- **Explored paths**: `vite.config.ts`, `react-router.config.ts`, `scripts/generate-images.js`, `src/shared/ui/MetaBalls.tsx`, `src/shared/data/academy.ts`
- **Key findings**: 
  1. Vite plugin crash caused by missing `svg` exclusion.
  2. Large MP4s (25MB) choking Vercel preset copy.
  3. `generate-images.js` lacks `try/catch` around `sharp().toFile()`.
  4. `MetaBalls.tsx` uses Tailwind `hidden` breaking Safari SVG filters, and SVG filters on large animating elements destroy INP.
- **Unexplored areas**: Implementation of the Canvas alternative for MetaBalls (left to implementer).

## Key Decisions Made
- Proposed removing/excluding large MP4s in favor of CDNs.
- Proposed updating Vite optimizer to ignore `.svg`.
- Proposed fixing try-catch in the image generator script.
- Proposed refactoring `MetaBalls.tsx` to `<canvas>` or basic CSS blur to save main-thread performance.

## Artifact Index
- `/Users/umurey/agency-domination/.agents/explorer_cwv_10/handoff.md` — Final investigation report and proposed fix strategy
