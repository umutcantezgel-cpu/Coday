# Scope: Milestone 1: i18n & Hydration

## Architecture
- Replace `useTranslation` from `react-i18next` with `useTranslations` from `next-intl`.
- Ensure next-intl works with Server/Client components.
- Fix hydration mismatches & missing text caused by react-i18next in Next.js 15.

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| 1 | i18n & Hydration | Migrate react-i18next client usages to next-intl to fix hydration & missing text | none | DONE |
