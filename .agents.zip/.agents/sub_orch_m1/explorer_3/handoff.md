# Next-intl Migration Strategy

## Observation
1. **Current `react-i18next` usage**: Over 100 files in `src/` import `react-i18next`. 99 files use `useTranslation()`, and 74 files use the `<Trans>` component.
2. **Current `next-intl` configuration**: `src/i18n/request.ts`, `src/i18n/routing.ts`, and `src/i18n/navigation.ts` exist. However, `next.config.ts` and `src/middleware.ts` do not yet use `next-intl`.
3. **App routing structure**: `src/app/` currently contains `page.tsx`, `layout.tsx`, etc., directly. It does not use `[locale]/` routing.
4. **Translations loading**: `react-i18next` relies on `public/locales/[lng]/[ns].json` and an invalid `import.meta.glob` call in `src/i18n.server.ts`. Meanwhile, `src/i18n/request.ts` imports `../../messages/${locale}.json`.

## Logic Chain
1. **Move App Routes**: The project rule mandates "Routes in `app/[locale]/...` with `next-intl`". All UI routes (`page.tsx`, `layout.tsx`, `/privacy`, `/branchen`, etc.) must be moved inside `src/app/[locale]/`. Metadata files (`robots.ts`, `sitemap.ts`, `manifest.ts`) usually stay at the root.
2. **Setup Next-Intl Configuration**:
   - Update `next.config.ts`:
     ```ts
     import createNextIntlPlugin from 'next-intl/plugin';
     const withNextIntl = createNextIntlPlugin('./src/i18n/request.ts');
     // wrap nextConfig with withNextIntl(nextConfig)
     ```
   - Update `src/middleware.ts` to wrap its existing response logic with `createMiddleware`:
     ```ts
     import createMiddleware from 'next-intl/middleware';
     import { routing } from './i18n/routing';
     const intlMiddleware = createMiddleware(routing);
     
     export default function middleware(request: NextRequest) {
       const response = intlMiddleware(request);
       // ... apply A/B test cookies and VERCEL_ENV staging headers to `response`
       return response;
     }
     ```
3. **Provide Translations to the App**:
   - `src/app/[locale]/layout.tsx` must read the `locale` parameter and pass messages to `<NextIntlClientProvider messages={messages}>` which wraps `{children}`.
   - We must consolidate `public/locales/[lng]/[ns].json` into `messages/de.json` and `messages/en.json` (or write a script to merge them), so `request.ts` can load all translations.
4. **Codebase Migration for Hooks**:
   - Convert `import { useTranslation } from 'react-i18next'` to `import { useTranslations } from 'next-intl'`.
   - Update `const { t } = useTranslation('ns')` to `const t = useTranslations('ns')`.
5. **Codebase Migration for `<Trans>` Component**:
   - Replace `<Trans i18nKey="my.key" components={{ b: <b /> }} />` with `t.rich('my.key', { b: (chunks) => <b>{chunks}</b> })`.
6. **Cleanup**: Remove `react-i18next`, `i18next`, and `i18next-http-backend` from `package.json`. Delete `src/i18n.ts` and `src/i18n.server.ts`.

## Caveats
- There are nearly 100 components to migrate. This should be done via a careful find-and-replace or specialized script to prevent regressions.
- `t.rich()` API expects render functions `(chunks) => ReactNode` instead of static components like `react-i18next`'s `<Trans>`. This must be manually adjusted for each `<Trans>` usage.
- Links and Routers must be migrated to the customized wrappers exported from `src/i18n/navigation.ts` (`Link`, `useRouter`, `usePathname`, `redirect`).

## Conclusion
The application requires a structural shift of its `src/app` directory to `src/app/[locale]`, wrapping the Next.js config and Middleware with `next-intl`, merging the translation namespaces, and executing a codebase-wide replacement of the `useTranslation` hook and `<Trans>` component.

## Verification Method
1. `npm run typecheck` and `npm run lint` must exit with 0 to ensure no lingering `react-i18next` types or broken imports exist.
2. Verify translations on the local server (`npm run dev`) by visiting `/` (which should default to `/de`) and `/en`. 
3. Verify that the previous `NO_I18NEXT_INSTANCE` error in the server logs disappears.
