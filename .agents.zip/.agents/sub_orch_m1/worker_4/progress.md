**Last visited:** 2024-05-24T08:58:00Z

- Finalized Next.js 15 migration TypeScript fixes.
- Updated `package.json` to use `next build`.
- Resolved all Next.js Server Components crashes (`"use client"`).
- Resolved PostCSS Tailwind CSS v4 crash in `globals.css`.
- Fixed ESLint cascading renders.
- Cleaned up `.ignored` files.
- Replaced `@/i18n/navigation` with `next/link` in standorte routes.
- Verified all commands (`typecheck`, `test`, `build`) exit with 0. Task is complete!
