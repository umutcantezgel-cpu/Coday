# Handoff Report: Milestone 1, Iteration 2 (Explorer)

## 1. Observation
- **`SkipLink.test.tsx`**: The file at `src/shared/__tests__/SkipLink.test.tsx` (lines 7-12) still mocks `react-i18next`. However, `src/shared/ui/SkipLink.tsx` was already migrated to import `useTranslations` and `useLocale` from `next-intl`.
- **`LanguageLayout.tsx`**: Running `grep_search` for `LanguageLayout` across `src/` yields only hits inside its own file (`src/widgets/layout/LanguageLayout.tsx`). It is not imported by any other layout, page, or component.
- **Lint warnings**: Running `npm run lint` yields 159 warnings. The vast majority of these are `@typescript-eslint/no-unused-vars` complaining that `'useLocale' is defined but never used` or `'useTranslations' is defined but never used`.

## 2. Logic Chain
- **Issue 1 (SkipLink Test)**: The test renders `<SkipLink />` and expects it to output the German label when the language is 'de'. Since `SkipLink` relies on `useLocale()` from `next-intl`, we must mock `next-intl` instead of `react-i18next` and return `'de'` by default to satisfy the current test assertions.
- **Issue 2 (LanguageLayout Dead Code)**: Because there are zero external references to `LanguageLayout.tsx` in the entire codebase, it is unreferenced legacy code and perfectly safe to delete.
- **Issue 3 (Unused Variables Lint)**: A bulk search-and-replace during the migration clearly inserted `useLocale` and `useTranslations` imports across many files without checking if they were actually used. The `@typescript-eslint/no-unused-vars` rule is **not** natively auto-fixable using standard `eslint --fix` without additional plugins (like `eslint-plugin-unused-imports`). Therefore, a simple `eslint --fix` will not resolve these warnings.

## 3. Caveats
- No caveats. The issues are self-contained and the lint errors strictly involve unused declarations which do not affect runtime behavior.

## 4. Conclusion
1. **Fix `SkipLink.test.tsx`**: Replace the `react-i18next` mock with:
   ```typescript
   vi.mock('next-intl', () => ({
     useLocale: () => 'de',
     useTranslations: () => (key: string) => key,
   }));
   ```
2. **Remove `LanguageLayout.tsx`**: Delete `src/widgets/layout/LanguageLayout.tsx` entirely.
3. **Resolve Lint Warnings**: Instruct the implementer to use the `cleanup-dead-imports` skill to systematically purge the unused variables and imports, as `eslint --fix` will not automatically strip them. Alternatively, they can use AST tools or targeted regex replacements for the specific unused `next-intl` hooks.

## 5. Verification Method
- Run `npm run test` -> should pass with no `SkipLink` failures.
- Run `npm run lint` -> should report 0 warnings.
- Run `npm run build` -> should succeed, confirming that `LanguageLayout.tsx` wasn't implicitly needed.
