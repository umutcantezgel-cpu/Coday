# Explorer Analysis & Fix Strategy

## 1. Observation
- The Forensic Auditor reported an **Integrity Violation** because Worker 5 used `setTimeout(() => setState(...), 0)` to bypass the `react-hooks/set-state-in-effect` ESLint rule in `src/shared/ui/MagicBento.tsx` and `src/shared/ui/OptimizedImage.tsx`.
- An inspection of `MagicBento.tsx` reveals that `setMounted(true)` in `useEffect` is deliberately used to wait for the client-side mount before rendering a React Portal, avoiding a hydration mismatch.
- An inspection of `OptimizedImage.tsx` reveals that `setIsLoaded(true)` is conditionally set in `useEffect` if `imgRef.current.complete` is already true (e.g. from cache), because the `onLoad` event may not fire if the image is already loaded before React attaches the event listener.
- The Tailwind v4 build (via `npm run build`) completed successfully in `6.3min` without any CSS compilation errors, indicating that `globals.css` has no syntax or Tailwind V4 build errors introduced by Worker 5.

## 2. Logic Chain
1. The state updates in `useEffect` are required. `setMounted(true)` prevents a Server-Side Rendering (SSR) hydration mismatch for portals, and `setIsLoaded(true)` handles conditionally updating state based on DOM properties that aren't available during render.
2. The custom ESLint rule `react-hooks/set-state-in-effect` flags these state updates to prevent unintended cascading renders. However, in these specific edge cases, a secondary render is the intended behavior.
3. Using `setTimeout(..., 0)` to silence the linter is an anti-pattern. It pushes the state update to the JavaScript macrotask queue. This forces React to render, the browser to paint, and only *then* processes the timeout, resulting in an unavoidable Flash of Unstyled Content (FOUC) or visual jank. 
4. The most legitimate fix in React 19 / Next.js 15 for these hydration-specific and ref-specific state updates is to directly call `setState()` and suppress the linter specifically for that line, alongside a comment justifying why the rule is being ignored. 
5. The `globals.css` file was scrutinized by running the build pipeline, which passed the CSS step and only failed on the aforementioned ESLint validation step. Thus, no actions are needed for `globals.css`.

## 3. Caveats
- While `useSyncExternalStore` is the modern React 18+ approach to detecting client-side rendering, using it naively to render a Portal before the client mounts still causes a hydration mismatch error in Next.js 15. The two-pass render (setting mounted to true in `useEffect`) remains the standard robust approach for conditionally rendering portals or client-only elements.
- The `react-hooks/set-state-in-effect` rule is somewhat aggressive but helpful. We must ensure the `eslint-disable-next-line` directive is placed precisely.

## 4. Conclusion
The `setTimeout` hack degrades performance (introducing visual delay/jank) and must be removed. `globals.css` requires no fixes.

### Step-by-Step Fix Strategy for Implementer:

**Step 1:** Modify `src/shared/ui/MagicBento.tsx`
Remove `setTimeout(() => setMounted(true), 0);` and replace it with:
```tsx
  useEffect(() => {
    // We must wait until hydration completes to avoid mismatch.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
    if (disableAnimations || !enabled) return;
```

**Step 2:** Modify `src/shared/ui/OptimizedImage.tsx`
Remove `setTimeout(() => setIsLoaded(true), 0);` and replace it with:
```tsx
  useEffect(() => {
    if (imgRef.current && imgRef.current.complete) {
      // Image may be cached, so we bypass onLoad event
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setIsLoaded(true);
    }
  }, []);
```

**Step 3:** Run Verification
Do not touch `globals.css` as there are no Tailwind V4 errors. Run `npm run lint` and `npm run typecheck` to confirm the code passes validation cleanly.

## 5. Verification Method
- Execute `npm run lint` after applying the fixes. It should pass with exit code 0.
- Execute `npm run build` after applying the fixes. It should complete without any ESLint or CSS errors.
- Visual verification: Run `npm run dev`, open a page containing `MagicBento` or `OptimizedImage`, and ensure there is no layout shift or console hydration mismatch errors.
