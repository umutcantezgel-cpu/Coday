# Observation

1. **react-i18next footprint**: I found `useTranslation` imported from `react-i18next` in ~25 files (e.g., `ServicesSection.tsx`, `HeroSection.tsx`, `useFormat.ts`, `useRtl.ts`, `LanguageLayout.tsx`, `<Trans>` component in `MobileSimulator.tsx`).
2. **Translation Storage**: `react-i18next` translations are stored in `public/locales/[lng]/*.json` (e.g., 21 files for `de` namespace: `home.json`, `common.json`, `services.json`, etc. totaling ~200KB).
3. **next-intl footprint**: `next-intl` is installed (`v4.12.0`). I found `src/i18n/request.ts` and `src/i18n/routing.ts` configured, but:
   - `next.config.ts` lacks the `withNextIntl` plugin.
   - `src/middleware.ts` does not use `createMiddleware(routing)`.
   - `src/app/layout.tsx` lacks `NextIntlClientProvider`.
   - The App Router structure lacks a `[locale]` root folder (pages exist directly under `src/app/`).
4. **Hydration Issue**: `src/i18n.ts` expects `window.initialI18nStore` to be injected by SSR for hydration. However, `RootLayout` (`src/app/layout.tsx`) does not inject this script. Thus, client components hydrate with empty translations, causing the "missing text" and hydration mismatches.
5. **next-intl messages**: Currently, `request.ts` imports a single file `../../messages/${locale}.json`, which is tiny (~700 bytes) and only contains limited keys (like `nav`, `footer`).

# Logic Chain

1. **The root cause of missing text**: `react-i18next` requires SSR injection of the translation store to hydrate correctly in Next.js. Because this isn't happening (and `getStaticProps` is gone in App Router), `react-i18next` wipes translations on the client.
2. **next-intl architecture**: `next-intl` is better suited for RSCs because it passes translations down via React Context without manual script injection. However, it's not fully wired up.
3. **Namespace resolution**: To migrate without rewriting all 21 translation files into a single `messages/de.json`, `request.ts` can statically import and compose the existing `public/locales` JSONs into a deeply nested `messages` object. This maps perfectly to how `next-intl` namespaces work.
4. **Component Migration**: 
   - `const { t } = useTranslation(['home', 'common'])` resolves `home` as the default namespace, allowing inline overrides like `t('key', { ns: 'common' })`.
   - `next-intl` handles this by initializing separate hooks: `const tHome = useTranslations('home'); const tCommon = useTranslations('common');`.
   - For language and direction features in `useFormat` and `useRtl`, `useLocale` from `next-intl` provides the necessary context.
5. **App Router Routing**: For `next-intl` middleware to automatically handle URLs like `/de/services` vs `/en/services`, the app requires moving pages into `src/app/[locale]/`.

# Caveats

- **App Router Restructuring**: I noticed all routes (like `page.tsx`, `privacy/`, `standorte/`) are currently at `src/app/`. To use `next-intl` localized routing, these **must** be moved into a `src/app/[locale]/` directory. The migration strategy below assumes you will perform this move, otherwise localized routing middleware will 404 or misdirect.
- **`<Trans>` Component**: Used in `MobileSimulator.tsx`. `next-intl` uses `t.rich()` instead of a wrapper component. The JSON strings may need to be updated to use `<0>` or named tags (e.g., `<blue>`) to match `next-intl` formatting.
- **LanguageLayout**: `src/widgets/layout/LanguageLayout.tsx` appears to be a leftover from a previous routing structure (it exports a `loader` function). This file can be safely deleted as Next.js middleware + layout handles this now.

# Conclusion

To fix the hydration and missing text issues, we must complete the `next-intl` setup and replace `react-i18next` usages. We will dynamically build the `next-intl` messages object from the existing `public/locales` files to avoid massive file rewrites. 

### Step-by-Step Fix Strategy

**1. Complete next-intl Wiring**
- **`next.config.ts`**: Wrap the export with `const withNextIntl = require('next-intl/plugin')('./src/i18n/request.ts'); export default withNextIntl(nextConfig);`
- **`src/middleware.ts`**: Export `createMiddleware(routing)` from `next-intl/middleware` (combining your existing logic or forwarding it).
- **`src/app/layout.tsx`**: Fetch `await getMessages()` and wrap `children` in `<NextIntlClientProvider messages={messages}>`.
- **Restructure App**: Move `page.tsx` and all route folders into `src/app/[locale]/`. Move the root `layout.tsx` into `[locale]/` as well to receive the `params.locale`.

**2. Consolidate Translations in `request.ts`**
Modify `src/i18n/request.ts` to statically import your existing split JSON files so `next-intl` can read them:
```typescript
const messages = {
  ...(await import(`../../messages/${locale}.json`)).default,
  home: (await import(`../../public/locales/${locale}/home.json`)).default,
  common: (await import(`../../public/locales/${locale}/common.json`)).default,
  // Add remaining namespaces...
};
return { locale, messages };
```

**3. Migrate Client Components**
- **Hooks**: Replace `useTranslation(['ns1', 'ns2'])` with `const t1 = useTranslations('ns1'); const t2 = useTranslations('ns2');`.
- **Inline Overrides**: Replace `t('key', { ns: 'common' })` with `tCommon('key')`.
- **Default Values**: Drop `{ defaultValue: '...' }` (already present in your JSONs).
- **Locale Data**: In `useFormat.ts` and `useRtl.ts`, replace `const { i18n } = useTranslation();` with `import { useLocale } from 'next-intl'; const locale = useLocale();`. For RTL check, use `locale === 'ar' || locale === 'he'`.
- **Rich Text**: Replace `<Trans i18nKey="blog:key" components={{span: <span/>}} />` with `tBlog.rich('key', { span: (chunks) => <span>{chunks}</span> })`.

**4. Cleanup**
Delete `src/i18n.ts`, `LanguageLayout.tsx`, and uninstall `react-i18next` and `i18next`.

# Verification Method

1. **Build check**: Run `npm run typecheck` and `npm run build`. The build will fail if any `useTranslations` hooks are used outside of `NextIntlClientProvider` or point to missing keys.
2. **Visual test**: Start `npm run dev`. Navigate to `/de` and `/en`. Ensure the Hero section and CTA buttons render localized text immediately (no flash of empty text).
3. **Hydration check**: Open Chrome DevTools Console. There should be NO Next.js hydration mismatch errors regarding text nodes (e.g., "Text content did not match. Server: 'Startseite' Client: ''").
