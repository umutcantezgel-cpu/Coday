# Handoff Report

## Observation
1. Running `grep -rl "react-i18next" src/ | wc -l` revealed **101 files** still importing `react-i18next` (mostly `useTranslation`).
2. There are legacy files `src/i18n.ts` and `src/i18n.server.ts` configuring `i18next`, while `src/i18n/request.ts` is configured for `next-intl`.
3. Neither `next.config.ts` nor `src/middleware.ts` uses the `next-intl` plugin or middleware.
4. There is no `NextIntlClientProvider` in `src/app/layout.tsx` or any layout, meaning Client Components do not receive `next-intl` messages.
5. In addition to `useTranslation`, `BookingCalendar.tsx` and `MobileSimulator.tsx` use the `<Trans>` component.
6. The `i18n.language` property is used for locale conditionals (e.g. `i18n.language === 'en' ? 'en-US' : 'de-DE'`).
7. Files like `src/features/analyzer/model/store.ts` use the `TFunction` type imported from `i18next`.

## Logic Chain
- The application is mid-migration from `react-i18next` to `next-intl`. Server components correctly removed `react-i18next`, which disabled the `I18nextProvider`. This causes `useTranslation` in client components to fail with `NO_I18NEXT_INSTANCE`, resulting in hydration mismatches because the client renders raw keys (e.g. `buttons.start_project`) while the server rendered the correct translation.
- To resolve this:
  - `next.config.ts` must use `createNextIntlPlugin` to register the `next-intl` request config.
  - `NextIntlClientProvider` must wrap children in `src/app/layout.tsx` to pass messages to Client Components.
  - All 101 usages of `useTranslation` must be replaced with `useTranslations` (note the 's') from `next-intl`.
  - usages of `react-i18next`'s `<Trans>` must be rewritten using `next-intl`'s `t.rich()` function.
  - usages of `i18n.language` must be replaced with `useLocale()` from `next-intl`.
  - Type definitions referencing `TFunction` should be swapped to `any` or `ReturnType<typeof useTranslations>`.

## Caveats
- I did not verify if the JSON translation files (`messages/*.json`) need format changes, though `next-intl` is compatible with standard nested JSON.
- Test suites (`vitest` and `playwright`) may contain mocks for `react-i18next` (e.g. `vi.mock('react-i18next', ...)` in `SeoHead.test.tsx`) that will need to be updated to mock `next-intl` instead.
- This investigation assumes no dynamic routing segments (e.g., `[locale]`) are currently being utilized, based on the `src/app/` folder structure.

## Conclusion
A step-by-step fix strategy to migrate these usages safely:

1. **Configure Plugin**: Update `next.config.ts` to wrap `nextConfig` with `createNextIntlPlugin('./src/i18n/request.ts')`.
2. **Add Provider**: In `src/app/layout.tsx`, import `NextIntlClientProvider` and `getMessages` from `next-intl/server`. Wrap `{children}` with `<NextIntlClientProvider messages={messages}>`.
3. **Refactor Hooks**: In the 101 client components:
   - Change `import { useTranslation } from 'react-i18next';` to `import { useTranslations } from 'next-intl';`
   - Change `const { t } = useTranslation('ns');` to `const t = useTranslations('ns');`
4. **Refactor Utilities**:
   - Replace `<Trans />` with `t.rich('key', { tags })`.
   - Replace `const { i18n } = useTranslation()` with `const locale = useLocale()` and replace `i18n.language` with `locale`.
   - Replace `import type { TFunction } from 'i18next'` with type inference or `any`.
5. **Clean up**: Delete `src/i18n.ts`, `src/i18n.server.ts`, and remove `react-i18next` & `i18next` dependencies from `package.json`.

## Verification Method
1. **Lint/Typecheck**: Run `npm run typecheck` and `npm run lint` to ensure no `react-i18next` imports remain.
2. **Dev Server Visual Check**: Start `npm run dev`, open the browser console, and verify the `NO_I18NEXT_INSTANCE` error is gone.
3. **Build Check**: Run `npm run build` and ensure Next.js reports no hydration mismatch warnings in the build output.
4. **Test Run**: Check `npm run test:run` to ensure all tests pass and components render strings correctly.
