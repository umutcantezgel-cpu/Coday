import subprocess
import time
import urllib.request
import re
import os
import signal
import sys

def verify():
    # Start dev server
    print("Starting dev server...")
    process = subprocess.Popen(
        ["npm", "run", "dev"],
        cwd="/Users/umurey/agency-domination",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    
    server_ready = False
    for _ in range(30):
        try:
            req = urllib.request.Request('http://localhost:3000/en')
            with urllib.request.urlopen(req) as response:
                if response.status == 200:
                    server_ready = True
                    print("Server is up and running!")
                    break
        except Exception as e:
            pass
        time.sleep(1)
        
    if not server_ready:
        print("Dev server failed to start or crashed.")
        process.terminate()
        sys.exit(1)
        
    # Fetch homepage
    try:
        req = urllib.request.Request('http://localhost:3000/en')
        with urllib.request.urlopen(req) as response:
            html = response.read().decode('utf-8')
    except Exception as e:
        print(f"Failed to fetch homepage: {e}")
        process.terminate()
        sys.exit(1)
        
    # Check for translation keys
    failed = False
    
    # Let's see if we find raw keys like 'nav.home' or 'home.hero.title'
    raw_keys_to_check = ['nav.home', 'home.hero.title', 'home.hero.subtitle', 'footer.company']
    for key in raw_keys_to_check:
        if key in html:
            print(f"FAILED: Found raw translation key in HTML: {key}")
            failed = True
            
    # Let's see if we find the actual translated text
    expected_texts = [
        "Home", 
        "AI-Augmented Web Development", 
        "High-end websites with React, TypeScript, and Headless CMS.",
        "Coday · Sole Proprietorship"
    ]
    
    for text in expected_texts:
        if text not in html:
            print(f"FAILED: Expected translated text not found in HTML: {text}")
            failed = True
            
    if not failed:
        print("SUCCESS: Translated texts found and no raw keys detected.")
        
    process.terminate()
    process.wait()
    
    if failed:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    verify()
