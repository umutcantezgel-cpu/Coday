# Handoff: Iteration 1 Issue Analysis

## Observation
1. Running `npm run test -- src/shared/__tests__/SkipLink.test.tsx` fails with `Error: No intl context found`. The test file still contains `vi.mock('react-i18next', ...)` while the component (`SkipLink.tsx`) was migrated to `next-intl` and uses `useLocale()`.
2. A full project search using `grep` confirms `LanguageLayout.tsx` is completely unused. No files in `src/` import or reference it.
3. Running `npm run lint` outputs 159 warnings. The vast majority of these are `@typescript-eslint/no-unused-vars` complaining about unused `useLocale` and `useTranslations` imports, as well as some other unused UI imports (e.g. `Link`, `cn` in `HeroSection.tsx`).

## Logic Chain
1. **SkipLink Test**: `SkipLink.tsx` depends on `useLocale` from `next-intl`. Because the test environment doesn't provide a `next-intl` context provider and still mocks the old `react-i18next` library, it crashes. Updating the mock to intercept `next-intl` will satisfy the dependency and allow the test to pass.
2. **LanguageLayout Dead Code**: Since `LanguageLayout.tsx` was a relic of the previous i18n routing setup and is unreferenced, its removal is zero-risk and cleans up the bundle.
3. **Lint Warnings Fix**: The `@typescript-eslint/no-unused-vars` rule is intentionally not auto-fixable by default in ESLint (`eslint --fix` skips it). Since there are 159 warnings spread across dozens of files, manually deleting them is tedious. A bulk removal approach is required.

## Caveats
- I did not run a full build without `LanguageLayout.tsx`, but static analysis confirms it's orphaned.
- The lint warnings include a few non-i18n related unused variables (e.g., `Link`, `cn`, `baseButtonStyles` in `HeroSection.tsx`), so the cleanup tool must be capable of removing standard unused TS imports and variables, not just `useLocale`/`useTranslations`.

## Conclusion
1. **Fix `SkipLink.test.tsx`**: Replace the `react-i18next` mock with:
   ```tsx
   vi.mock('next-intl', () => ({
     useLocale: () => 'de',
     useTranslations: () => (key: string) => key,
   }));
   ```
2. **Remove Dead Code**: Delete `src/widgets/layout/LanguageLayout.tsx` directly.
3. **Resolve Lint Warnings**: The worker should run the `cleanup-dead-imports` skill (located at `.agent/skills/cleanup-dead-imports/SKILL.md`) to automatically strip all unused imports across the codebase, or temporarily install `eslint-plugin-unused-imports` to auto-fix them. 

## Verification Method
1. `npm run test -- src/shared/__tests__/SkipLink.test.tsx` -> Should pass with 3/3 tests green.
2. `rm src/widgets/layout/LanguageLayout.tsx && npm run build` -> Should compile successfully.
3. Apply the import cleanup strategy, then run `npm run lint` -> Should exit with `0 errors, 0 warnings`.
