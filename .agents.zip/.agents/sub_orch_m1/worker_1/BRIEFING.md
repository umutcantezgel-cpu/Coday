# BRIEFING — 2026-05-23T18:25:20-07:00

## Mission
Migrate from react-i18next to next-intl across the Coday codebase.

## 🔒 My Identity
- Archetype: Worker
- Roles: implementer, qa
- Working directory: /Users/umurey/agency-domination/.agents/sub_orch_m1/worker_1
- Original parent: d81de234-e771-4fee-a038-de6e5085c3f5
- Milestone: Milestone 1: i18n & Hydration

## 🔒 Key Constraints
- Bulk replace `react-i18next` with `next-intl` via a script.
- Move `src/app/` UI routes to `src/app/[locale]/`.
- Setup `next-intl` in `next.config.ts`, `middleware.ts`, `src/i18n/request.ts`.
- Delete old i18n files and package dependencies.
- Verify with typecheck, lint, build.
- Do NOT push to main, do not cheat.
- Strict TypeScript, no any.

## Current Parent
- Conversation ID: d81de234-e771-4fee-a038-de6e5085c3f5
- Updated: 2026-05-23T18:25:20-07:00

## Task Summary
- **What to build**: Migration to `next-intl`.
- **Success criteria**: typecheck, lint, and build pass after migration.
- **Interface contracts**: PROJECT.md / SCOPE.md
- **Code layout**: Project layout

## Key Decisions Made
- Use a Node.js script for bulk refactoring.

## Artifact Index
- [TBD]
