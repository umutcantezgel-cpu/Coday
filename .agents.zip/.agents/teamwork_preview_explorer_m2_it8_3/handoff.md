# Handoff Report: Iteration 8 Fixes for Milestone 2

## 1. Observation

1. **`react-router-dom` Imports**: 
   - Found `react-router-dom` still imported in `src/widgets/layout/MainLayout.tsx`, `src/widgets/navigation/NavDropdown.tsx`, and `src/widgets/home/HeroSection.tsx`. 
   - `MainLayout.tsx` uses `useLocation`, `useOutlet`, and `Outlet` instead of App Router primitives.
   - `NavDropdown.tsx` and `HeroSection.tsx` use `NavLink`.
2. **`TFunction` and `.raw()` Errors**: 
   - The previous worker used `t('culture.team.members', { returnObjects: true })` in `src/features/culture/TeamGallery.tsx`. This causes TypeScript errors (`Conversion of type 'string' to type 'TeamMember[]' may be a mistake`) because `next-intl`'s `t()` returns a string.
   - `next-intl` natively supports `t.raw('key')` for objects/arrays. The `TFunction` error reported in the previous run was a remnant of `react-i18next` types being present before the transition to `next-intl` was fully resolved.
3. **Translation (`i18n`) Type Errors**:
   - Running `npm run typecheck` yields over 60 errors.
   - `Cannot find name 'useTranslation'`: Many files still attempt to use `useTranslation` (e.g., `src/features/seo/TrafficROICalculator.tsx`, `src/features/blog/ui/BlockRenderer.tsx`).
   - `Cannot find name 'i18n'`: Many files destructured `const { t, i18n } = useTranslation()`, which broke when changed to `const t = useTranslations()`.
   - `Argument of type 'string' is not assignable to parameter of type 'TranslationValues'`: Files like `src/widgets/cookie/CookieSettingsModal.tsx` pass a string fallback as the second argument (e.g., `t('cookie.settings.title', 'Cookie Einstellungen')`). `next-intl` expects a `TranslationValues` object, not a string fallback.
4. **CookieConsentBanner**: 
   - `src/widgets/cookie/CookieConsentBanner.tsx` uses a `<div className="fixed...">` wrapper instead of the required semantic `<aside aria-label="Cookie Banner">`.
5. **Linting and ESLint**:
   - `eslint.config.js` does not include `src/.pages-backup/` in its `ignores` array.
   - `eslint.config.js` contains `@typescript-eslint/no-explicit-any: 'off'`, which is a direct INTEGRITY VIOLATION of project rules.

## 2. Logic Chain

- **`react-router-dom`**: The project uses Next.js App Router. All `react-router-dom` usages must be replaced. `NavLink` should become `Link` from `@/i18n/navigation`. `useLocation` should become `usePathname` from `@/i18n/navigation`. `Outlet` should be replaced by rendering `children` props.
- **`t.raw`**: By using `t.raw('key')` instead of `{ returnObjects: true }`, we leverage the correct `next-intl` API and resolve the type overlaps for `TeamMember[]` and `string[]` arrays.
- **Translation Errors**: 
  - To fix `Cannot find name 'i18n'`, we must use `import { useLocale } from 'next-intl'` and replace `i18n.language` with `const locale = useLocale()`.
  - To fix string fallbacks, we must remove the second string argument from `t('key', 'Fallback')` calls across the 60+ instances, as fallback messages are handled at the provider level in `next-intl`.
- **Semantic HTML**: Changing the `<div>` to `<aside aria-label="Cookie Banner">` ensures accessibility compliance and satisfies the requirement.
- **Lint Integrity**: Adding `'src/.pages-backup/'` to `eslint.config.js` `ignores` legitimately resolves the parsing error for `dummy.tsx`. Removing the `@typescript-eslint/no-explicit-any: 'off'` rule re-enables strict type checking as mandated by the agency rules.

## 3. Caveats

- There are quite a few files with the translation string argument error (`Argument of type 'string' is not assignable...`). The implementer will need to do a bulk search-and-replace or run a script to remove the second argument safely.
- Some legacy pages in `src/legacy/` and `src/pages_backup_2/` also have `react-router-dom` imports, but since they are in backup folders (already ignored by ESLint and build processes), I have focused only on the active `src/widgets/` and `src/features/` codebase.

## 4. Conclusion

A systematic fix strategy is required for the implementer:
1. **ESLint**: Update `eslint.config.js` to add `'src/.pages-backup/'` to `ignores` and delete the `'@typescript-eslint/no-explicit-any': 'off'` line.
2. **Cookie Banner**: Edit `src/widgets/cookie/CookieConsentBanner.tsx` to wrap the banner in `<aside aria-label="Cookie Banner" className="fixed...">`.
3. **`react-router-dom` Removal**: Refactor `MainLayout.tsx`, `NavDropdown.tsx`, and `HeroSection.tsx` to use `@/i18n/navigation`.
4. **Bulk i18n Fixes**: 
   - Replace `{ returnObjects: true }` with `t.raw()` where arrays/objects are expected.
   - Remove string fallbacks from `t()` calls globally.
   - Migrate `useTranslation` -> `useTranslations` and `i18n.language` -> `useLocale()`.

## 5. Verification Method

1. Run `npm run lint` and verify it exits with code 0. Check `eslint.config.js` to ensure `@typescript-eslint/no-explicit-any` is not disabled.
2. Run `npm run typecheck` and verify it exits with code 0 with no unresolved translation errors or `any` hacks.
3. Inspect `src/widgets/cookie/CookieConsentBanner.tsx` manually to confirm the `<aside>` tag is present.
4. Run `grep -r "react-router-dom" src/widgets src/features` to confirm 0 results.
