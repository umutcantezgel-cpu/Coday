# Handoff Report

## 1. Observation
- Inspected the repository state for `src/shared/__tests__/SkipLink.test.tsx`, `src/shared/ui/SkipLink.tsx`, and `src/widgets/home/HeroSection.tsx`.
- The `HEAD` commit (buggy state from previous iteration) contains the following incorrect patterns:
  - `src/shared/__tests__/SkipLink.test.tsx`: Uses `vi.mock('react-i18next', ...)` to mock internationalization internally instead of providing the `NextIntlClientProvider` wrapper.
  - `src/shared/ui/SkipLink.tsx`: Imports `useTranslation` from `react-i18next`.
  - `src/widgets/home/HeroSection.tsx`: Imports `useTranslation` from `react-i18next` and `Link as NavLink` from `react-router-dom`.
- Note: There are currently uncommitted changes in the workspace that appear to correctly apply these fixes, indicating a dirty working tree from a previous automated attempt. The target state to reach is confirmed to be the one detailed in the fix strategy below.

## 2. Logic Chain
- Based on the project constraints, `react-router-dom` and `react-i18next` are forbidden. The project strictly uses Next.js 15 App Router routing (`next/link`) and `next-intl`.
- Furthermore, the constraints dictate that we must NOT mock `next-intl` internally in test files. We must instead use `NextIntlClientProvider` to wrap test renders.
- To resolve the error from Iteration 4, the implementer needs to rewrite the imports and usage in the three affected files to use the correct libraries, ensuring tests run correctly without mocking the i18n internals.

## 3. Caveats
- I did not investigate the primary task scope (Tailwind brand vs primary mappings, and `CookieBanner` markup) as my specific sub-task directive was scoped strictly to fixing the hallucinated imports in these three files.
- The implementer should ensure no other files were affected by the `react-router-dom` and `react-i18next` hallucination (although `grep` results suggest these were the primary remaining culprits in the investigated paths).

## 4. Conclusion
The recommended fix strategy for the implementer is:

**1. `src/shared/__tests__/SkipLink.test.tsx`**
- **Remove:** `vi.mock('react-i18next', ...)` and `import { vi } from 'vitest'`.
- **Add:** `import { NextIntlClientProvider } from 'next-intl'`.
- **Change:** Create a helper `renderWithIntl` that wraps `<SkipLink />` inside `<NextIntlClientProvider locale={locale} messages={messages}>`. Use this helper for all test assertions.

**2. `src/shared/ui/SkipLink.tsx`**
- **Remove:** `import { useTranslation } from 'react-i18next'`.
- **Add:** `import { useTranslations } from 'next-intl'`.
- **Change:** Update the hook call to `const t = useTranslations('common')` and use `t('skipLink')` to retrieve the label.

**3. `src/widgets/home/HeroSection.tsx`**
- **Remove:** `import { useTranslation } from 'react-i18next'` and `import { Link as NavLink } from 'react-router-dom'`.
- **Add:** `import { useTranslations } from 'next-intl'` and `import Link from 'next/link'`.
- **Change:** Replace `const { t } = useTranslation(...)` with `const t = useTranslations('home')` and `const tCommon = useTranslations('common')`. Replace `<NavLink to="...">` with `<Link href="...">`.

## 5. Verification Method
- **Static checks:** Run `npm run lint` and `npm run typecheck`.
- **Tests:** Run `npx vitest run src/shared/__tests__/SkipLink.test.tsx` to verify the tests pass with the new provider wrapper.
- **Search:** Run `grep -r "react-i18next" src/` and `grep -r "react-router-dom" src/` to ensure no traces remain in the project.
