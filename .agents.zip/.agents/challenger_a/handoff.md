## Challenge Summary

**Overall risk assessment**: MEDIUM

The accessibility issues for Milestone 5 (Gen3) were partially resolved. While the ARIA updates in `StatsSection.tsx` are correctly implemented, the focus trap logic in `CardNav.tsx` fails to behave as expected when `Escape` is pressed. Focus is lost to the `<body>` element instead of returning to the navigation pill button.

## 1. Observation

- **StatsSection.tsx**: I verified the source code of `src/widgets/home/StatsSection.tsx`. It correctly wraps visual-only animated numbers with `aria-hidden="true"` and provides adjacent `.sr-only` spans containing the fully formed, translatable text for screen readers. A Playwright E2E test (`e2e/a11y-check.spec.ts`) confirmed these elements exist in the DOM.
- **CardNav.tsx**: I created an E2E Playwright test (`e2e/a11y-check.spec.ts`) to empirically verify the focus trap. The test focuses a navigation pill button, opens the dropdown, focuses a link inside the dropdown, and presses `Escape`. The test failed with `Received: inactive` when asserting `expect(navButton).toBeFocused()`.
- **CardNav.tsx Source**: I reviewed `src/widgets/navigation/CardNav.tsx` lines 78-84. The `handleKeyDown` function contains:
  ```typescript
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      const button = (e.currentTarget as HTMLElement).querySelector<HTMLButtonElement>('.nav-pill-link');
      button?.focus();
      setActiveCategory(null);
    }
  };
  ```
- **Debug Script**: A secondary Playwright script (`e2e/test-a11y-debug.spec.ts`) logged `document.activeElement` before and after pressing `Escape`. The output confirmed that after `Escape`, the focus falls to `<body>` (`document.activeElement === document.body` was `true`).
- **E2E Tests**: The `pa11y-ci` automated accessibility tests run by `npm run test:a11y:ci` passed successfully for all 4 configured routes, meaning no baseline contrast or label issues remain.

## 2. Logic Chain

1. The `pa11y-ci` tests successfully passed, demonstrating the baseline accessibility is sound and the missing ARIA labels have been resolved.
2. In `StatsSection.tsx`, the explicit `aria-hidden="true"` on the animated numbers and the adjacent `sr-only` text correctly guides screen readers while keeping visual effects intact.
3. In `CardNav.tsx`, the worker's attempt to trap focus uses a `keydown` handler on the `.nav-item-wrapper` that listens for `Escape`.
4. When `Escape` is caught, it attempts to explicitly set focus back to `.nav-pill-link` via `button?.focus()` and then immediately unmounts the dropdown content via `setActiveCategory(null)`.
5. However, `button?.focus()` followed immediately by unmounting the active element's container (the dropdown) or missing `e.preventDefault()` allows the browser or a bubbling handler to interfere. As a result, the focus is dropped and the browser resets focus to `<body>`.
6. Therefore, the implementation in `CardNav.tsx` does not meet the requirement of correctly returning focus to the trigger button without dropping it to `<body>`.

## 3. Caveats

- I did not test the focus trap with a manual screen reader (like VoiceOver or NVDA). I relied on `document.activeElement` within an automated Chromium browser (Playwright) which natively models DOM focus behavior.
- The `e.preventDefault()` or `e.stopPropagation()` might be all that is needed, or perhaps a `requestAnimationFrame` before calling `button.focus()`, but it is out of scope for me to fix it.
- The automated `pa11y-ci` tests passed, but automated tests often cannot verify dynamic interaction patterns like "pressing Escape inside a dropdown", which is why my empirical E2E test caught this.

## 4. Conclusion

The Gen3 worker successfully addressed the `StatsSection` ARIA labels and resolved the build issues to get `test:a11y:ci` passing. However, the `CardNav` focus fix is flawed. Pressing `Escape` still causes focus to reset to the `<body>` instead of gracefully returning to the `nav-pill-link`.

The task should be marked as **Incomplete / Failed Verification** until the `CardNav.tsx` logic is fixed to reliably trap and return focus on `Escape`.

## 5. Verification Method

To independently verify this finding:
1. Ensure the development server is running (`npm run build && PORT=3000 npm run start` or `npm run dev`).
2. Run the Playwright test I added: `npx playwright test e2e/a11y-check.spec.ts --project=chromium`.
3. Observe the output:
   - `[chromium] › e2e/a11y-check.spec.ts:30:1 › StatsSection contains aria-hidden and sr-only text` **PASSES**
   - `[chromium] › e2e/a11y-check.spec.ts:3:1 › CardNav correctly returns focus to the nav button on Escape` **FAILS** (Expected: focused, Received: inactive).
4. Alternatively, manually open `http://localhost:3000/`, use the `Tab` key to focus on "Services" (`nav-pill-link`), press `Enter` to open it, `Tab` to a link inside the dropdown, and press `Escape`. You will observe that the "Services" button does not receive the focus outline.
