# Scope: Awwwards-Level UI/UX Animations

## Architecture
- React SPA built with Vite and React Router v7.
- Micro-interactions (magnetic buttons, scroll-tracking, noise overlays) to be implemented in `src/shared/ui/animations`.
- Animations must use requestAnimationFrame and CSS GPU acceleration (transform, opacity) to ensure 60 FPS and avoid main thread blocking.

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| 3.1 | Noise Overlay | Implement a subtle, fixed, pointer-events-none noise overlay using CSS or minimal JS | none | DONE |
| 3.2 | Magnetic Button | Implement a magnetic button wrapper using requestAnimationFrame and GPU transforms | none | DONE |
| 3.3 | Scroll-Tracking | Implement smooth scroll-tracking modifiers (parallax/reveals) using modern web APIs (e.g. Scroll-driven animations, requestAnimationFrame) | none | DONE |

## Interface Contracts
### `src/shared/ui/animations` ↔ components
- Reusable hooks or wrappers (`<Magnetic>`, `<Noise>`, `<ScrollReveal>`).
- Must not affect LCP/CLS metrics (M2 compatibility).
