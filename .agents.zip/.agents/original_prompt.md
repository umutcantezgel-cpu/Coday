## 2026-05-23T17:58:08-07:00

Restore the original UI/UX design by fixing broken layouts, hydration mismatches, and Tailwind CSS conflicts introduced during the recent Next.js 15 App Router migration. The final result must be a flawless, production-ready interface matching high-end agency standards.

Working directory: /Users/umurey/agency-domination
Integrity mode: development

## Requirements

### R1. Resolve Migration Visual Bugs
Identify and fix all visual regressions, broken CSS, layout shifts, and Tailwind CSS conflicts that occurred during the migration to Next.js 15 App Router.

### R2. Eliminate Hydration Errors
Ensure that all React Server Components vs. Client Components boundaries are correctly respected and that no hydration mismatches occur on the client side that could break the UI.

### R3. Production Polish
Ensure the resulting UI/UX meets high-end agency standards and feels premium, responsive, and flawless for end-users on all viewports.

## Acceptance Criteria

### Visual & Layout Integrity
- [ ] No visual regressions or layout shifts remain from the migration.
- [ ] UI components render flawlessly across mobile, tablet, and desktop viewports.

### Console & Build
- [ ] No React hydration mismatches appear in the browser console during local development.
- [ ] The Next.js production build (`npm run build`) completes successfully without any CSS module or Tailwind configuration errors.

### Verification
- [ ] Existing Playwright test suites (if applicable) or programmatic validation scripts run successfully without catching layout shifts or visual errors.

## 2026-05-24T01:40:18Z

CRITICAL COURSE CORRECTION: 
I noticed that your workers just modified `src/widgets/home/HeroSection.tsx` and changed `next/link` back to `import { Link as NavLink } from 'react-router-dom';`. 

DO NOT USE `react-router-dom`! This project has been fully migrated to Next.js 15 App Router. `react-router-dom` is no longer installed and its usage will break the build. 

Please immediately undo the `react-router-dom` imports and strictly use `next/link` (or `@/shared/ui/LocalizedLink`) for all routing. The goal is to restore the visual design (Tailwind, hydration fixes), NOT to revert the underlying Next.js routing architecture back to Vite/React Router.

## 2026-05-24T11:33:19Z

AUTHORIZATION GRANTED & BLOCKER RESOLVED:
I have explicitly authorized the `package.json` changes. Furthermore, I have proactively run the cleanup for you.
- Uninstalled all `react-router`, `react-router-dom`, and `vite` dependencies.
- Re-installed and ensured `next` and `next-intl` are present.
- Updated `scripts.dev`, `scripts.start`, and `scripts.build` to use Next.js.
- Removed the legacy `vite preview` script.

The `package.json` is now fully Next.js 15 App Router compliant. You are unblocked! Please resume the dev server, build tests, and continue finalizing your hydration and layout fixes.

## 2026-05-24T12:15:30Z

The `npm run typecheck` verification failed. You have remaining migration errors from switching `react-i18next` to `next-intl`. 

In `next-intl`:
1. You cannot use `t('key', 'default value')`. The second argument must be an object of values (e.g. `t('key', { name: 'World' })`). If you just want a default value, you don't pass it as a string. Instead, use a fallback mechanism or add it to the messages dictionary.
2. The `i18n` object (like `i18n.language` or `i18n.dir()`) no longer exists. Use `const locale = useLocale();` instead.
3. You cannot pass an array to `t()`. Use `t.raw('key')` or `t.rich('key')` if returning objects/arrays depending on your setup.

Here are the exact errors you need to fix:
src/features/booking/ui/BookingCalendar.tsx(150,15): error TS2322: Type 'string | undefined' is not assignable to type 'string | number | Date | RichTagsFunction'.
src/features/calculator/ui/ModuleCard.tsx(27,18): error TS2304: Cannot find name 'i18n'.
src/features/calculator/ui/ModuleCard.tsx(103,43): error TS2345: Argument of type 'string' is not assignable to parameter of type 'Record<string, string | number | Date>'.
src/features/calculator/ui/Summary.tsx(12,18): error TS2304: Cannot find name 'i18n'.
src/features/calculator/ui/Summary.tsx(61,47): error TS2345: Argument of type 'string' is not assignable to parameter of type 'Record<string, string | number | Date>'.
src/features/case-studies/ui/ResultMetrics.tsx(16,11): error TS2339: Property 'i18n' does not exist on type 'Translator<Record<string, any>, never>'.
src/features/consulting/ProblemSolventMatrix.tsx(87,49): error TS2345: Argument of type 'string' is not assignable to parameter of type 'Record<string, string | number | Date>'.
src/features/contact/ApplicationWizard.tsx(27,18): error TS2304: Cannot find name 'i18n'.
src/features/contact/ui/MobileContactLayout.tsx(34,21): error TS2345: Argument of type 'string' ...
src/features/culture/ValuesDeck.tsx(26,55): error TS2345: Argument of type 'string' ...
src/features/faq/ui/RelevantFAQs.tsx(15,29): error TS2345: Argument of type 'string[]' is not assignable to parameter of type 'string'.
src/features/faq/ui/RelevantFAQs.tsx(16,24): error TS2304: Cannot find name 'i18n'.
src/features/industries/gastronomie/TableBookingRoiVisualizer.tsx(99,56): error TS2304: Cannot find name 'i18n'.
src/features/industries/handwerk/CraftsmanLeadCalculator.tsx(29,71): error TS2304: Cannot find name 'i18n'.
src/features/work/components/InProgressSection.tsx(25,48): error TS2345: Argument of type 'string' ...
src/features/work/components/TemplateVault.tsx(23,44): error TS2345: Argument of type 'string' ...
src/features/work/components/WorkHero.tsx(25,32): error TS2345: Argument of type 'string' ...

Please have your team fix these TypeScript errors immediately so the build can pass.
