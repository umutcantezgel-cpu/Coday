# Structural Hydration Fixes Handoff

## 1. Observation
- `src/shared/GlobalErrorBoundary.tsx`: The file defines a React class component using state (`this.state`), but lacks the `"use client";` directive at the top, which causes an error in Next.js 15 Server Components.
- `src/app/layout.tsx`: Line 28 `<body>` tag does not have `suppressHydrationWarning`. Lines 29-34 contain a raw `<script>` tag for the JSON-LD schema, despite `next/script` being imported on line 3.
- `src/widgets/home/ServicesSection.tsx`: Line 79 contains `className="... block h-full flex flex-col ..."`. The `block` and `flex` classes are conflicting Tailwind display utilities.

## 2. Logic Chain
1. **GlobalErrorBoundary**: Next.js App Router requires components with client-side state (like `React.Component` state) to be explicitly marked as Client Components. Adding `"use client";` at line 1 resolves this.
2. **Layout**: Hydration warnings often occur on the `<body>` tag due to third-party scripts or browser extensions modifying its attributes. `suppressHydrationWarning` safely ignores these. Further, raw `<script>` tags can cause hydration issues; using Next.js's `<Script>` component is the standard way to inject JSON-LD and scripts safely.
3. **ServicesSection**: The `block` and `flex` utilities apply conflicting `display: block` and `display: flex` CSS properties. Since `flex-col` is present, the element is intended to be a flex container. Removing `block` resolves the conflict without breaking the layout.

## 3. Caveats
- No read/write or test capabilities were exercised by this agent (read-only constraint).
- The `suppressHydrationWarning` on `<body>` only applies one level deep. This is standard practice, but any hydration issues deeper in the tree might still appear.

## 4. Conclusion
The requested fixes are straightforward and can be applied with the following code modifications:

**Proposed Changes:**

**`src/shared/GlobalErrorBoundary.tsx`**
```tsx
// BEFORE (line 1)
import * as React from 'react';

// AFTER
"use client";
import * as React from 'react';
```

**`src/app/layout.tsx`**
```tsx
// BEFORE (lines 28-34)
      <body className="bg-secondary text-white antialiased">
        <script
          id="schema-organization"
          type="application/ld+json"
          nonce={nonce}
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }}
        />

// AFTER
      <body className="bg-secondary text-white antialiased" suppressHydrationWarning>
        <Script
          id="schema-organization"
          type="application/ld+json"
          nonce={nonce}
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }}
        />
```

**`src/widgets/home/ServicesSection.tsx`**
```tsx
// BEFORE (lines 77-80)
                <NavLink
                  href={service.link}
                  className="group relative p-6 md:p-8 block h-full flex flex-col focus:outline-none focus-visible:ring-4 focus-visible:ring-primary focus-visible:rounded-2xl"
                >

// AFTER
                <NavLink
                  href={service.link}
                  className="group relative p-6 md:p-8 h-full flex flex-col focus:outline-none focus-visible:ring-4 focus-visible:ring-primary focus-visible:rounded-2xl"
                >
```

## 5. Verification Method
1. Apply the provided code snippets.
2. Run `npm run typecheck` to verify no type errors were introduced.
3. Run `npm run lint` to verify no linting rules are broken.
4. Run `npm run build` to ensure the project builds without Next.js errors.
5. Run `npm run dev` and open the browser console. Confirm that there are no hydration warnings and that the layout of the Services Section is intact.
