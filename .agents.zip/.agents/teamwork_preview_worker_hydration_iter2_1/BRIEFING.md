# BRIEFING — 2026-05-24T01:40:00Z

## Mission
Fix build/typecheck errors and Tailwind bug, and ensure typecheck, lint, and build pass cleanly for the Coday agency website.

## 🔒 My Identity
- Archetype: qa, implementer, specialist
- Roles: implementer, qa, specialist
- Working directory: /Users/umurey/agency-domination/.agents/teamwork_preview_worker_hydration_iter2_1
- Original parent: 0e8a5270-6fb4-48ac-8852-1ebb627878f6
- Milestone: Hydration Iteration 2

## 🔒 Key Constraints
- NEVER push directly to `main`.
- NEVER modify next.config.ts, middleware.ts, .env.*, package.json dependencies without explicit confirmation.
- NEVER run destructive commands.
- Solo-Founder Reality: Keep solutions maintainable.
- TypeScript strict mode, RSC by default, Tailwind inline.
- Integrity Mandate: Do not cheat or fake outputs.

## Current Parent
- Conversation ID: 0e8a5270-6fb4-48ac-8852-1ebb627878f6
- Updated: 2026-05-24T01:40:00Z

## Task Summary
- **What to build**: Fix TS syntax errors (`t('key', 'fallback')`), HeroSection, LanguageSwitcher, formatService, Tailwind purge bug, GlobalErrorBoundary. Run build and typecheck.
- **Success criteria**: `npm run typecheck`, `npm run lint`, and `npm run build` pass successfully.

## Key Decisions Made
- [TBD]

## Artifact Index
- [TBD]
