# Handoff Report

## 1. Observation
- `src/shared/__tests__/SkipLink.test.tsx` lines 5-8: uses `vi.mock('next-intl', ...)` instead of a proper provider.
- `src/shared/ui/SkipLink.tsx` lines 2, 9-10: imports `useTranslation` from `react-i18next` and uses `i18n.language` to hardcode the translation logic.
- `src/widgets/home/HeroSection.tsx` lines 4-5: imports `useTranslation` from `react-i18next` and `Link as NavLink` from `react-router-dom`.
- `HeroSection.tsx` lines 35, 60, 66, 77, 85, 97, 102, 112, 131, 148: uses `t('...')` with object configurations like `{ returnObjects: true }` or `{ ns: 'common' }` that are specific to `react-i18next`.

## 2. Logic Chain

### A. Fix `src/shared/__tests__/SkipLink.test.tsx`
Remove the `vi.mock('next-intl')` entirely. Import `NextIntlClientProvider` from `next-intl` and wrap the `<SkipLink />` component in the tests. Supply `locale` and `messages` to the provider to satisfy the context requirement.

### B. Fix `src/shared/ui/SkipLink.tsx`
Replace `react-i18next` with `next-intl`. Import `useTranslations` and `useLocale`. Check if the translation key exists using `t.has()`, and provide the hardcoded label as a fallback via `useLocale()`. This explicitly meets the reviewer's requirement to utilize both hooks safely.

### C. Fix `src/widgets/home/HeroSection.tsx`
- Replace `import { useTranslation } from 'react-i18next';` with `import { useTranslations } from 'next-intl';`.
- Replace `import { Link as NavLink } from 'react-router-dom';` with `import Link from 'next/link';`.
- Update `NavLink` JSX tags to `Link` and change the `to="..."` prop to `href="..."`.
- Replace the single `t` function with namespace-specific hooks: `const tHome = useTranslations('home');` and `const tCommon = useTranslations('common');`.
- Replace `t('hero.X')` calls with `tHome('hero.X')`.
- For the array, replace `t('hero.rotating', { returnObjects: true }) as string[]` with `tHome.raw('hero.rotating') as string[]`.
- For the common namespace calls, replace `t('buttons.X', { ns: 'common' })` with `tCommon('buttons.X')`.
- For the `defaultValue`, use `tCommon.has('buttons.contact') ? tCommon('buttons.contact') : tCommon('buttons.view_work')`.

## 3. Caveats
- `t.has()` and `t.raw()` are modern `next-intl` methods (v3+). They are standard for App Router, but the worker should ensure the syntax matches the installed version.
- `NextIntlClientProvider` requires a `messages` object in tests. We are injecting a minimal mock dictionary inline for `skipToMain`.
- The `href` attribute on Next.js `Link` might require standard locale prefixes if not handled globally, but for a direct swap, replacing `to` with `href` is sufficient.

## 4. Conclusion
The worker needs to implement the exact code swaps outlined in the logic chain to resolve the reviewer's feedback.

## 5. Verification Method
After changes are made by the implementer, run:
1. `npm run typecheck`
2. `npm run lint`
3. `npm run test -- src/shared/__tests__/SkipLink.test.tsx`
4. Inspect `src/shared/ui/SkipLink.tsx` and `src/widgets/home/HeroSection.tsx` to verify zero traces of `react-i18next` and `react-router-dom`.
