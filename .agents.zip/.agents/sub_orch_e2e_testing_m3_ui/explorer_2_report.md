# Explorer 2 Report: UI/UX & Scenarios E2E Test Strategy (Milestone 3)

## 1. Observation
- The application heavily relies on `framer-motion` (imported as `motion/react`) for its UI/UX micro-interactions.
- Key UI components include `Magnetic`, `CustomCursor`, `ScrollReveal`, `AnimatedList`, and `MobileNavOverlay` found in `src/shared/ui/` and `src/widgets/`.
- The `Magnetic` component (`src/shared/ui/Magnetic.tsx`) uses mouse position tracking to animate the position of its children using a spring transition.
- The `playwright.config.ts` is configured to run against the built preview server (`http://localhost:4173`).
- E2E Test infrastructure requirements (from `TEST_INFRA.md`):
  - **Feature 4**: UI/UX 60 FPS Micro-interactions (Tier 1: ≥5, Tier 2: ≥5, Tier 3: Pairwise)
  - **Real-World Scenarios**: Tier 4: ≥5 complex scenarios crossing multiple features.

## 2. Logic Chain

### 2.1 Testing Strategy for 60 FPS in Playwright
Playwright cannot directly assert "FPS" using standard locators. To measure frame rate during interactions, we must inject a `requestAnimationFrame` loop into the browser context while simultaneously performing the Playwright actions (scrolling, moving mouse).

**Proposed Utility Function (`e2e/utils/fps.ts`):**
```typescript
import { Page } from '@playwright/test';

export async function measureFPS(page: Page, action: () => Promise<void>, durationMs = 1000): Promise<number> {
  const fpsPromise = page.evaluate((duration) => {
    return new Promise<number>((resolve) => {
      let frames = 0;
      let startTime = performance.now();
      
      const measure = (time: DOMHighResTimeStamp) => {
        frames++;
        if (time - startTime < duration) { 
          requestAnimationFrame(measure);
        } else {
          resolve((frames * 1000) / (time - startTime)); // Calculate FPS
        }
      };
      requestAnimationFrame(measure);
    });
  }, durationMs);

  await action();
  return await fpsPromise;
}
```

### 2.2 Test Design: `e2e/ui.spec.ts` (Feature 4)

**Tier 1: Core Functionality (≥5 tests)**
1. **Magnetic Button Hover:** Mouse over a `Magnetic` element, move the cursor inside its bounding box continuously, and verify FPS ≥ 55.
2. **ScrollReveal Animations:** Smoothly scroll down the homepage using `mouse.wheel`, triggering `ScrollReveal` components, verifying scroll FPS ≥ 55.
3. **Mobile Navigation Overlay:** Click the mobile menu toggle (under mobile viewport), measure the opening animation FPS and verify it completes without jank.
4. **Custom Cursor Tracking:** Move the mouse rapidly across the screen and use CDP or coordinate polling to ensure the `CustomCursor` DOM element correctly tracks the mouse coordinates with minimal latency.
5. **Interactive UI Widgets:** Interact with a complex widget (e.g., `CircularGauge` in the Analyzer), ensuring the animation plays at 60 FPS.

**Tier 2: Boundary & Edge Cases (≥5 tests)**
1. **Rapid Menu Toggling:** Quickly toggle the MobileNavOverlay 10 times in succession. Verify the state does not corrupt, animations do not get stuck, and final state matches intent.
2. **Viewport Resizing during Animation:** Resize the viewport (e.g., 1920x1080 to 375x812) while a `ScrollReveal` component is entering the viewport. Verify layout integrity post-resize.
3. **Extreme Scrolling Thrash:** Rapidly scroll up and down the page (simulating trackpad flick). Verify the FPS remains above a degraded threshold (e.g., ≥ 45 FPS) and no layout thrashing occurs.
4. **Low-end Device Emulation:** Use Playwright's CDP session to enable CPU throttling (`Emulation.setCPUThrottlingRate`, rate: 4x) and measure Magnetic button hover FPS. Validate graceful degradation (e.g., ≥ 30 FPS).
5. **Concurrent Animations:** Trigger a scroll animation and a hover animation simultaneously (e.g., scrolling while hovering a Magnetic button) and measure combined FPS.

**Tier 3: Pairwise Interactions (≥3 tests)**
1. **Magnetic Component + Custom Cursor:** Verify that interacting with a Magnetic component does not visually desync the custom cursor.
2. **Mobile Nav + Scroll Lock:** Open the Mobile Navigation, attempt to scroll the background page. Verify background scroll is locked and the attempt doesn't cause frame drops on the overlay.
3. **Interactive Widget + Route Change:** Click an internal SPA link while an animation is playing. Verify the unmount is clean and does not leave orphaned animated elements.

### 2.3 Test Design: `e2e/scenarios.spec.ts` (Tier 4)

**Scenario 1: The Organic Funnel (SEO + Perf + UI)**
- *Path:* Landing (Homepage) -> Packages.
- *Steps:* User lands on homepage. Validate JSON-LD and Canonical (SEO). Check LCP < 1.5s (Perf). Scroll down via mouse wheel (checking FPS) and click a `Magnetic` CTA to go to `/packages`. Verify SPA navigation succeeds and new URL SEO tags are correct.

**Scenario 2: Mobile Service Booking (UI + SEO)**
- *Path:* Organic search entry to Services -> Contact.
- *Steps:* Emulate mobile viewport. Land on `/services`. Open `MobileNavOverlay` (check 60 FPS). Navigate to `/contact`. Fill out the contact form. Ensure layout does not shift (CLS < 0.1) when the keyboard appears (simulated via focus), and validate form submission interactions.

**Scenario 3: Deep Industry Navigation (Perf + UI)**
- *Path:* Direct link to `/branchen/handwerk`.
- *Steps:* Load `/branchen/handwerk`. Validate breadcrumb JSON-LD. Perform rapid scroll to bottom to load `AnimatedList` features. Verify no main-thread blocking. Click "Angebot anfordern" to enter the wizard.

**Scenario 4: Content Engagement & Interactivity (SEO + UI)**
- *Path:* Knowledge Base -> Interactive Blog Post.
- *Steps:* Land on `/wissen/blog`. Click an article. Verify `Article` JSON-LD. Interact with a complex component like `ROICalculator` embedded in the blog. Ensure slider/input adjustments update values at 60 FPS without layout shifts.

**Scenario 5: Analyzer Tool Flow (Perf + UI)**
- *Path:* Homepage -> Analyzer.
- *Steps:* User clicks to `/analyzer`. `CircularGauge` and `ScoreCard` animations play smoothly (FPS ≥ 55). User submits a URL. The waiting state (`AnalysisProgress`) maintains high FPS. Results are rendered with CLS < 0.1.

## 3. Caveats
- **CI Environments:** Achieving a true 60 FPS in a headless CI environment (like GitHub Actions) is highly unlikely due to lack of a real GPU and shared CPU resources. It is recommended to lower the threshold (e.g., ≥ 30 FPS) when `process.env.CI` is true, while keeping strict 60 FPS (≥ 55) for local runs.
- **rAF Injection Precision:** The `requestAnimationFrame` method measures the browser's render loop, but Playwright's mouse commands might not map 1:1 to human micro-jitters. Test actions will need to use continuous `mouse.move` interpolations to accurately trigger hover animations continuously.

## 4. Conclusion
We have fully specified the strategies and test cases required for Milestone 3. The Playwright injection method allows us to opaque-box test the application's React-based Framer Motion animations. We have designed 5+ Tier 1 tests, 5+ Tier 2 tests, some Tier 3 tests, and 5 comprehensive Tier 4 scenarios bridging SEO, Performance, and UI/UX.

## 5. Verification Method
- **Implementation:** The implementer will create `e2e/utils/fps.ts`, `e2e/ui.spec.ts`, and `e2e/scenarios.spec.ts` based on this design.
- **Execution:** The suite can be independently verified by running `npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts`.
- **Validation:** Visual verification of the Playwright HTML report (`playwright-report/index.html`) to check that the tests successfully passed the FPS thresholds and correctly completed the real-world navigation scenarios.
