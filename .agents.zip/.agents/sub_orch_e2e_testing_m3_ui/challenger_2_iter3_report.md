# E2E Testing M3 UI - Challenger 2 Iteration 3 Report

## 1. Observation
I executed the E2E test suites (`npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts`) against the local development server. The test run completed with 6 failures out of 17 tests:

1. **`scenarios.spec.ts:46` - The Organic Search Arrival**:
   `Error: expect(locator).toBeVisible() failed`
   `Locator: locator('a[href="/de/services"], a[href="/de/leistungen"]').first()`
   The test expects to find a link to the services hub, but it does not exist on the homepage.
2. **`scenarios.spec.ts:114` - The Bot Crawl (JS Disabled)**:
   `Error: expect(received).not.toEqual(expected) // deep equality` (Note: test was modified during run, but failed with `expect(botPage.url()).toContain('about');` receiving `/de`).
   The test clicks the about link but does not await the navigation event properly before asserting the URL.
3. **`scenarios.spec.ts:135` - The Internationalization Switch**:
   `Error: expect(received).toContain(expected) // indexOf` (Expected: "en", Received: "de").
   The `enSwitch` locator (`button:has-text("EN")`) fails to correctly target the language switcher when the active language is "de" (since the button renders the text "DE"), leading to no language change.
4. **`ui.spec.ts:60` - Tier 1: Custom Cursor Render**:
   `Error: expect(locator).toBeAttached() failed` for `locator('.custom-cursor').first()`.
   The `CustomCursor` React component uses framer-motion but does not apply the `.custom-cursor` class to its rendered `div` elements.
5. **`ui.spec.ts:89` - Tier 1: Scroll Reveal Execution**:
   `Error: expect(received).toBeGreaterThan(expected)` (Expected: > 0.5, Received: 0.1).
   The scroll animation does not trigger. The test hardcodes `window.scrollTo(0, 5000)`, which is unreliable for triggering the `whileInView` animation on `#reveal-target`.
6. **`ui.spec.ts:12` - Tier 2: Rapid Interaction**:
   `Error: page.goto: Test timeout of 30000ms exceeded.`
   The dev server times out under parallel testing load, causing the `beforeEach` hook to fail randomly.

## 2. Logic Chain
1. **Scenario 1**: The implementation provides specific service routes (e.g. `/services/web-development`) rather than a general `/de/services` index link on the homepage. The test locator is stale or the implementation is missing the expected index link.
2. **Scenario 4**: In a JS-disabled context, `aboutLink.click({ force: true })` triggers a full page load. The test calls `botPage.waitForLoadState('domcontentloaded')` which might resolve immediately before the browser starts the actual navigation, causing the URL assertion to run prematurely. It should use `Promise.all([botPage.waitForNavigation(), aboutLink.click()])`.
3. **Scenario 5**: The `LanguageSwitcher` displays the *current* language text (e.g. "DE"). The test looks for a button containing the *target* language text ("EN"). The selector logic is inverted or fundamentally broken for this implementation.
4. **UI Tier 1 (Cursor)**: The test specifically asserts the presence of the `.custom-cursor` class, but the component in `src/shared/ui/CustomCursor.tsx` only has `fixed top-0 left-0...` utility classes.
5. **UI Tier 1 (Scroll)**: Playwright's viewport might not intersect `#reveal-target` when blindly scrolling to `Y=5000`. Another passing test successfully triggers it using `scrollIntoViewIfNeeded()`, proving the hardcoded pixel value is the culprit.
6. **Timeouts**: The dev server (`npm run build && npm run start` per Playwright config) is buckling under `fullyParallel: true` with 7 workers.

## 3. Caveats
- I did not fix the implementation code or the test code, as my role is strictly Review/Challenger.
- The `fullyParallel: true` timeout might be specific to my container's resource limits rather than an inherent application flaw, but it indicates the test suite's `beforeEach` is susceptible to race conditions.

## 4. Conclusion
The E2E tests are failing due to a mix of **stale locators**, **incorrect test assertions (flawed test logic)**, and **missing classes in the UI components**. The test suite is currently unreliable and does not accurately reflect the application's correctness. The implementer must fix the locators, adopt robust navigation awaiting (`waitForNavigation`), and align the `CustomCursor` component with the test expectations.

## 5. Verification Method
Run the following command to reproduce the failures:
```bash
npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts
```
Review the test results in the terminal or `playwright-report` to confirm the specific locator, timeout, and assertion failures documented above.
