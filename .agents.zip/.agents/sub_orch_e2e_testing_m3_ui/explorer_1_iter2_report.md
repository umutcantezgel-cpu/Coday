# Forensic Analysis & Fix Strategy Report

## 1. Observation

Based on a forensic audit of the E2E test suite (`e2e/ui.spec.ts` and `e2e/scenarios.spec.ts`), the following integrity violations and logic flaws were identified:

**Faked LCP Verification:**
In `e2e/scenarios.spec.ts` (Lines 16-34), the LCP evaluation explicitly defaults to `0` and silently resolves if an LCP event is not detected within 1 second:
```typescript
        setTimeout(() => {
          observer.disconnect();
          resolve(lcpValue); // lcpValue is 0 if no event fired
        }, 1000);
```
This is followed by `expect(Number(lcp)).toBeLessThan(5000);`, which evaluates `0 < 5000` and always passes.

**Faked FPS / Performance Tracking:**
In `e2e/ui.spec.ts` (Lines 31-48), the performance evaluation entirely skips the core FPS and frame drop assertions if the tracking fails or doesn't log any frames:
```typescript
    if (frameTimes && frameTimes.length > 0) {
      // ... calculations
      expect(fps).toBeGreaterThan(40);
      expect(longFrames.length).toBeLessThan(10);
    }
```
If `frameTimes` is empty, the test silently passes.

**Facade / Dummy Tests:**
Throughout both test files, interactions and assertions are placed inside conditional blocks that check for element existence:
- `e2e/ui.spec.ts`: `if (count > 0)` used for custom cursor (Line 60), nav items (Line 166).
- `e2e/scenarios.spec.ts`: `if (await servicesLink.count() > 0)` (Line 42), `if (await form.count() > 0)` (Line 56), mobile menu buttons (Line 81), canonical tags (Line 91), bot crawl links (Line 111), language switchers (Line 132).
If the feature isn't implemented and the element isn't in the DOM, the block is skipped and the test is marked as a pass without executing its intended validation.

## 2. Logic Chain

1. **LCP Bypass:** By resolving the LCP promise with `0` on timeout, the test fails to assert whether LCP was genuinely captured. The assertion `0 < 5000` evaluates to true, resulting in a false positive.
2. **FPS Bypass:** The condition `if (frameTimes && frameTimes.length > 0)` creates a safe-exit path. If `requestAnimationFrame` fails to run (e.g., due to an error, environment restriction, or blocking), the test interprets the absence of data as a passing state rather than a failure.
3. **Facade Checks:** The pervasive use of `if (await locator.count() > 0)` transforms requirement-driven E2E tests into optional checks. A requirement-driven test assumes the feature exists and tests its behavior; by making the existence conditional, the test loses its capacity to fail when the requirement is missing, defeating the purpose of opaque-box testing.

## 3. Caveats

- **Timeouts vs. Legitimate Failures:** Rejecting the promise for LCP if no event fires within 1 second is strict. If the application genuinely takes longer than 1 second to dispatch LCP, the test will fail, which is correct (since the requirement is LCP < 1.5s), but the 1-second timeout may need to be slightly adjusted (e.g., 2 seconds) to allow the failure to be about LCP exceeding thresholds rather than purely timing out.
- **Pipeline Blockers:** Applying the fix strategy will cause the test suite to immediately fail in CI if the actual application does not yet implement these features. This is expected and desired behavior, but should be noted.

## 4. Conclusion

The test suite contains structural integrity violations designed to artificially force tests to pass even when application features are absent or failing. 

**Recommended Fix Strategy:**
1. **LCP Test (`e2e/scenarios.spec.ts`):** Modify the `setTimeout` block in the LCP evaluation to reject the promise (e.g., `reject(new Error("LCP event not observed"))`) if `lcpValue === 0`. The assertion should strictly expect a value `> 0` and `< 5000`.
2. **FPS Test (`e2e/ui.spec.ts`):** Remove the `if (frameTimes && frameTimes.length > 0)` wrapper in `trackPerformance`. Instead, unconditionally assert `expect(frameTimes.length).toBeGreaterThan(0)` and then run the FPS assertions.
3. **Facade Removal:** Remove every instance of `if (await locator.count() > 0)` and `if (count > 0)`. Rely on Playwright's default strictness (`locator.click()`, `expect(locator).toBeVisible()`) so that tests immediately throw and fail when expected UI elements are not found.

## 5. Verification Method

- **Command:** `npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts`
- **Expected Outcome:** The test suite should FAIL with clear errors indicating missing elements (e.g., "Timeout waiting for locator('.custom-cursor')"), failed performance expectations, and rejected LCP promises.
- **Invalidation:** If the tests still pass against a barebones app missing the target components, or if there are any remaining silent passes/bypasses, the fix was implemented incorrectly.
