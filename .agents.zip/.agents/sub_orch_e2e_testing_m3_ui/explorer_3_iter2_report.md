# Handoff Report: E2E Testing Integrity Fix Strategy

## 1. Observation
- **LCP Bypass (`e2e/scenarios.spec.ts:16-34`)**: The `page.evaluate()` block sets a 1000ms `setTimeout` that resolves `lcpValue` as `0` if no `largest-contentful-paint` event fires. This forces `expect(Number(lcp)).toBeLessThan(5000)` to always pass, effectively hiding failures.
- **FPS/Performance Bypass (`e2e/ui.spec.ts:31-48`)**: The performance metrics are wrapped in `if (frameTimes && frameTimes.length > 0)`. If `requestAnimationFrame` fails to record any frames, the conditional bypasses the FPS and frame drop assertions entirely.
- **Facade Tests (`e2e/scenarios.spec.ts`, `e2e/ui.spec.ts`)**: Across both test suites, core interactions are guarded by conditional checks.
  - `e2e/scenarios.spec.ts` checks: `servicesLink.count() > 0` (line 42), `form.count() > 0` (line 56), `mobileMenuBtn.count() > 0` (line 81), `canonical.count() > 0` (line 91), `aboutLink.count() > 0` (line 111).
  - `e2e/ui.spec.ts` checks: `cursor.count() > 0` (line 60), `navItem.count() > 0` (line 166).

## 2. Logic Chain
- For tests to provide actual value, they must enforce constraints. A test that bypasses an assertion when the target element or condition is missing produces a false positive (a "silent pass").
- The conditional LCP check guarantees that missing content paint events result in an artificially fast time (`0ms`), masking both performance regressions and outright rendering failures. Rejecting the LCP promise if the event never fires will accurately surface failures.
- The conditional FPS check fails to assert that performance was tracked at all. Removing the condition and explicitly asserting `expect(frameTimes.length).toBeGreaterThan(0)` ensures the tracking mechanism is functioning before calculating metrics.
- The `if (await locator.count() > 0)` checks treat missing features as acceptable. By removing these conditions and unconditionally interacting with or asserting visibility on these elements (`await expect(locator).toBeVisible()`), the test will correctly fail when a required element is not implemented in the application.

## 3. Caveats
- Hard-failing LCP tests will likely cause tests to time out if the application lacks large content blocks. The underlying application may need to be fixed to emit valid `largest-contentful-paint` events.
- Hard-failing UI tests will cause all scenarios to fail immediately if the application has not yet implemented the forms, mobile menus, or specific service links. This is the correct behavior for E2E tests, but implies additional application work is required to reach a passing state.

## 4. Conclusion
To restore integrity to the E2E tests, we must execute the following strict fix strategy:
1. **LCP Fix**: In `e2e/scenarios.spec.ts`, replace the `setTimeout` resolution with a `reject(new Error('LCP event not fired within timeout'))` to ensure the test fails if rendering is broken.
2. **FPS Fix**: In `e2e/ui.spec.ts`, remove the `if (frameTimes && frameTimes.length > 0)` block. Instead, explicitly assert `expect(frameTimes.length).toBeGreaterThan(0)` before calculating and asserting FPS and long frames.
3. **Facade Removal**: In both `e2e/scenarios.spec.ts` and `e2e/ui.spec.ts`, remove all `if (await locator.count() > 0)` blocks. Replace them with unconditional assertions (e.g., `await expect(locator).toBeVisible()`) and directly execute the `.click()`, `.fill()`, and subsequent assertions.

## 5. Verification Method
- **LCP/FPS Verification**: Run `npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts` against an unoptimized or broken build. The tests must fail with "LCP event not fired" or a failed `expect(frameTimes.length).toBeGreaterThan(0)` instead of passing silently.
- **Facade Verification**: Run the Playwright tests on the current application state. If the required elements (forms, menus, cursors) do not exist, the tests should throw explicit locator or assertion errors (e.g., `Error: locator.click: Timeout`).
