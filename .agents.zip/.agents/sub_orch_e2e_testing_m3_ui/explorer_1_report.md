# Handoff Report: E2E Test Strategy for UI/UX & Scenarios (Milestone 3)

## Observation
- **Scope & Requirements**: `ORIGINAL_REQUEST.md` specifies R3: "Awwwards-Level UI/UX Animationen" involving Magnetic Buttons, Background Noise, and 60 FPS micro-interactions without render-blocking tasks > 50ms. `TEST_INFRA.md` requires 5+ Tier 1 tests, 5+ Tier 2 tests, some Tier 3 tests in `e2e/ui.spec.ts`, and 5+ Tier 4 tests in `e2e/scenarios.spec.ts`.
- **Codebase Artifacts Identified**:
  - `Magnetic.tsx` — Handles hover interactions via `motion.div` updating `x` and `y` properties. Present in `MobileReadyNav.tsx`.
  - `ScrollFloat.tsx` & `ScrollReveal.tsx` — Used for scroll-based opacity/transform animations (e.g., in `Services.tsx` line 185).
  - `HeroSection.tsx` — Contains `.mix-blend-overlay` for Noise and lazy-loaded `MetaBalls` animation.
- **Playwright Constraints**: Playwright executes mouse and scroll actions almost instantly by default. To test 60 FPS and "smooth" scrolling, we must inject custom JS via `page.evaluate()` to perform `window.scrollBy({ behavior: 'smooth' })` and `requestAnimationFrame` hooks.

## Logic Chain
1. **Verifying 60 FPS**: Playwright runs in a Chromium environment where `requestAnimationFrame` triggers before each paint. We can inject a loop inside `page.evaluate()` to count frames over a 1-second interval. If the count is ~60, the animation is smooth. 
2. **Verifying <50ms Render Blocking**: The standard web API `PerformanceObserver` with `entryTypes: ['longtask']` captures tasks taking over 50ms. We can monitor this during interactions to ensure the bundle size/JS doesn't stall the main thread.
3. **Partitioning UI Tests (`e2e/ui.spec.ts`)**:
   - *Tier 1* must test baseline visual states and simple interactions (Hovering Magnetic buttons, verifying Noise overlay).
   - *Tier 2* must test edge cases and stress conditions (Spam scrolling, rapid mouse leave, FPS tracking under load like `MetaBalls`).
   - *Tier 3* must test interactions (Navigating while an animation is active).
4. **Designing Scenarios (`e2e/scenarios.spec.ts`)**:
   - *Tier 4* tests must be cross-cutting. A scenario should traverse multiple features (e.g., verifying SEO tags, triggering a UI animation, measuring LCP/CLS, and completing a navigation flow).

## Caveats
- Headless Chromium (especially in CI environments) can sometimes cap or throttle FPS artificially, leading to flaky >= 55 FPS assertions. Implementation should consider a slightly forgiving threshold (e.g., `>= 45-50` FPS on CI) or provide a fallback.
- `page.mouse.wheel` is step-based. Smooth scrolling should be explicitly triggered via `window.scrollTo({ behavior: "smooth" })` to test scroll animations correctly.

## Conclusion

### 1. Playwright 60 FPS / Performance Verification Strategy
The worker should implement two core helper functions in a utils file (or inside the test blocks):
```typescript
export async function measureFPS(page: Page, durationMs: number = 1000): Promise<number> {
  return await page.evaluate((duration) => {
    return new Promise<number>((resolve) => {
      let frameCount = 0;
      let startTime = performance.now();
      const countFrame = (time: number) => {
        frameCount++;
        if (time - startTime < duration) requestAnimationFrame(countFrame);
        else resolve((frameCount * 1000) / (time - startTime));
      };
      requestAnimationFrame(countFrame);
    });
  }, durationMs);
}

export async function detectLongTasks(page: Page, durationMs: number = 1000): Promise<number> {
  return await page.evaluate(async (duration) => {
    return new Promise<number>((resolve) => {
      let count = 0;
      const observer = new PerformanceObserver((list) => count += list.getEntries().length);
      observer.observe({ entryTypes: ['longtask'] });
      setTimeout(() => { observer.disconnect(); resolve(count); }, duration);
    });
  }, durationMs);
}
```

### 2. Test Cases for `e2e/ui.spec.ts`
**Tier 1 (Happy Path - 5 Tests)**
1. **Magnetic Button Hover**: Hover over a `MobileReadyNav` item. Verify the inline `style` updates with `transform: translate(...)` values.
2. **Scroll Float Initial State**: Navigate to `/services`. Verify that the `ScrollFloat` container text is initially hidden/transformed out of view.
3. **Scroll Float Reveal**: Scroll to the `ScrollFloat` component and verify it becomes fully visible (opacity 1).
4. **Hero Background Noise**: Verify `.mix-blend-overlay` element exists on the Homepage and does not block pointer events (`pointer-events: none`).
5. **Idle 60 FPS**: Run `measureFPS` on the idle homepage and verify FPS >= 50.

**Tier 2 (Boundaries/Edge Cases - 5 Tests)**
1. **Magnetic Button Reset**: Move the mouse rapidly across the nav button and out. Wait 500ms. Verify it returns exactly to `translate(0px, 0px)`.
2. **Scroll Spam**: Dispatch multiple rapid `scrollBy` events. Verify no unhandled exceptions are thrown and animations stabilize.
3. **No Long Tasks on Initial Load**: Use `detectLongTasks` during the first 2 seconds of the homepage load. Assert count is `0`.
4. **Smooth Scroll FPS**: Trigger a smooth scroll down the homepage for 2 seconds. Concurrently run `measureFPS`. Verify FPS >= 50.
5. **MetaBalls Load Integrity**: Wait for `MetaBalls` canvas/component to become visible on the hero section. Measure FPS to ensure the complex animation does not thrash the CPU.

**Tier 3 (Interactions - 2 Tests)**
1. **Nav Interaction + Route Transition**: Click a magnetic nav link and immediately measure CLS during the page load transition to verify UI teardown doesn't cause layout shifts.
2. **Language Switch Animation Stability**: Switch language while `ScrollFloat` elements are in view. Verify their opacity remains `1` and text updates cleanly.

### 3. Test Cases for `e2e/scenarios.spec.ts` (Tier 4)
1. **Scenario 1 (The Full Funnel)**: Load Home (verify LCP < 1.5s via DevTools or LH). Scroll smoothly to trigger Hero animations (measure FPS). Hover over the Magnetic "Contact" CTA, click it. Verify the new page has correct `robots.txt` access and JSON-LD schema.
2. **Scenario 2 (Services Deep Dive)**: Navigate to `/services`. Verify Canonical tags match. Smoothly scroll to the bottom, validating `ScrollFloat` triggers without long tasks (>50ms). Navigate to a sub-service and verify the `<title>` updates.
3. **Scenario 3 (Mobile Engagement)**: Set viewport to `Mobile Chrome` (375x667). Click the hamburger menu. Verify the menu opens smoothly (measure FPS during the `isOpen` transition). Select a link, verify navigation without CLS.
4. **Scenario 4 (404 to Home Recovery)**: Visit `/invalid-url`. Ensure custom 404 renders. Click the magnetic "Zur Startseite" button. Verify the homepage fully loads its Heavy animations (MetaBalls) and restores the correct SEO canonical tag.
5. **Scenario 5 (Heavy Scroll + Interaction)**: On the homepage, trigger an automated slow scroll from top to footer. While scrolling, trigger `detectLongTasks`. Validate that crossing multiple components does not cause blocking JS, and finally click the Sitemap/Robots link in the footer.

## Verification Method
- **Implementer**: The Worker agent should create `e2e/ui.spec.ts` and `e2e/scenarios.spec.ts` mapping directly to these 17 tests.
- **Verification**: Run `npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts`. All tests should pass without timeouts, proving the animations are smooth and the integration of SEO/Perf/UI is stable.
