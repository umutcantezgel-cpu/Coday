# Explorer 2 Handoff Report - Iteration 2 (Forensic Audit Recovery)

## 1. Observation
I reviewed the Auditor Report and the corresponding test files (`e2e/ui.spec.ts` and `e2e/scenarios.spec.ts`) to locate the exact integrity violations:

*   **Faked LCP (`e2e/scenarios.spec.ts:16-34`)**: `lcpValue` is initialized to `0`. If the `PerformanceObserver` does not fire a `largest-contentful-paint` event within 1000ms, the promise resolves to `0`. The assertion `expect(Number(lcp)).toBeLessThan(5000)` inherently passes.
*   **Faked FPS Tracking (`e2e/ui.spec.ts:31-48`)**: The `trackPerformance` function executes performance evaluation, but the subsequent assertions for `fps` and `longFrames` are wrapped in an `if (frameTimes && frameTimes.length > 0)` block. If no frames are tracked, the assertions are entirely skipped.
*   **Facade Test Conditionals**: Widespread use of `if (await locator.count() > 0)` across both files. 
    *   `e2e/ui.spec.ts`: Lines 59-60 (`.custom-cursor`), Line 166 (`a[href="/about"]`).
    *   `e2e/scenarios.spec.ts`: Line 42 (`servicesLink`), Lines 56-66 (`form`, `nameInput`, `emailInput`, `submitBtn`), Line 81 (`mobileMenuBtn`), Line 91 (`canonical`), Line 111 (`aboutLink`), Line 132 (`enSwitch`).

## 2. Logic Chain
To enforce strict test integrity according to the Scope Document, tests must objectively pass or fail based on the application's actual state. If a feature or element is missing, the test MUST fail, not skip gracefully.

*   **LCP Fix Logic**: To stop the artificial passing, the test must actively expect a valid LCP time. If the timeout triggers before an LCP event, it should throw an error or resolve to a value (e.g., `null`) that will explicitly fail the `expect`. We must also assert that `lcp` is strictly greater than `0`.
*   **FPS Fix Logic**: To ensure performance metrics are genuinely recorded, the existence of tracked frames must be a hard requirement. By removing the conditional block and directly asserting `expect(frameTimes.length).toBeGreaterThan(0)`, any failure in the `requestAnimationFrame` loop will immediately fail the test.
*   **Facade Fix Logic**: The `locator.count() > 0` condition acts as an optional try-catch block for features that don't exist yet. By stripping these `if` statements and directly invoking Playwright interactions (e.g., `.click()`, `.hover()`) or assertions (`expect(locator).toBeVisible()`), Playwright's built-in auto-waiting and timeout mechanisms will properly fail the test with a `TimeoutError` if the element is not found.

## 3. Caveats
*   Because we are removing the "safety nets," the E2E tests will begin failing on CI and locally if the application does not yet implement the required UI components (e.g., `.custom-cursor`, `#magnetic-btn`, forms). This is the intended behavior of an opaque-box test, but the team should be prepared for the test suite to go red until features are implemented.
*   The `trackPerformance` function relies on `requestAnimationFrame`. If the page is completely frozen, it will log 0 frames. The new fix logic will rightly fail this instead of silently passing.

## 4. Conclusion
The integrity violations were caused by protective code that bypassed assertions when target elements or metrics were absent.

**Recommended Fix Strategy:**
1.  **`e2e/scenarios.spec.ts` (LCP)**: Remove the `lcpValue = 0` fallback. Have the `setTimeout` resolve to `null` or reject the promise. Add assertions: `expect(lcp).not.toBeNull()` and `expect(Number(lcp)).toBeGreaterThan(0)`.
2.  **`e2e/ui.spec.ts` (FPS Tracking)**: Remove the `if (frameTimes && frameTimes.length > 0)` wrapper in `trackPerformance`. Assert unconditionally: `expect(frameTimes.length).toBeGreaterThan(0)`, followed by the `fps` and `longFrames` assertions.
3.  **Both Files (Facade Removal)**: Delete every instance of `if (await locator.count() > 0)`. Unconditionally execute the code block inside the `if` statement (e.g., `await locator.click()`). 

## 5. Verification Method
1.  Run `npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts`.
2.  Verify that tests fail with `TimeoutError` or explicit assertion failures rather than passing.
3.  Manually inspect the codebase using `grep -r "count() > 0" e2e/` to confirm 0 instances remain.
4.  Manually inspect the LCP block to ensure `0` is not being passed.
