# E2E Testing M3 UI - Explorer 1 Iteration 4 Report

## 1. Observation
The E2E tests are failing due to a mix of brittle DOM locators, incorrect expectations of React component structures, and missing explicit waits for navigation events, as observed in both Challenger reports:
1. `scenarios.spec.ts:46` - Services Navigation fails. `a[href="/de/services"]` doesn't exist; the top-level Services item is a dropdown toggle (`<button>`).
2. `scenarios.spec.ts:114` - JS Disabled Navigation fails. URL assertion evaluates prematurely because `waitForLoadState('domcontentloaded')` resolves against the *current* page state during a full-page reload.
3. `scenarios.spec.ts:135` - Language Switcher timeout. Locating by `button:has-text("EN")` fails because the button dynamically renders the *current* language text ("DE") with an `aria-label` used for the target language.
4. `ui.spec.ts:60` - Custom Cursor fails. It expects a `.custom-cursor` class, but `CustomCursor.tsx` applies raw Tailwind classes instead (e.g. `.pointer-events-none`).
5. `ui.spec.ts:89` - Scroll Reveal execution fails. Hardcoded `window.scrollTo(0, 5000)` instantly jumps, which sporadically fails to trigger `whileInView` animations. Reading opacity with an immediate `evaluate()` misses auto-retries.
6. Server Timeouts / `fullyParallel` mode issues. Running multiple tests on `localhost:3004` concurrently causes dev server timeouts (`test timeout of 30000ms exceeded`).

## 2. Logic Chain
- **Issue 1 (Services Nav):** We must update the test to interact with the dropdown. Hover over or click the "Leistungen" button, then click a valid submenu link like `/de/services/web-development`.
- **Issue 2 (Navigation Race):** To correctly wait for a non-JS full-page reload, we need to bind the click event and navigation wait simultaneously using `Promise.all([botPage.waitForNavigation(), aboutLink.click({ force: true })])`.
- **Issue 3 (Language Switcher):** The switcher should be located by its semantic purpose. Using `page.locator('button[aria-label*="Switch to"]')` or `page.getByRole('button', { name: /Switch to English|Auf Deutsch/i })` ensures resilience against UI text changes.
- **Issue 4 (Custom Cursor):** Since the component doesn't have the `.custom-cursor` class, the locator in `ui.spec.ts` must be updated to target the existing DOM footprint: `page.locator('div.pointer-events-none.z-\\[9999\\]').first()` (or we add a class to the React component).
- **Issue 5 (Scroll Reveal):** We should replace `window.scrollTo` with `locator.scrollIntoViewIfNeeded()`. Then, we must replace the synchronous `.evaluate()` opacity check with Playwright's native auto-retrying web assertions: `await expect(targetSpan).toHaveCSS('opacity', '1')` (or a value > 0 if fractional).
- **Issue 6 (Parallel Execution):** Limiting concurrent workers in `playwright.config.ts` prevents the Vite server from buckling under load. Set `workers: 1` or `workers: 2` (or disable `fullyParallel`).

## 3. Caveats
- I am exclusively investigating and providing a strategy. I have not applied these code modifications.
- Some localized link text matching (e.g. "Leistungen" vs "Services") might differ depending on the initialized default locale during the test run. Using semantic roles and `href` matching mitigates this.

## 4. Conclusion
The tests should be fundamentally updated to adhere to best practices for Playwright. The fix strategy primarily targets `e2e/scenarios.spec.ts`, `e2e/ui.spec.ts`, and `playwright.config.ts`. The focus is on using Playwright's robust location methods (`getByRole` or `aria-label`), ensuring correct `Promise.all` logic for network navigation, and relying on native auto-retrying assertions instead of manual DOM evaluation.

## 5. Verification Method
1. The Implementer applies the changes described above.
2. Run `npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts` locally.
3. Observe all tests pass without flaky timeouts or locator errors.
