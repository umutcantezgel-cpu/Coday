# Explorer Report: Milestone 3 - UI/UX & Scenarios Tests

## 1. Observation
- **Requirements**: `ORIGINAL_REQUEST.md` specifies "Awwwards-Level UI/UX Animationen" (Feature 4) which include Micro-interactions (Magnetic Buttons, Scroll-Tracking, Custom Cursor) that must not block render (JS tasks < 50ms) and must run at ≥ 60 FPS.
- **Test Infrastructure**: `SCOPE.md` and `TEST_INFRA.md` dictate Opaque-box testing using Playwright with a Tiered structure (Tier 1-4). Tiers 1-3 go to `e2e/ui.spec.ts` (Feature 4), Tier 4 goes to `e2e/scenarios.spec.ts`.
- **Application State**: Examination of `src/shared/ui/` reveals multiple target components for animation testing: `Magnetic.tsx`, `CustomCursor.tsx`, `ScrollReveal.tsx`, `FlowingMenu.tsx`, `GooeyNav.tsx`, and `ClickSpark.tsx`.
- **Current Tests**: The `e2e/` directory contains `home.spec.ts` and `temp-perf.spec.ts` but does not currently have `ui.spec.ts` or `scenarios.spec.ts`.

## 2. Logic Chain & Recommended Test Design

### A. Playwright 60 FPS & Performance Verification Strategy
To measure 60 FPS (approx. 16.6ms per frame) and block-rendering tasks (< 50ms) via Playwright opaque-box testing, the implementer should use a dual approach:
1. **In-Page `requestAnimationFrame` Tracker (For FPS)**:
   Inject a script via `page.evaluate()` prior to an action (like scrolling) that tracks frame timestamps over a set duration.
   ```typescript
   // Example Injection
   await page.evaluate(() => {
     window.frameTimes = [];
     let last = performance.now();
     const loop = () => {
       const now = performance.now();
       window.frameTimes.push(now - last);
       last = now;
       if (window.isTracking) requestAnimationFrame(loop);
     };
     window.isTracking = true;
     requestAnimationFrame(loop);
   });
   // ... Perform UI action ...
   // Evaluate window.frameTimes to ensure 95th percentile is <= 16.6ms.
   ```
2. **Chrome DevTools Protocol (CDP) Tracing (For Long Tasks)**:
   Attach a CDP session to track long tasks (> 50ms) that might block the main thread.
   ```typescript
   const client = await page.context().newCDPSession(page);
   await client.send('Performance.enable');
   // ... perform action ...
   // Retrieve metrics or use Tracing API to scan for 'TaskDuration' > 50ms.
   ```

### B. `e2e/ui.spec.ts` - Tier 1-3 (UI/UX Micro-interactions)

**Tier 1: Positive/Basic Functionality (≥ 5 tests)**
1. **Custom Cursor Render**: Verify the custom cursor DOM element follows the physical mouse coordinates (`page.mouse.move()`) accurately.
2. **Magnetic Button Transform**: Hover over a `Magnetic` button and verify CSS `transform: translate3d(...)` applies correctly.
3. **Scroll Reveal Execution**: Scroll down the page and verify elements wrapped in `ScrollReveal` transition from `opacity: 0` to `opacity: 1`.
4. **Gooey Nav Activation**: Click the menu trigger and verify the `GooeyNav` overlay becomes visible and animated.
5. **Click Spark Generation**: Click on the body and verify the `ClickSpark` SVG/canvas generates elements at the precise click coordinates.

**Tier 2: Boundary & Edge Cases (≥ 5 tests)**
1. **Rapid Interaction (Spam Click/Hover)**: Rapidly trigger hover states on a Magnetic Button 20 times; verify it eventually settles at `translate3d(0,0,0)` and doesn't get stuck out of bounds.
2. **Fast Scrolling Constraints**: Emulate an extreme fast scroll (`window.scrollTo({top: 10000})`) and verify all bypassed `ScrollReveal` elements still become fully visible.
3. **Viewport Resize Resilence**: Resize the browser during an active `FlowingMenu` animation and ensure layout bounds recalculate without overflow.
4. **Reduced Motion Compliance**: Emulate `prefers-reduced-motion: reduce` and verify CSS/JS animations are disabled or minimized.
5. **Main Thread Blocking**: Perform a heavy UI interaction (open menu, scroll rapidly) and use CDP to assert no JS task exceeds 50ms (Zero render-blocking tasks).

**Tier 3: Pairwise & Integration (≥ 3 tests)**
1. **Menu + Scroll Interference**: Open the `GooeyNav` overlay while simultaneously scrolling the page; verify the overlay stays fixed and scroll events do not break it.
2. **Cursor + Magnetic Target + Spark**: Hover a `Magnetic` button (Cursor changes state), then click it (ClickSpark fires). Ensure all three animations coalesce seamlessly without visual errors.
3. **Deep Link Load + Reveal**: Directly load a URL deep in the page (`/about#team`) and verify that in-viewport elements render instantly while above-viewport elements remain visually consistent.

### C. `e2e/scenarios.spec.ts` - Tier 4 (Real-World Scenarios)

**Tier 4: Complex Multi-Feature Workloads (≥ 5 tests)**
1. **The Organic Search Arrival (SEO + UI + Perf)**
   - *Flow*: Throttle network (Fast 3G), load the Homepage. Verify Server-side JSON-LD is present, check LCP is < 1.5s, scroll down triggering 60 FPS animations, and navigate to the Services page.
2. **The High-Converting Lead (UI + Perf)**
   - *Flow*: User lands on the page, opens the `GooeyNav`, uses the `CustomCursor` to fill out a contact form, and clicks submit. Measure Interaction to Next Paint (INP) to ensure smooth input handling despite active background animations.
3. **The Mobile Explorer (Responsive + UI + SEO)**
   - *Flow*: Load site in a mobile viewport. Verify that desktop-only animations (like Custom Cursor) are disabled, mobile hamburger menu works, and canonical tags correctly point to the base URL without mobile query params.
4. **The Bot Crawl (JS Disabled)**
   - *Flow*: Disable JavaScript in Playwright context. Navigate through Homepage -> About -> Services. Verify that SSR renders all text content, `<title>`, `<meta>` tags, and semantic HTML (`<h1>`, `<h2>`) to ensure pure technical SEO integrity.
5. **The Internationalization Switch (SEO + UI)**
   - *Flow*: Load `/de`. Validate German JSON-LD and title tags. Switch the language toggler to `/en`. Verify the route changes seamlessly, animations reset gracefully, and the `<html lang="en">` attribute updates.

## 3. Caveats
- **CI Environment Limits**: Headless browsers in CI (like GitHub Actions) typically do not have a real GPU. Achieving exactly 60 FPS in a virtualized CI environment can be flaky. The implementer should set a slightly looser threshold (e.g., ~45-50 FPS average) in CI environments or skip the exact FPS assertion on purely headless Linux without a GPU, focusing instead on the absence of >50ms JS long-tasks.
- **`requestAnimationFrame` Mocking**: Playwright test timings may vary. Relying on `performance.now()` in `evaluate` is accurate enough for rough estimates, but Chrome Trace files (via CDP) are the single source of truth.

## 4. Conclusion
The application is structured well for UI testing with discrete components in `src/shared/ui`. By employing `requestAnimationFrame` tracking and CDP Tracing, the implementer can programmatically enforce the 60 FPS and <50ms requirements. Creating `e2e/ui.spec.ts` and `e2e/scenarios.spec.ts` with the detailed tests above will fulfill Milestone 3's requirements for Tier 1-4 coverage.

## 5. Verification Method
- **Implementer Action**: The implementer agent should create the files, inject the 60FPS tracking logic, and write the outlined Playwright specs.
- **Test Command**: `npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts`
- **Validation**: All tests must pass, and the report should log frame duration percentiles or throw failures if dropped frames or >50ms tasks are detected.
