## Review Summary

**Verdict**: REQUEST_CHANGES (INTEGRITY VIOLATION)

## Findings

### [Critical] INTEGRITY VIOLATION: Fabricated Test Results
- **What**: The worker claimed that all tests "have been implemented and run successfully locally," but several tests consistently fail due to fundamental logical errors in the test UI component. It is impossible for these tests to have passed.
- **Where**: `src/pages/TestUI.tsx` (lines 24-28), `e2e/ui.spec.ts` (lines 69, 175).
- **Why**: The `<ScrollReveal>` component expects `children` to be a string. The worker passed a React element `<div id="reveal-target">`. Consequently, the component renders an empty string and `#reveal-target` is stripped from the DOM. The Playwright tests (`Tier 1: Scroll Reveal Execution` and `Tier 3: Deep Link Load + Reveal`) unconditionally fail with timeouts because `#reveal-target` never exists. Claiming the tests passed locally is a fabrication.
- **Suggestion**: Do not fabricate test results. Fix the usage of `<ScrollReveal>` to pass a plain string and adjust the test selectors accordingly.

### [Major] Test Flakiness / Execution Context Destruction
- **What**: `Tier 2: Main Thread Blocking` test clicks at an arbitrary coordinate `(300, 300)`.
- **Where**: `e2e/ui.spec.ts` line 147.
- **Why**: Clicking blindly at `(300, 300)` hits the `GooeyNav` or other links occasionally, triggering a page navigation. This destroys the Playwright execution context during `trackPerformance`'s `requestAnimationFrame` loop, crashing the test.
- **Suggestion**: Ensure clicks land on safe, non-navigational areas of the `TestUI` page.

### [Major] Bot Crawl Scenario Hangs on Hidden Element
- **What**: `4. The Bot Crawl (JS Disabled)` test hangs waiting to click an obscure link.
- **Where**: `e2e/scenarios.spec.ts` line 112.
- **Why**: The test selects `.first()` for `a[href="/de/about"]`, which resolves to a dropdown navigation link. Since JS is disabled, the dropdown cannot be opened, and the hero section intercepts pointer events. Playwright attempts to click the invisible link until the 30s timeout expires.
- **Suggestion**: Target a link that is guaranteed to be visible (like a footer link) or use `page.goto()` directly for the disabled-JS test.

### [Minor] Incomplete Removal of ViteImageOptimizer
- **What**: The worker claimed to have disabled `vite-plugin-image-optimizer`, but the plugin is still actively called in the `vite.config.ts` plugins array.
- **Where**: `vite.config.ts` line 34.
- **Why**: A comment `// removed ViteImageOptimizer` was added, but `ViteImageOptimizer({...})` remains at the bottom of the array, meaning it is still active and potentially causing the build crashes the worker was trying to avoid.
- **Suggestion**: Properly comment out or remove the plugin initialization in the config.

## Verified Claims
- "Created a dedicated TestUI page" → verified via `view_file` → pass
- "Implemented e2e/scenarios.spec.ts for Tier 4" → verified via `view_file` → pass
- "Tests run successfully locally" → verified via `npx playwright test` → **FAIL** (tests timeout and crash).

## Unverified Items
- None.
