# E2E Testing M3 UI - Explorer 3 Iteration 4 Report

## 1. Observation
Based on the Challenger reports from Iteration 3 and direct code inspection, the E2E test failures map to 6 distinct issues:
1. **Stale Locator (Services Link):** `scenarios.spec.ts:46` fails to find `a[href="/de/services"]`. The application's `MobileReadyNav` uses a `<button>` that reveals a dropdown of specific service links, rather than a top-level anchor tag.
2. **Race Condition (JS Disabled Bot Crawl):** `scenarios.spec.ts:114` fails the URL assertion. The test calls `botPage.waitForLoadState('domcontentloaded')` immediately after clicking a link in a JS-disabled environment, which resolves instantly on the *current* page before the new navigation finishes.
3. **Flawed Locator (Language Switcher):** `scenarios.spec.ts:135` looks for `button:has-text("EN")`, but the `LanguageSwitcher` button displays the *current* language (e.g. "DE").
4. **Missing Class (Custom Cursor):** `ui.spec.ts:60` looks for a `.custom-cursor` class. However, `CustomCursor.tsx` applies inline styles and Tailwind utilities without a semantic class or test ID.
5. **Animation Bypass (Scroll Reveal):** `ui.spec.ts:89` instantly sets the scroll position to 5000 via `window.scrollTo` and checks opacity once. This bypasses framer-motion's viewport triggers and Playwright's auto-retrying assertions.
6. **Parallel Server Overload:** `playwright.config.ts` runs tests with `fullyParallel: true` using multiple workers, crashing the Vite dev server under heavy concurrent load (resulting in `ENOTEMPTY` errors and 30000ms timeouts).

## 2. Logic Chain
1. **Scenario 1:** The app architecture uses an animated dropdown navigation menu (`MobileReadyNav.tsx`); the test assumes a static `href` link on the top level. The test needs to locate the dropdown trigger button, hover/click it, and then target a nested service link (e.g., `a[href*="/services/"]`).
2. **Scenario 4:** When JS is disabled, clicking a link causes the browser to perform a synchronous full navigation. Calling `waitForLoadState` sequentially does not wait for the *new* navigation event. `Promise.all([waitForNavigation(), click()])` is required.
3. **Scenario 5:** The language switcher's visual text represents the active state, not the target state. The test must locate the switcher via `aria-label` or role instead of its inner text.
4. **UI Tier 1 (Cursor):** `CustomCursor.tsx` manages `motion.div` elements. Adding a `data-testid="custom-cursor"` is the standard way to expose these elements to opaque-box tests without relying on implementation-specific utility classes.
5. **UI Tier 1 (Scroll):** Framer motion relies on `IntersectionObserver` via `whileInView`. Hard scroll jumps can fail to register. Using Playwright's native `scrollIntoViewIfNeeded()` and `expect(locator).toHaveCSS('opacity', '1')` allows the test to auto-retry until the animation completes.
6. **Timeouts:** The local Vite SSR server cannot handle ~7 parallel workers rapidly requesting routes and assets simultaneously. Limiting workers locally stabilizes the test execution environment.

## 3. Caveats
- No caveats. The findings from both Challenger reports directly align with the application code (`CustomCursor.tsx`, `MobileReadyNav.tsx`, `playwright.config.ts`) and test files (`ui.spec.ts`, `scenarios.spec.ts`).

## 4. Conclusion
The E2E suite requires structural updates to align with the application's true DOM behavior. The recommended fix strategy is:

1. **App fix:** Add `data-testid="custom-cursor"` to the outer circle `motion.div` in `src/shared/ui/CustomCursor.tsx`.
2. **Config fix:** Update `playwright.config.ts` to set `workers: process.env.CI ? 1 : 1` (or a low number like 2) and disable `fullyParallel` for the UI suite to stabilize the local dev server.
3. **Test logic fix (scenarios.spec.ts):**
   - **Scenario 1:** Refactor the Services navigation to locate the nav button (`page.getByRole('button', { name: /services|leistungen/i })`), reveal the dropdown, and click a nested link `a[href*="/services/"]`.
   - **Scenario 4:** Wrap the bot crawl click in `Promise.all([botPage.waitForNavigation(), aboutLink.click({ force: true })])`.
   - **Scenario 5:** Locate the language switcher using an `aria-label` or class rather than strict text content.
4. **Test logic fix (ui.spec.ts):** 
   - **Scroll Reveal:** Use `await targetSpan.scrollIntoViewIfNeeded()` and `await expect(targetSpan).toHaveCSS('opacity', '1')` instead of manual `window.scrollTo` and `evaluate` opacity checks.
   - **Custom Cursor:** Update the locator to `page.getByTestId('custom-cursor')`.

## 5. Verification Method
1. The Implementer should apply the above code changes to the application and test files.
2. Run the tests using:
   ```bash
   npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts
   ```
3. Ensure the test run completes with 0 failures and no Vite server timeouts.
