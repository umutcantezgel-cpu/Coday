# E2E Testing M3 UI - Fix Strategy Report

## 1. Observation
After reviewing both Challenger reports and the source code, I verified 6 distinct failure points in the E2E UI/Scenarios test suite:
1. **`scenarios.spec.ts:46` (Organic Search):** `a[href="/de/services"]` is not found on the homepage. `MobileReadyNav.tsx` uses a dropdown button for Services, not a direct link to an index page.
2. **`scenarios.spec.ts:114` (Bot Crawl, JS Disabled):** Fails URL assertion because `aboutLink.click()` triggers an immediate page reload (since JS is disabled), and `botPage.waitForLoadState('domcontentloaded')` executes sequentially *after*, immediately passing on the current page before navigation actually finishes.
3. **`scenarios.spec.ts:135` (Internationalization):** Fails locating `button:has-text("EN")`. `LanguageSwitcher.tsx` renders the *current* language text ("DE" in German), not the target language text.
4. **`ui.spec.ts:60` (Custom Cursor Render):** Fails locating `.custom-cursor`. `src/shared/ui/CustomCursor.tsx` applies Tailwind utility classes but does not append the `.custom-cursor` class.
5. **`ui.spec.ts:89` (Scroll Reveal Execution):** Evaluated opacity is `0.1` instead of `> 0.5`. Tests instantly jump to `5000px`, bypassing normal viewport intersection, and read the `opacity` instantly via `.evaluate()`, bypassing Playwright's auto-retries.
6. **Parallel Execution Timeouts:** `playwright.config.ts` uses `fullyParallel: true` but relies on an external/unmanaged Dev Server which crashes under high concurrent load (7 workers).

## 2. Logic Chain
1. **Organic Search Arrival**: Since there is no standalone `/de/services` link, the test should mirror user behavior by opening the Services dropdown in the header and clicking a specific sub-service, like Web Development.
2. **JS Disabled Navigation**: To avoid race conditions, Playwright requires awaiting both the navigation and the click simultaneously using `Promise.all()`.
3. **Language Switcher Locator**: The switcher button's text is dynamic and reflects the *active* language, making a hardcoded text lookup brittle. The `title` attribute (`title="Switch Language"`) is stable across states.
4. **Custom Cursor**: Since opaque-box testing requires identifiable elements, adding the missing `.custom-cursor` class to the application's `CustomCursor.tsx` component is the most direct and semantic fix.
5. **Scroll Reveal Logic**: Testing animations requires robust auto-retrying assertions instead of single-point DOM readings. Using `scrollIntoViewIfNeeded()` ensures the viewport trigger fires, and `toHaveCSS` ensures Playwright polls the DOM until the animation completes.
6. **Dev Server Load**: Reducing local Playwright workers to `1` or `2`, or moving to a production build via a `webServer` block in `playwright.config.ts`, will stabilize the test suite.

## 3. Caveats
- I did not test the fixes directly as my role is strictly read-only Explorer.
- Changing `workers: 1` might increase total test execution time, but it guarantees stability until the CI environment handles optimized production builds.

## 4. Conclusion
The E2E failures stem from a mix of stale/incorrect locators, flawed navigation/assertion logic, and one missing CSS class in the app.

**Recommended Fixes for the Implementer:**
1. **Fix Application Code (`src/shared/ui/CustomCursor.tsx`)**:
   Add `className="custom-cursor ..."` to the outer `<motion.div>` (the Outer Circle).
2. **Fix `scenarios.spec.ts`**:
   - *Line 46*: Change to click the dropdown trigger (`page.locator('button', { hasText: /Services|Leistungen/ })`), then click the `a[href$="/services/web-development"]` link, and assert for `**/services/web-development`.
   - *Line 114*: Replace sequential wait with `await Promise.all([botPage.waitForNavigation(), aboutLink.click({ force: true })]);`.
   - *Line 135*: Change the locator to `page.locator('button[title="Switch Language"]').first()`.
3. **Fix `ui.spec.ts` (All Scroll Reveal/Fast Scrolling tests)**:
   - Replace `window.scrollTo(0, 5000)` with `await target.scrollIntoViewIfNeeded()`.
   - Replace manual `.evaluate()` opacity checks with Playwright assertions: `await expect(targetSpan).toHaveCSS('opacity', '1')` or `not.toHaveCSS('opacity', '0.1')`.
4. **Fix `playwright.config.ts`**:
   - Set `workers: process.env.CI ? 1 : 2` to alleviate local dev server crashes.

## 5. Verification Method
After applying the fixes, run:
```bash
npx playwright test e2e/ui.spec.ts e2e/scenarios.spec.ts
```
The suite should complete successfully without timeout or locator errors.
