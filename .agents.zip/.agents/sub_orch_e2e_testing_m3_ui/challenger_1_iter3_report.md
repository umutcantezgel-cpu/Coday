# Empirical Challenge Report: E2E Testing M3

## Challenge Summary

**Overall risk assessment**: HIGH 

The implemented tests are highly brittle and suffer from severe assumption failures regarding the application's DOM structure, component behavior, and Playwright execution mechanics. Almost all tests fail when run against the actual implementation due to mismatched locators, race conditions, and incorrect test paradigms (e.g., evaluating state immediately instead of using Playwright's auto-retrying assertions). Furthermore, the webServer setup is prone to crashing under parallel load.

## 1. Observation
When executing the test suites using Playwright, multiple failures occurred across `ui.spec.ts` and `scenarios.spec.ts`:
- **Custom Cursor Render:** Failed with `Timeout 5000ms: element(s) not found` for `locator('.custom-cursor').first()`.
- **Scroll Reveal Execution:** Failed with `Expected: > 0.5, Received: 0.1` for opacity check.
- **The Bot Crawl (JS Disabled):** Failed with `Expected substring: "about", Received string: "http://127.0.0.1:3006/de"`.
- **The Internationalization Switch:** Failed with timeout when trying to click `button:has-text("EN")`.
- **The Organic Search Arrival:** Failed with `element(s) not found` for `locator('a[href="/de/services"], a[href="/de/leistungen"]')`.
- Running both test files simultaneously caused Vite build errors (`ENOTEMPTY`) and server crashes (`net::ERR_CONNECTION_REFUSED`).

## 2. Logic Chain

1. **Custom Cursor DOM:** `CustomCursor.tsx` uses Tailwind classes and inline styles but does *not* apply a `.custom-cursor` class. The test assumes a class that doesn't exist.
2. **Scroll Reveal viewport triggering:** The test executes `window.scrollTo(0, 5000)` instantly and waits 1000ms, then reads the opacity via `evaluate()`. Framer motion's `whileInView` with `margin: "-10%"` and its 0.8s animation duration might not complete or trigger correctly on instant scroll jumps. `evaluate()` reads it exactly once (returning the initial `0.1`), bypassing Playwright's auto-retrying capabilities.
3. **Services Link Navigation:** `MobileReadyNav.tsx` uses a `<button>` for the "Services" category that reveals a dropdown. There is no direct `<a>` tag with `href="/de/services"`, causing the test to timeout.
4. **Language Switcher Text:** `LanguageSwitcher.tsx` renders the *current* language text inside the button (e.g., "DE" when viewing the German version). The test attempts to find a button with text "EN", which doesn't exist until the language is actually English.
5. **JS Disabled Navigation Race Condition:** In the bot crawl test, `aboutLink.click()` triggers a full-page reload because JS is disabled. The subsequent `botPage.waitForLoadState('domcontentloaded')` immediately resolves because the *current* page is already loaded, leading the test to check the URL before the new page has loaded.
6. **Parallel Execution Conflict:** `playwright.config.ts` tries to build and start the Vite dev server on port 3006. Running multiple tests with high worker counts or running the suites simultaneously overloads the Vite SSR server, causing timeouts (`Test timeout of 30000ms exceeded while running "beforeEach" hook`).

## 3. Caveats
- I did not test fixing the UI components to match the tests. As a reviewer, I am assuming the UI components are the source of truth and the tests are flawed (since they are opaque-box tests). 
- I analyzed the test behavior locally. In a CI environment, the server timeouts might be even more pronounced due to lower CPU power.

## 4. Conclusion
The E2E tests are failing due to flawed assumptions about the DOM structure and race conditions. The tests must be rewritten to rely on actual `data-testid`s or semantic roles (like `aria-label`), use Playwright's auto-retrying web assertions (e.g., `expect(locator).toHaveCSS()`) instead of manual `evaluate()` scripts, and correctly handle full-page navigations using `Promise.all([page.waitForNavigation(), action()])`.

### Recommended Mitigations
- **Challenge 1:** Add a `data-testid="custom-cursor"` or locate it by its inline styles.
- **Challenge 2:** Use `expect(locator).toHaveCSS('opacity', '1')` and simulate real scrolling instead of instantly jumping to `5000`.
- **Challenge 3:** Click the Services nav button to open the dropdown, then click the desired sub-link.
- **Challenge 4:** Target the language switcher by `aria-label` (e.g., `button[aria-label*="Switch to English"]`).
- **Challenge 5:** Use `Promise.all([botPage.waitForNavigation(), aboutLink.click({ force: true })])`.

## 5. Verification Method
Run the tests manually to observe the failures:
`npx playwright test e2e/ui.spec.ts`
`npx playwright test e2e/scenarios.spec.ts`
Review the error logs in `test-results/` to confirm that the errors match the logic chain provided (e.g., `0.1` opacity, timeout waiting for `button:has-text("EN")`).
