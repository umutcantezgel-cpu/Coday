# E2E Testing Handoff Report

## Observation
1. In `e2e/seo.spec.ts`, multiple assertions for JSON-LD and Open Graph SEO tags were using `.first()` to bypass duplicate tags in the DOM. This masked critical duplicate tag issues.
2. In `playwright.config.ts`, the `webServer.command` was configured to `npm run build && npm run preview` and waiting on `localhost:4173`. Playwright couldn't serve the SSR application because `npm run start` (which uses `react-router-serve`) is the correct command, and it defaults to a random port unless `PORT=3006` is specified.
3. In `vite.config.ts`, `ViteImageOptimizer` was causing an `ENOENT` crash during the Rollup `closeBundle` phase because it was trying to optimize missing public assets. 

## Logic Chain
1. To implement STRICT requirement-driven tests, `.first()` logic was removed from `e2e/seo.spec.ts`. The locators are now checked with `toHaveCount(1)`. The application currently produces duplicate `meta` and `script` tags, which intentionally causes these tests to fail. This verifies the tests are capable of detecting Tier-1 SEO regressions.
2. The Playwright configuration was updated to `npm run build && PORT=3006 npm run start` on port `3006`. The server successfully boots and Playwright can connect to it instead of timing out.
3. `vite.config.ts` was updated to include `ViteImageOptimizer` selectively via the `!isSsrBuild` condition, AND `includePublic: false` was added to the optimizer options to prevent the `ENOENT` crash on missing public images during the Rollup build.

## Caveats
- The `e2e/seo.spec.ts` file now explicitly fails multiple tests due to the app's existing bug (which is the required state for the E2E track). Do not revert the E2E test strictness!

## Conclusion
The test infrastructure has been strictly realigned.
1. `playwright.config.ts` targets the real production SSR server output correctly on port 3006.
2. The `vite.config.ts` build successfully passes without `ViteImageOptimizer` crashing.
3. SEO E2E tests are intentionally failing where duplicate tags are present, providing the needed guardrails for the Implementation Track to come in and address the duplicate Open Graph and JSON-LD outputs in the React app.

## Verification Method
1. Run `npm run build && PORT=3006 npm run start` to see the site load on `http://localhost:3006`.
2. Run `npx playwright test e2e/seo.spec.ts`. The tests will start the server, and several tests (e.g. `Homepage has expected Open Graph tags`) will strictly fail because `toHaveCount(1)` expects exactly 1 match but finds multiple duplicates in the DOM.
