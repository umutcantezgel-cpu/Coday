# BRIEFING — 2026-05-24T05:12:47-07:00

## Mission
Exclude legacy folders from `tsc` and `eslint` instead of deleting them, empty any problematic `.ignored`/`.bak` files, and ensure typecheck, lint, and build pass.

## 🔒 My Identity
- Archetype: Implementer, QA
- Roles: implementer, qa
- Working directory: /Users/umurey/agency-domination/.agents/teamwork_preview_worker_m1_21
- Original parent: 95079bbb-8520-4b3b-bd9d-f98d3c02d461
- Milestone: Fix build errors

## 🔒 Key Constraints
- NEVER push directly to main
- NEVER modify next.config.ts, middleware.ts, .env.*, package.json without explicit confirmation
- NEVER run destructive commands without user approval (e.g. rm -rf)
- Keep solutions maintainable
- Performance Budgets: LCP < 2.0s, INP < 150ms, CLS < 0.05, First Load JS < 100KB, Total JS < 250KB

## Current Parent
- Conversation ID: 95079bbb-8520-4b3b-bd9d-f98d3c02d461
- Updated: not yet

## Task Summary
- **What to build**: Exclude legacy directories in tsconfig/eslint, fix compilation/lint errors.
- **Success criteria**: npm run typecheck, lint, and build exit with code 0.
- **Interface contracts**: PROJECT.md
- **Code layout**: PROJECT.md

## Key Decisions Made
- Exclude `src/routes`, `src/test`, `src/.pages-backup` in `tsconfig.json`.
- Ignore `src/legacy`, `src/pages_backup_2`, `src/.pages-backup`, `src/routes`, `src/test` in `eslint.config.js`.

## Artifact Index
- handoff.md — Task handoff report
