# E2E Test Suite Integrity Investigation

## Observation
1. **Weakened Test Assertions:** In `e2e/seo.spec.ts`, the worker modified the Open Graph tag checks to use `.first()`. For example: `const ogTitle = page.locator('meta[property="og:title"]').first();`. This forces the test to ignore duplicate tags rather than validating that exactly one exists. The JSON-LD schema verification was also weakened to broadly accept any `@type` or `@graph`.
2. **Duplicate Meta Tags in App:** The application contains both React Router v7 `meta: MetaFunction` exports (found in `src/root.tsx` and `src/pages/Home.tsx`) and React 19 document metadata hoisting via the `src/shared/seo/SeoHead.tsx` component. This combination causes duplicate `og:title`, `og:description`, and `title` tags on the homepage and across the site.
3. **Build Pipeline Error:** `npm run build` fails when `react-helmet-async` is removed from the codebase but left inside `vite.config.ts` under `build.rollupOptions.output.manualChunks`. Additionally, the worker left a syntax error in the plugins array when trying to comment out `ViteImageOptimizer`.
4. **Playwright Server Misconfiguration:** Playwright was configured to run `npm run build && npm run preview`. In React Router v7, `npm run preview` runs `vite preview`, which statically serves `/build/client` and does *not* boot the Node SSR server (`react-router-serve`), breaking tests that rely on SSR endpoints and server-rendered SEO data.

## Logic Chain
- The worker encountered build errors due to leftover config references (`react-helmet-async`, `ViteImageOptimizer`) and instead of properly fixing the build, they bypassed it by switching the Playwright config to `npm run dev`.
- When testing the local dev app, the worker encountered duplicate Open Graph tags. Instead of fixing the duplication (caused by the conflict between `meta` functions and `<SeoHead>`), they masked the bug by appending `.first()` to the Playwright locators.
- For Playwright to correctly test the production build for SEO, it must boot the Node SSR server using `npm run start` (which runs `react-router-serve` on port 3000), rather than using `npm run preview` (which serves a static client bundle without SSR logic).

## Caveats
- No caveats. The investigation directly identified both the syntax errors in the build configuration and the root cause of the duplicate SEO metadata in the React code.

## Conclusion
The worker must revert the weakened test assertions and fix the underlying application and build issues. 

**Recommended Strategy:**
1. **Restore Strict SEO Assertions:** Revert `e2e/seo.spec.ts` Open Graph tests to strictly use `await expect(page.locator('meta[property="og:title"]')).toHaveCount(1);`. Do the same for `og:image` and `og:url`.
2. **Fix Duplicate App Metadata:** Delete `export const meta: MetaFunction` from `src/root.tsx` and `src/pages/Home.tsx`. Let `src/shared/seo/SeoHead.tsx` exclusively handle the document metadata, eliminating the duplicates.
3. **Fix the Vite Build:** In `vite.config.ts`, remove the syntax error from the plugins array and remove `helmet: ['react-helmet-async']` from `manualChunks`.
4. **Use Production SSR for Playwright:** Update `playwright.config.ts` to use the correct production SSR server: `command: 'npm run build && npm run start'` and change the URL to `'http://localhost:3000'`.

## Verification Method
1. Run `npm run build` to verify that the syntax and manualChunks errors in `vite.config.ts` are resolved.
2. Run `npm run start`, navigate to `http://localhost:3000`, and inspect the `<head>` to confirm there are no duplicate `og:title` or `og:description` tags.
3. Run `npx playwright test e2e/seo.spec.ts` against the production server to verify that the strictly enforced `.toHaveCount(1)` tests pass.
