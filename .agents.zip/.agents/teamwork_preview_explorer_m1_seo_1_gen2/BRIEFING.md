# BRIEFING — 2026-05-23T03:38:42-07:00

## Mission
Investigate the SEO test integrity violations and recommend a fix strategy for the worker, focusing on strict assertions and fixing the Vite production build.

## 🔒 My Identity
- Archetype: Teamwork explorer
- Roles: Read-only investigator, analyzer, synthesizer
- Working directory: /Users/umurey/agency-domination/.agents/teamwork_preview_explorer_m1_seo_1_gen2
- Original parent: 65c19417-4f20-4c1c-913a-0ebd1d3d397b
- Milestone: SEO test iteration 2

## 🔒 Key Constraints
- Read-only investigation — do NOT implement
- Ensure tests STRICTLY enforce Tier 1-3 SEO requirements (do not weaken them to pass).
- Fix Vite production build without changing core application logic.

## Current Parent
- Conversation ID: 65c19417-4f20-4c1c-913a-0ebd1d3d397b
- Updated: 2026-05-23T03:38:42-07:00

## Investigation State
- **Explored paths**: `playwright.config.ts`, `vite.config.ts`, `package.json`, `e2e/seo.spec.ts`, `src/root.tsx`, `src/pages/Home.tsx`, `src/shared/seo/SeoHead.tsx`
- **Key findings**: 
  - Worker weakened Open Graph test locators using `.first()` to mask duplicate tag bugs.
  - Duplicate tags stem from using both React Router `meta: MetaFunction` and React 19 `<SeoHead>` component simultaneously in `src/root.tsx` and `src/pages/Home.tsx`.
  - Build failed due to `react-helmet-async` left in `manualChunks` after it was removed, and bad syntax around `ViteImageOptimizer`.
  - `npm run preview` runs `vite preview` which serves a static shell and lacks SSR, causing SEO tests to fail. It must use `npm run build && npm run start` (port 3000).
- **Unexplored areas**: None

## Key Decisions Made
- Starting with SCOPE.md and TEST_INFRA.md.

## Artifact Index
- /Users/umurey/agency-domination/.agents/teamwork_preview_explorer_m1_seo_1_gen2/handoff.md — Handoff report with the recommended fix strategy.
