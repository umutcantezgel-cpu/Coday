# BRIEFING — 2026-05-23T18:56:20-07:00

## Mission
Review the worker's implementation for the hydration error fix.

## 🔒 My Identity
- Archetype: Reviewer AND adversarial critic
- Roles: reviewer, critic
- Working directory: /Users/umurey/agency-domination/.agents/teamwork_preview_reviewer_hydration_iter2_1
- Original parent: 0e8a5270-6fb4-48ac-8852-1ebb627878f6
- Milestone: Hydration Fix Review (iter 2)
- Instance: 1 of 1

## 🔒 Key Constraints
- Review-only — do NOT modify implementation code
- Run `npm run typecheck`, `npm run lint`, `npm run build`
- Handle `.next/build.lock` if it blocks the build

## Current Parent
- Conversation ID: 0e8a5270-6fb4-48ac-8852-1ebb627878f6
- Updated: 2026-05-23T18:56:20-07:00

## Review Scope
- **Files to review**: Mentioned in worker's handoff
- **Interface contracts**: PROJECT.md / SCOPE.md / AGENTS.md
- **Review criteria**: correctness, style, conformance, adversarial robustness

## Key Decisions Made
- [TBD]

## Artifact Index
- [TBD]

## Review Checklist
- **Items reviewed**: none yet
- **Verdict**: pending
- **Unverified claims**: none yet

## Attack Surface
- **Hypotheses tested**: none yet
- **Vulnerabilities found**: none yet
- **Untested angles**: none yet
