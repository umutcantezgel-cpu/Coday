const fs = require('fs');
try {
  fs.rmSync('.next', { recursive: true, force: true });
  console.log('Removed .next folder successfully.');
} catch (e) {
  console.error('Error removing .next folder:', e);
}
