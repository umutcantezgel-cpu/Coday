# Handoff Report

## Observation
- Running `npx playwright test --config=playwright-perf.config.ts e2e/performance.spec.ts --project=chromium` yields perfectly passing results with LCP values of ~50ms (Normal) and ~190ms (Throttled).
- By temporarily modifying the tests to output `entry.element.outerHTML` via `page.on('console')`, I observed the LCP element was `<pre>Error [ERR_MODULE_NOT_FOUND]: Cannot find mod...`.
- The `playwright-perf.config.ts` targets `http://localhost:4173`, which was returning an HTTP 500 Internal Server Error, rendering a plain text error page.
- Adding `expect(response?.ok()).toBeTruthy()` to the tests caused them to fail immediately.
- When `baseURL` was pointed to a real external site (`https://example.com`), the Throttled tests yielded an LCP of ~15,000ms, failing the 2,500ms assertion.
- The `Scroll-Induced and Mobile Performance` test uses `window.scrollTo(0, y)` which snaps the viewport instantly, failing to simulate intermediate rendering frames that typically cause layout shifts during real smooth scrolling.

## Logic Chain
1. The tests rely solely on metrics (`window.lcpValue`, `window.clsValue`) without asserting that the intended page actually loaded (HTTP 200) or that the expected primary content (e.g., hero image) is visible.
2. Because an HTTP 500 error page consists of minimal text, it renders nearly instantly, bypassing the intended performance threshold assertions and yielding false positives.
3. Throttling is successfully applied via CDP (`Network.emulateNetworkConditions`), but because the page was returning a 500 error, the small payload masked the fact that the 2500ms target might be unrealistic for the real application.
4. Testing CLS via instantaneous `scrollTo` bypasses the continuous viewport updates that normally trigger layout shifts, making the test a weak oracle for scroll-induced CLS.

## Caveats
- The 15,000ms LCP observed on `example.com` under throttling may be inflated due to CDP throttling quirks combined with CPU slowdown (`rate: 4`), but it proves the throttling *is* active and the thresholds will likely need tuning once the app successfully loads.
- I did not fix the underlying 500 server error (`ENOTEMPTY: directory not empty, rmdir '/Users/umurey/agency-domination/build/client/images'`) as my role is to challenge the test methodology, not fix the application build.

## Conclusion
The performance tests are currently passing superficially against an error page. They are missing foundational assertions for page health (HTTP 200, content visibility) prior to measuring Core Web Vitals. The CLS scroll test is also using an unrealistic immediate scroll instead of smooth scrolling. The tests MUST be updated to verify successful page loads before capturing metrics, and the throttling thresholds must be re-evaluated against the functioning application.

## Verification Method
1. Run the test with a status check: edit `e2e/performance.spec.ts` to add `const response = await page.goto('/'); expect(response?.ok()).toBeTruthy();`
2. Run `npx playwright test --config=playwright-perf.config.ts e2e/performance.spec.ts --project=chromium`. The test will fail due to the dev server error.
3. Temporarily add a page console listener (`page.on('console', msg => console.log(msg.text()))`) to see the `500 Internal Server Error` logged in the browser console.
