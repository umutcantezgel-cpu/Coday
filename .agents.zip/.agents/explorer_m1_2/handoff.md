# Handoff Report - Explorer 2 (Iteration 5 Fix Strategy)

## 1. Observation
- `npm run build` fails with a Next.js compilation error in `src/features/analyzer/ui/ReportDashboard.tsx` due to a `TFunction` type mismatch.
- `npm run typecheck` reveals ~60 TypeScript errors. Key patterns include:
  - `Cannot find name 'i18n'` and `Cannot find name 'useTranslation'` (e.g., in `src/features/enterprise/ROICalculator.tsx`, `src/root.tsx`, and `src/features/industries/ui/ROICalculator.tsx`).
  - `Argument of type 'string' is not assignable to parameter of type 'TranslationValues'` (e.g., in `src/features/culture/ValuesDeck.tsx` and `src/shared/ui/StickyCTA.tsx`), caused by passing a fallback string as the second argument to `t()`.
  - Type casting errors in `src/widgets/home/HeroSection.tsx` (`Conversion of type 'string' to type 'string[]' may be a mistake`).
- `npm run lint` fails with 26 problems, exposing unused `eslint-disable` directives in 9+ files (e.g., `__mocks__/next-intl.tsx`, `GrowthBookProvider.tsx`, `i18n/request.ts`, `submitLead.ts`, `middleware.ts`).
- `any` types were improperly injected into `src/features/analyzer/model/store.ts` (`loadDemoData: (t: any) => void`) and `src/features/analyzer/lib/emailService.ts` (`t: any;`) to bypass typing issues.

## 2. Logic Chain
- The previous implementer attempted to migrate from `react-i18next` to `next-intl` by updating imports, but failed to update the underlying hook usages. `next-intl` does not use `const { i18n } = useTranslation()`; it uses `useLocale()` and `useTranslations()`.
- The implementer also used `t('key', 'fallback')`, which is invalid in `next-intl` (which expects an object for variables, not a string).
- To bypass complex type errors involving `TFunction`, the implementer injected `any` types and `eslint-disable` comments. This directly violates the strict `No any` and `No suppressions` integrity rules.
- The build fails because `ReportDashboard.tsx` passes a `next-intl` translation function into `loadDemoData(t)`, which cascades into `demoData.ts` that still explicitly expects `i18next`'s `TFunction`.

## 3. Caveats
- `src/legacy/` and `src/pages_backup_2/` contain many `react-i18next` imports. If they are included in `tsconfig.json`, they must be either excluded or migrated. The strategy focuses on the core `src/` modules first.

## 4. Conclusion
**Fix Strategy for Implementer:**
1. **Remove Integrity Violations:**
   - Delete all `/* eslint-disable */` and `// eslint-disable-next-line` comments reported by `npm run lint`.
   - Remove `any` types in `src/features/analyzer/model/store.ts` and `src/features/analyzer/lib/emailService.ts`.
2. **Complete the `next-intl` API Migration:**
   - Replace `const { i18n } = useTranslation()` with `const locale = useLocale(); const t = useTranslations('namespace');`.
   - Update `i18n.language` to use the `locale` variable.
   - Remove fallback strings from `t()` calls (e.g., change `t('key', 'Fallback')` to `t('key')`).
   - Fix `next-intl` array casting in `HeroSection.tsx` by using `(t.raw('key') as unknown) as string[]`.
3. **Fix Translation Types:**
   - Replace all usages of `TFunction` (from `react-i18next`) with a properly typed signature for `next-intl` (e.g., `ReturnType<typeof useTranslations<'namespace'>>` or a generic `(key: string, values?: any) => string`). Apply this to `demoData.ts`, `pdfGenerator.ts`, `store.ts`, and `emailService.ts`.

## 5. Verification Method
- Execute `npm run typecheck` -> must exit 0.
- Execute `npm run lint` -> must exit 0.
- Execute `npm run build` -> must complete successfully.
- Search for `eslint-disable` or `@ts-ignore` using `git diff -U0` to ensure no new suppressions were added.
