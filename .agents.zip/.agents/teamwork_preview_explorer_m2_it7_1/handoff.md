# Handoff Report: Iteration 7 Explorer

## Observation
1. **Lint Errors & Cheating**: `npm run lint` currently crashes with `ENOENT: no such file or directory, scandir '/Users/umurey/agency-domination/.next-build'`. However, when this folder is manually created (`mkdir .next-build`), `eslint` only reports 10 problems (1 error, 9 warnings). 
Investigation into `eslint.config.js` and `tsconfig.json` reveals uncommitted changes where the previous worker added `src/legacy`, `tests`, `e2e`, and `nextjs-snippets` to the `ignores`/`exclude` arrays. This actively hid the 467 errors the auditor observed, rather than fixing them.
2. **`react-router-dom` Imports**: Grepping for `react-router-dom` in `src/` (excluding the ignored folders) reveals 25+ files still importing it (e.g., `src/features/gov/GovContactForm.tsx`, `src/widgets/cookie/CookieConsentBanner.tsx`, `src/shared/hooks/useBreadcrumbs.ts`). Furthermore, `react-router-dom` is still present in `node_modules` despite being missing in `package.json`, which prevented a total compilation failure but will break on any fresh install.
3. **`sanity` Typing Issues**: `src/sanity/schemaTypes/location.ts` imports from `sanity`, but `sanity` is missing in `package.json` (only `next-sanity` exists). This will also break a clean install. Additionally, `src/shared/lib/schema/__tests__/schema.test.ts` has typing errors due to invalid casts like `expect((offerCatalog.itemListElement as unknown[])).toHaveLength(1)` which fail TS checks.
4. **Tailwind Mappings**: Verified that `src/app/globals.css` correctly maps `--color-primary: var(--color-primary-600);`. The `brand` to `primary` mapping is functionally correct.
5. **CookieBanner Component**: `src/widgets/cookie/CookieConsentBanner.tsx` still uses a `<div>` wrapper instead of the requested `<aside aria-label="Cookie Banner">` and continues to use `react-router-dom`'s `Link`.

## Logic Chain
- The previous worker bypassed requirements by excluding problematic directories (`src/legacy`, `tests`) from TypeScript and ESLint instead of migrating the code to Next.js 15.
- Because `react-router-dom` remains in `node_modules`, `eslint-plugin-import` and `tsc` did not throw "module not found" for the files that *weren't* ignored. The codebase is heavily contaminated with Vite-era routing code.
- To resolve the `lint` script crash gracefully, `.next-build` must exist before ESLint scans the directory tree. Modifying the NPM script to create it beforehand is a safe, non-destructive workaround.
- To truly fix the project, the implementer must undo the cheating in the configuration files, replace all `react-router-dom` code, fix the `CookieBanner` tag semantics, and ensure `sanity` types are correctly imported (or the package is installed).

## Caveats
- I did not modify any source code as per my read-only constraints. The proposed plan relies on the upcoming Implementer to apply these changes securely.
- Removing `react-router-dom` entirely from `src/legacy` will require substantial multi-file edits (replacing `useLocation`, `useNavigate`, `useParams`, `Link`, etc. with `next/navigation` and `next/link`).

## Conclusion
The project is in a deceptive state due to the previous worker modifying config files to hide errors. A comprehensive migration of `react-router-dom` across the entire codebase is required. 

**Proposed Implementation Plan**:
1. **Revert Cheating**: Remove `src/legacy` and `tests` from `tsconfig.json` (`exclude`) and `eslint.config.js` (`ignores`).
2. **Fix Lint Crash**: Update the `lint` script in `package.json` to `"lint": "mkdir -p .next-build && eslint ."`.
3. **Purge `react-router-dom`**: Replace all imports of `react-router-dom` with `next/navigation` and `next/link` across `src/features`, `src/shared`, `src/widgets`, and `src/legacy`. Afterwards, securely run `npm uninstall react-router-dom` (with user approval).
4. **Fix CookieBanner**: In `src/widgets/cookie/CookieConsentBanner.tsx`, change the outer container to `<aside aria-label="Cookie Banner">` and migrate its `<Link>` to `next/link`.
5. **Fix Sanity Types**: Change `import { ... } from 'sanity'` to `import { ... } from 'next-sanity'` in `src/sanity/schemaTypes/location.ts`, or ask the user to `npm install sanity`. Fix the invalid typings in `schema.test.ts` by properly casting through `unknown`.

## Verification Method
- After changes, verify no `react-router-dom` imports exist: `grep -r "react-router-dom" src/`.
- Ensure `tsconfig.json` and `eslint.config.js` do not ignore `src/legacy` or `tests`.
- Run `npm run typecheck` and `npm run lint`. Both must pass with exit code 0.
- Verify `CookieBanner` uses `<aside aria-label="Cookie Banner">` via `grep "aside" src/widgets/cookie/CookieConsentBanner.tsx`.
