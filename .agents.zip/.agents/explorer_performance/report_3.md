# Performance E2E Testing Strategy

## Observation
The goal is to evaluate Core Web Vitals (specifically LCP < 1.5s and CLS < 0.1) using Playwright, without modifying the application's source code. The project is a React-based SPA (built with Vite and React Router, evident from `vite.config.ts` and `src/routes.ts`). Tests need to cover Tier 1 (happy path) and Tier 2 (boundaries/corners). 

Using Playwright, we can reliably extract CWV metrics by injecting a script into the page before it loads using `page.addInitScript()`. This avoids any need for changes in the application source. For boundary conditions, Chrome DevTools Protocol (CDP) can be leveraged to emulate network degradation, CPU throttling, and cache invalidation.

## Logic Chain
1. **Extraction Mechanism**: 
   Since we cannot modify application source code, adding `web-vitals` library to the app is not an option. Instead, Playwright's `page.addInitScript()` can inject a global `PerformanceObserver` as soon as the page context is created. This will record `largest-contentful-paint` and `layout-shift` events into a global variable (`window.cwvMetrics`). 
2. **Retrieval**: 
   After navigation and allowing the page to reach `networkidle` (with a small buffer for LCP to finalize), `page.evaluate()` will read the accumulated values from `window.cwvMetrics`.
3. **Tier 1 (Happy Path)**: 
   These tests run under ideal conditions (Playwright's default fast network and CPU) to ensure the baseline meets strict targets (LCP < 1.5s, CLS < 0.1). We will test critical pages and client-side navigation.
4. **Tier 2 (Boundaries/Corners)**: 
   Real-world performance degrades under constraints. We will use `page.context().newCDPSession(page)` to invoke:
   - `Network.emulateNetworkConditions` (Fast 3G)
   - `Network.setCacheDisabled`
   - `Emulation.setCPUThrottlingRate` (4x slowdown)
   This simulates lower-end devices and poor connectivity.

## Caveats
- `PerformanceObserver` might not capture LCP perfectly if the interaction happens before LCP settles, so waiting for `networkidle` and a brief timeout (e.g., 1000ms) is recommended before evaluating the metrics.
- LCP threshold on "Fast 3G" and CPU throttling is relaxed to `< 2.5s` as hitting `< 1.5s` on a throttled connection is physically improbable for most standard assets, aligning with Google's "Good" threshold.
- These tests are strictly for Chromium-based browsers, as CDP is Chrome-specific.

## Conclusion
We recommend creating the following 8 tests in `e2e/performance.spec.ts`.

### Setup & Extraction (To be used in `beforeEach` or as a utility)
```typescript
async function injectPerformanceObserver(page) {
  await page.addInitScript(() => {
    window.cwvMetrics = { lcp: 0, cls: 0 };
    
    // Track LCP
    new PerformanceObserver((list) => {
      const entries = list.getEntries();
      if (entries.length > 0) {
        window.cwvMetrics.lcp = entries[entries.length - 1].startTime;
      }
    }).observe({ type: 'largest-contentful-paint', buffered: true });

    // Track CLS
    new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!entry.hadRecentInput) {
          window.cwvMetrics.cls += entry.value;
        }
      }
    }).observe({ type: 'layout-shift', buffered: true });
  });
}
```

### Recommended Tests

**Tier 1: Happy Path (Ideal Conditions)**
1. **Homepage Baseline (Desktop):**
   - Inject observer, `page.goto('/')`, wait for `networkidle`.
   - Assert: `lcp < 1500`, `cls < 0.1`.
2. **Heavy Route Baseline (Desktop):**
   - Inject observer, `page.goto('/services')` (or another heavy page), wait for `networkidle`.
   - Assert: `lcp < 1500`, `cls < 0.1`.
3. **Client-side Navigation CLS:**
   - Go to `/`, click a navigation link (e.g., "About" or "Services"), wait for route transition.
   - Assert: `cls < 0.1`. Ensures SPA routing doesn't cause unstable layout shifts.

**Tier 2: Boundaries & Corners (Constrained Conditions)**
4. **Cache Disabled:**
   - Use CDP: `await client.send('Network.setCacheDisabled', { cacheDisabled: true })`.
   - Action: `page.goto('/')`.
   - Assert: `lcp < 1500`, `cls < 0.1`. Verifies optimal server response and asset delivery.
5. **Network Throttling (Fast 3G):**
   - Use CDP: `await client.send('Network.emulateNetworkConditions', { offline: false, downloadThroughput: 1.5 * 1024 * 1024 / 8, uploadThroughput: 750 * 1024 / 8, latency: 40 })`.
   - Action: `page.goto('/')`.
   - Assert: `lcp < 2500` (relaxed for 3G), `cls < 0.1`. 
6. **CPU Throttling (4x Slowdown):**
   - Use CDP: `await client.send('Emulation.setCPUThrottlingRate', { rate: 4 })`.
   - Action: `page.goto('/')`.
   - Assert: `cls < 0.1`. A slow CPU delays React hydration; this test ensures fallback UIs and lazy components don't cause layout shifts when they finally mount.
7. **Scroll-Induced CLS:**
   - Action: `page.goto('/')`, then simulate multiple mouse wheel scrolls (`page.mouse.wheel()`).
   - Assert: `cls < 0.1`. Validates that lazy-loaded images off-screen have correct aspect ratios and do not shift content upon entering the viewport.
8. **Mobile Viewport Performance:**
   - Action: Set context viewport to mobile (e.g., 375x667), `page.goto('/')`.
   - Assert: `lcp < 1500`, `cls < 0.1`. Mobile viewports stack differently and might have a different LCP element (e.g., mobile hero vs desktop hero).

## Verification Method
1. Create `e2e/performance.spec.ts` using the strategy outlined above.
2. Run `npx playwright test e2e/performance.spec.ts --project=chromium`.
3. The tests will log and assert the CWV metrics directly from the browser's performance APIs without any modifications to `src/`.
