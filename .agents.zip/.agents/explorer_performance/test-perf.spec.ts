import { test, expect } from '@playwright/test';

test('perf test', async ({ page }) => {
  await page.addInitScript(() => {
    window.cwv = { lcp: 0, cls: 0 };
    
    new PerformanceObserver((entryList) => {
      const entries = entryList.getEntries();
      const lastEntry = entries[entries.length - 1];
      window.cwv.lcp = lastEntry.startTime;
    }).observe({ type: 'largest-contentful-paint', buffered: true });

    new PerformanceObserver((entryList) => {
      for (const entry of entryList.getEntries()) {
        if (!entry.hadRecentInput) {
          window.cwv.cls += entry.value;
        }
      }
    }).observe({ type: 'layout-shift', buffered: true });
  });

  await page.goto('/');
  await page.waitForTimeout(2000); // let lcp settle
  
  const cwv = await page.evaluate(() => window.cwv);
  console.log('CWV:', cwv);
  
  expect(cwv.lcp).toBeLessThan(1500);
  expect(cwv.cls).toBeLessThan(0.1);
});
