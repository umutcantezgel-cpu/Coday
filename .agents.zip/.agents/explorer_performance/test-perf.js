const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  
  // Expose a function to collect web vitals
  let lcpValue = 0;
  let clsValue = 0;
  
  await page.addInitScript(() => {
    window.lcpValue = 0;
    window.clsValue = 0;
    
    new PerformanceObserver((entryList) => {
      for (const entry of entryList.getEntries()) {
        window.lcpValue = entry.startTime;
      }
    }).observe({type: 'largest-contentful-paint', buffered: true});
    
    new PerformanceObserver((entryList) => {
      for (const entry of entryList.getEntries()) {
        if (!entry.hadRecentInput) {
          window.clsValue += entry.value;
        }
      }
    }).observe({type: 'layout-shift', buffered: true});
  });
  
  await page.goto('https://example.com');
  // Wait a bit to let LCP settle
  await page.waitForTimeout(1000);
  
  const lcp = await page.evaluate(() => window.lcpValue);
  const cls = await page.evaluate(() => window.clsValue);
  
  console.log('LCP:', lcp);
  console.log('CLS:', cls);
  
  await browser.close();
})();
