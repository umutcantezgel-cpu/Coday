# BRIEFING — 2026-05-24T11:32:15Z

## Mission
Implement fixes identified by the Explorers to resolve 7 integrity violations from Iteration 2.

## 🔒 My Identity
- Archetype: teamwork_preview_worker
- Roles: implementer, qa, specialist
- Working directory: /Users/umurey/agency-domination/.agents/teamwork_preview_worker_m4_1_gen3
- Original parent: e07cb9ef-1891-438d-ae24-d16dc8a2d1ee
- Milestone: 4

## 🔒 Key Constraints
- NEVER push directly to main
- NEVER modify next.config.ts, middleware.ts, .env.*, package.json dependencies without explicit confirmation
- DO NOT use react-router-dom, use next/link
- TypeScript strict mode, RSC by default
- Keep total JS shipped < 250 KB
- Do NOT cheat or use dummy/facade implementations
- Verify with typecheck, lint, build before closing

## Current Parent
- Conversation ID: e07cb9ef-1891-438d-ae24-d16dc8a2d1ee
- Updated: 2026-05-24T11:32:15Z

## Task Summary
- **What to build**: Implement 7 integrity violation fixes
- **Success criteria**: Code compiles, builds, lints pass. Bundle < 250 KB.
- **Interface contracts**: PROJECT.md / SCOPE.md
- **Code layout**: PROJECT.md § Code Layout

## Key Decisions Made
- [TBD]

## Artifact Index
- handoff.md — Report of fixes and verification
- progress.md — Liveness heartbeat
