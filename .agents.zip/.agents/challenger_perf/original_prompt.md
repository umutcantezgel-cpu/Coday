## 2026-05-23T10:40:36Z
You are a Challenger for Milestone 2 (Performance Tests) in the E2E Testing Track.
Your job is to empirically verify the tests in `e2e/performance.spec.ts`.
Try to break the tests or ensure they are genuinely working and not just passing superficially.
Run the tests (`npx playwright test --config=playwright-perf.config.ts e2e/performance.spec.ts --project=chromium`).
Confirm the tests behave as expected under throttling.
Report back with your findings.
