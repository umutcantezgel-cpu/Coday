# Handoff Report: Performance Tests Empirical Verification

## 1. Observation
- Ran the performance tests in `e2e/performance.spec.ts` using `npx playwright test --config=playwright-perf.config.ts e2e/performance.spec.ts --project=chromium`.
- The tests passed initially. Normal LCP was around ~60ms, and Throttled LCP ("Fast 3G", 150ms latency) was around ~184ms.
- To verify if the throttling was genuinely working and not just a superficial pass, I modified the CDP `Network.emulateNetworkConditions` parameters to extreme values (`latency: 3000`, `downloadThroughput: 100`).
- Upon rerunning, the test **correctly failed**. The LCP was measured at ~15072ms, failing the `expect(lcp).toBeLessThan(2500)` assertion.
- Inspected the metric collection code:
  ```typescript
  window.lcpValue = 0;
  // ...
  const lcp = await page.evaluate(() => window.lcpValue);
  expect(lcp).toBeLessThan(1500);
  ```

## 2. Logic Chain
1. **Throttling Accuracy**: The difference between Normal (60ms) and Throttled (184ms) aligns with the configured 150ms latency. The extreme latency test confirms that Playwright's CDP throttling is actively affecting the page load, and the `PerformanceObserver` is accurately capturing the delayed paint.
2. **False Positive Risk**: Because `window.lcpValue` is initialized to `0` and the test merely checks `expect(lcp).toBeLessThan(...)`, any situation where the LCP event fails to fire entirely (e.g., a blank page, observer crash, or LCP firing *after* `getMetrics` is called) will result in `lcp = 0`.
3. Since `0 < 1500` is true, a completely broken page that renders nothing will falsely pass the performance test.
4. **Race Condition**: `await page.waitForLoadState('networkidle')` does not guarantee that the browser has finished painting. If a large image finishes downloading and `networkidle` triggers, the actual decode and paint might happen slightly after `getMetrics` retrieves `window.lcpValue`.

## 3. Caveats
- Playwright's `networkidle` is generally decent for SPAs, but explicitly waiting for a known LCP element (like the Hero image or H1) would make the test bulletproof against race conditions.
- The `lcpValue` might technically be 0 if we mock the clock, but in normal browser execution, the first paint is strictly `> 0`.

## 4. Conclusion
The performance tests **are genuinely working and correctly throttling the network**. They accurately catch slow performance. 

However, they suffer from a **False Positive vulnerability**: if the page fails to render or the LCP event doesn't fire, the test reports 0ms and passes. 

**Recommended Fixes:**
1. Add `expect(lcp).toBeGreaterThan(0);` to ensure the metric was actually captured.
2. Add an assertion that the main content is visible *before* fetching metrics (e.g., `await expect(page.locator('h1')).toBeVisible()`) to prevent race conditions where `networkidle` fires before the LCP element renders.

## 5. Verification Method
- **Verify Throttling**: Run `patch e2e/performance.spec.ts` with extreme latency (e.g., 3000ms), then run `npx playwright test --config=playwright-perf.config.ts e2e/performance.spec.ts --project=chromium -g "Throttling"`. It will fail as expected.
- **Verify False Positive**: Comment out the `lcpObserver.observe(...)` line in `e2e/performance.spec.ts:23`. Run the tests. They will pass with `LCP: 0ms` despite no LCP being measured.
