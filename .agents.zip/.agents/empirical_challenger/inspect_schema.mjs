import * as cheerio from 'cheerio';

async function fetchHtml(url) {
  const res = await fetch(url);
  return res.text();
}

async function run() {
  const html = await fetchHtml('http://localhost:3000/de');
  const $ = cheerio.load(html);
  
  const jsonLdScripts = $('script[type="application/ld+json"]');
  console.log(`Found ${jsonLdScripts.length} JSON-LD scripts on homepage.`);
  
  jsonLdScripts.each((i, el) => {
    try {
      const parsed = JSON.parse($(el).html());
      console.log(`JSON-LD ${i}:`, JSON.stringify(parsed, null, 2));
    } catch (e) {
      console.error('Error parsing JSON-LD:', e);
    }
  });

  const canonical = $('link[rel="canonical"]').attr('href');
  console.log('Homepage Canonical:', canonical);
}

run().catch(console.error);
