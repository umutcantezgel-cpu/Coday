const http = require('http');
const fs = require('fs');

http.get('http://localhost:3000/', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    fs.writeFileSync('/tmp/coday_homepage.html', data);
    console.log('Homepage fetched.');
  });
}).on('error', (err) => {
  console.log("Error: " + err.message);
});
