import os
import re
import html

TARGET_EXTS = {'.ts', '.tsx', '.json', '.md', '.html', '.css', '.scss'}
EXCLUDE_DIRS = {'node_modules', '.next', '.git', '.agents', 'build', 'dist'}

# Patterns to match aggressive text.
PATTERNS = [
    r'anti[-\s]?ai',
    r'killer',
    r'von[\s_]+hand',
    r'spaghetti',
    r'waffen',
    r'frankenstein',
    r'diebstahl'
]
COMBINED_PATTERN = re.compile('|'.join(PATTERNS), re.IGNORECASE)

def check_file(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
            decoded_content = html.unescape(content) # Handle HTML entities like &#x2D;
            
            lines = decoded_content.split('\n')
            for i, line in enumerate(lines):
                if COMBINED_PATTERN.search(line):
                    print(f"Match found in {path}:{i+1}")
                    print(f"  {line.strip()[:100]}") # Truncate to 100 chars
    except Exception as e:
        print(f"Error reading {path}: {e}")

def main():
    start_dir = '/Users/umurey/agency-domination'
    for root, dirs, files in os.walk(start_dir):
        # Filter out excluded directories
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        
        for file in files:
            if any(file.endswith(ext) for ext in TARGET_EXTS):
                check_file(os.path.join(root, file))

if __name__ == "__main__":
    main()
