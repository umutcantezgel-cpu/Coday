# BRIEFING — 2026-05-23T21:07:29-07:00

## Mission
Investigate `SkipLink.test.tsx`, `SkipLink.tsx`, and `HeroSection.tsx` for incorrect `react-router-dom` and `react-i18next` imports, and propose a fix strategy to remove them and correctly provide `next-intl` context.

## 🔒 My Identity
- Archetype: Teamwork explorer
- Roles: Read-only investigation, analysis, structured reporting
- Working directory: /Users/umurey/agency-domination/.agents/teamwork_preview_explorer_m2_it5_3
- Original parent: bc2d4dd8-0c68-4c50-a160-11a23470daf1
- Milestone: Fix hallucinated imports in SkipLink and HeroSection

## 🔒 Key Constraints
- Read-only investigation — do NOT implement
- DO NOT USE `react-router-dom`. Use Next.js 15 App Router routing (`next/link`).
- DO NOT USE `react-i18next`. Use `next-intl`.
- Do NOT mock `next-intl` internally in test files; use `NextIntlClientProvider` to wrap test renders.

## Current Parent
- Conversation ID: bc2d4dd8-0c68-4c50-a160-11a23470daf1
- Updated: 2026-05-23T21:07:29-07:00

## Investigation State
- **Explored paths**: `src/shared/__tests__/SkipLink.test.tsx`, `src/shared/ui/SkipLink.tsx`, `src/widgets/home/HeroSection.tsx`, `src/widgets/cookie/CookieConsentBanner.tsx`, `tailwind.config.js`, `src/shared/__tests__/SkipLink_test2.test.tsx`
- **Key findings**: 
  - `SkipLink.test.tsx`, `SkipLink.tsx`, and `HeroSection.tsx` DO NOT have the hallucinated imports and are correct.
  - `SkipLink_test2.test.tsx` incorrectly uses `vi.mock('next-intl')`.
  - `CookieConsentBanner.tsx` uses `div` instead of `aside` and has a `react-router-dom` import.
  - `tailwind.config.js` lacks `brand` mapping.
- **Unexplored areas**: Legacy files that also use `react-router-dom`.

## Key Decisions Made
- Wrote `handoff.md` recommending the deletion of `SkipLink_test2.test.tsx`, updating `CookieConsentBanner.tsx` to use `<aside>` and `next/link`, and updating `tailwind.config.js`.

## Artifact Index
- `handoff.md` — Handoff report with findings and fix strategy.
