import puppeteer from 'puppeteer';

async function runTest() {
  console.log('Starting verification script...');
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  const page = await browser.newPage();

  console.log('Navigating to http://localhost:3000...');
  try {
    await page.goto('http://localhost:3000', { waitUntil: 'networkidle0', timeout: 10000 });
  } catch (err) {
    console.error('Failed to load page. Is the server running?', err.message);
  }

  // 1. Table Contrast check - We can't do exact visual contrast easily with raw Puppeteer,
  // but we can check the computed colors.
  console.log('Checking Table colors...');
  const tableColors = await page.evaluate(() => {
    const table = document.querySelector('table');
    if (!table) return null;
    const th = table.querySelector('th');
    const td = table.querySelector('td');
    return {
      thColor: th ? window.getComputedStyle(th).color : null,
      tdColor: td ? window.getComputedStyle(td).color : null,
      tableBg: window.getComputedStyle(table).backgroundColor,
    };
  });
  console.log('Table styles:', tableColors);

  // 2. Testimonial ARIA
  console.log('Checking Testimonial ARIA...');
  const testimonialRegion = await page.evaluate(() => {
    const el = document.querySelector('[role="region"][aria-label="Testimonials"]');
    return el ? { tag: el.tagName, tabIndex: el.getAttribute('tabindex') } : null;
  });
  console.log('Testimonial region:', testimonialRegion);

  // 3. CookieBanner landmark
  console.log('Checking CookieBanner landmark...');
  const cookieBanner = await page.evaluate(() => {
    const el = document.querySelector('aside[aria-label="Cookie Banner"]');
    return el ? { tag: el.tagName, ariaLabel: el.getAttribute('aria-label') } : null;
  });
  console.log('Cookie banner:', cookieBanner);

  // 4. SSR Title duplicates
  console.log('Checking for title duplicates...');
  const titles = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('title')).map(t => t.textContent);
  });
  console.log('Titles found:', titles);

  // 5. Focus Traps
  // We can open the cookie settings modal and check if focus is trapped.
  console.log('Checking Cookie Settings Modal focus trap...');
  let hasSettingsBtn = false;
  try {
    const btn = await page.waitForSelector('button:has-text("Einstellungen")', { timeout: 2000 });
    if (btn) {
      await btn.click();
      hasSettingsBtn = true;
      await page.waitForTimeout(500); // wait for modal
    }
  } catch(e) {
    console.log('Could not open settings modal:', e.message);
  }

  const modalOpen = await page.evaluate(() => {
    return document.querySelector('[role="dialog"][aria-modal="true"]') !== null;
  });
  console.log('Modal is open:', modalOpen);

  await browser.close();
}

runTest().catch(console.error);
