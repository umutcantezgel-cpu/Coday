# BRIEFING — 2026-05-23T19:19:18Z

## Mission
Recommend a proper fix for the `SkipLink.test.tsx` unit test failure by removing `vi.mock('next-intl')` and using `NextIntlClientProvider`. Also provide migration strategy for `SkipLink.tsx` and `HeroSection.tsx` from `react-i18next`/`react-router-dom` to Next.js 15 App Router standards.

## 🔒 My Identity
- Archetype: Teamwork explorer
- Roles: Read-only investigation, analysis, reporting
- Working directory: /Users/umurey/agency-domination/.agents/teamwork_preview_explorer_m2_it4_1
- Original parent: 6861b7b5-3532-40b7-ae05-61d3f05b9b6f
- Milestone: M2 Iteration 4

## 🔒 Key Constraints
- Read-only investigation — do NOT implement
- Never push directly to main
- Solo-Founder Reality: Keep solutions maintainable

## Current Parent
- Conversation ID: 6861b7b5-3532-40b7-ae05-61d3f05b9b6f
- Updated: 2026-05-23T19:19:18Z

## Investigation State
- **Explored paths**: `src/shared/__tests__/SkipLink.test.tsx`, `src/shared/ui/SkipLink.tsx`, `src/widgets/home/HeroSection.tsx`.
- **Key findings**: Files contain invalid `vi.mock` setups and forbidden legacy dependencies (`react-i18next`, `react-router-dom`).
- **Unexplored areas**: None.

## Key Decisions Made
- Recommended using `NextIntlClientProvider` wrapping in tests.
- Recommended strict migration to `next/link` and `next-intl`.
- Documented changes in `handoff.md`.

## Artifact Index
- handoff.md — Analysis and fix strategy for SkipLink and HeroSection
- progress.md — Liveness check and step progress
