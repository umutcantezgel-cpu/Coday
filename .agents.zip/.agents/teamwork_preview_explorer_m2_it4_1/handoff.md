# Handoff Report: SkipLink & HeroSection i18n Fixes

## 1. Observation
- The codebase currently shows errors indicating residual use of `react-i18next` and `react-router-dom` in `src/widgets/home/HeroSection.tsx` and `src/shared/ui/SkipLink.tsx`.
- The rule `AGENTS.md` explicitly states: "DO NOT USE react-router-dom. Use Next.js 15 App Router conventions" and expects the use of `next-intl` for i18n.
- A previous iteration attempted to fix `SkipLink.test.tsx` by using `vi.mock('next-intl')` (and `react-i18next`), which was rejected by the Forensic Auditor as an "INTEGRITY VIOLATION". Bypassing the context setup with a mock is invalid; the component needs to be wrapped in the actual `NextIntlClientProvider`.
- `SkipLink.tsx` contains hardcoded translation logic (`i18n.language === 'en' ? 'Skip to main content' : 'Zum Hauptinhalt springen'`) instead of leveraging the `useTranslations` hook correctly.

## 2. Logic Chain
1. **HeroSection.tsx**: We must remove `react-i18next` and `react-router-dom`. We replace them with `next-intl` (`useTranslations`) and Next.js App Router navigation (`next/link`). This resolves the TS2307 errors and aligns with `AGENTS.md`.
2. **SkipLink.tsx**: We must remove `react-i18next` (or `useLocale` with hardcoded text) and implement `useTranslations('common')` from `next-intl` to dynamically render the localized text `t('skip_link')`. This correctly implements the i18n system.
3. **SkipLink.test.tsx**: Instead of using `vi.mock` on the i18n libraries, the test should render `<SkipLink />` wrapped in `<NextIntlClientProvider locale="de" messages={{ common: { skip_link: 'Zum Hauptinhalt springen' } }}>`. This provides the necessary context authentically and passes the auditor's checks.

## 3. Caveats
- I am recommending the key `skip_link` within the `common` namespace. If the actual translation JSON uses a different key, the implementer will need to align the `messages` object in the test with the real schema.
- The `HeroSection.tsx` may need a `"use client"` directive at the very top since it imports `motion/react` and uses hooks.
- I have not actually executed code modifications as per my Read-Only Constraints.

## 4. Conclusion
We must implement a clean migration to Next.js 15 standards across these files:

**Fix for `SkipLink.test.tsx`**:
```tsx
import { describe, it, expect } from 'vitest';
import { render } from '@testing-library/react';
import React from 'react';
import { NextIntlClientProvider } from 'next-intl';
import { SkipLink } from '@/shared/ui/SkipLink';

describe('SkipLink', () => {
  const renderWithProvider = (ui: React.ReactNode, locale: string = 'de') => {
    return render(
      <NextIntlClientProvider locale={locale} messages={{ common: { skip_link: 'Zum Hauptinhalt springen' } }}>
        {ui}
      </NextIntlClientProvider>
    );
  };

  it('renders a skip link element with correct href', () => {
    const { container } = renderWithProvider(<SkipLink />);
    const link = container.querySelector('a[href="#main-content"]');
    expect(link).not.toBeNull();
  });

  it('has German label when language is de', () => {
    const { container } = renderWithProvider(<SkipLink />);
    const link = container.querySelector('a');
    expect(link).not.toBeNull();
    expect(link?.textContent).toBe('Zum Hauptinhalt springen');
  });

  it('has sr-only class for visual hiding', () => {
    const { container } = renderWithProvider(<SkipLink />);
    const link = container.querySelector('a');
    expect(link?.className).toContain('sr-only');
  });
});
```

**Fix for `SkipLink.tsx`**:
```tsx
"use client";

import React from 'react';
import { useTranslations } from 'next-intl';

export const SkipLink: React.FC = () => {
  const t = useTranslations('common');
  const label = t('skip_link', { defaultValue: 'Zum Hauptinhalt springen' });

  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[9999] focus:px-4 focus:py-2 focus:rounded-lg focus:bg-white focus:text-gray-900 focus:shadow-lg focus:ring-2 focus:ring-primary focus:ring-offset-2 font-medium text-sm transition-all"
    >
      {label}
    </a>
  );
};
```

**Fix for `HeroSection.tsx`**:
1. Add `"use client";` at the top (if not already there).
2. Change imports:
```tsx
import { useTranslations } from 'next-intl';
import NavLink from 'next/link';
// Remove react-i18next and react-router-dom
```
3. Update translation usage inside component:
```tsx
const t = useTranslations('common'); // or specific namespace
```

## 5. Verification Method
1. Run `npm run typecheck` to ensure no `react-i18next` or `react-router-dom` missing module errors are thrown for these files.
2. Run `npm run test src/shared/__tests__/SkipLink.test.tsx` to verify the tests pass organically without `vi.mock('next-intl')`.
3. Check `SkipLink.test.tsx` source code manually to confirm `vi.mock` is entirely absent.
