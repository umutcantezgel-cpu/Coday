# Investigation Handoff: Iteration 8 (Typecheck & Lint Cleanup)

## 1. Observation
- **TFunction & next-intl issues**: The codebase previously relied on `react-i18next` (`useTranslation`, `i18n.language`, `t('key', 'fallback')`). The replacement to `next-intl` left behind syntax that causes `TS2345` (e.g., in `ValuesDeck.tsx:45` where a fallback string is passed) and `TS2304` (`Cannot find name 'useTranslation'`). Also, `emailService.ts` fails because its `EmailReportData.t` type is strictly `(key: string) => string`, but it is called with an options object.
- **react-router-dom**: Still present in `src/widgets/layout/MainLayout.tsx` (using `useLocation`, `useOutlet`, `Outlet`) and `src/widgets/navigation/NavDropdown.tsx` (using `NavLink`).
- **CookieConsentBanner**: Uses a `<div>` wrapper instead of the semantically required `<aside aria-label="Cookie Banner">`.
- **Lint Errors (dummy.tsx)**: `src/.pages-backup/dummy.tsx` throws a parsing error because it is excluded from `tsconfig.json` but not excluded in `eslint.config.js`.
- **ESLint Integrity**: `@typescript-eslint/no-explicit-any` and `@typescript-eslint/ban-ts-comment` were forcefully turned `'off'` in `eslint.config.js` by the previous worker.

## 2. Logic Chain
- **next-intl migration**: `next-intl`'s `useTranslations()` returns a translation function that does not accept a fallback string natively like i18next. To get current locale, `useLocale()` must be used instead of `i18n.language`. To get raw objects/arrays from JSON, `t.raw('key')` must be used instead of `{ returnObjects: true }`.
- **Navigation**: Next.js App Router uses `usePathname` from `next/navigation` and `children` props for layouts. `react-router-dom` concepts like `Outlet` and `NavLink` are incompatible and must be replaced natively.
- **Lint Config**: Adding `'src/.pages-backup/**'` to the `ignores` array in `eslint.config.js` will stop ESLint from trying to parse files outside the TS project scope. Removing the `'off'` overrides will restore project integrity.
- **Type fixes**: `emailService.ts` needs its type updated to `t: (key: string, values?: Record<string, any>) => string`. Unused `useTranslations` imports flagged by ESLint must be removed.

## 3. Caveats
- Some files might currently show as modified in the git tree if the user or orchestrator is actively working, but the step-by-step strategy below assumes we are systematically applying these fixes from a clean state.
- Fixing `@ts-expect-error` in `ProjectTimelineAnimation.tsx` requires properly typing the `icon` array rather than suppressing it, but removing `ban-ts-comment: 'off'` will correctly flag it for the implementer to fix.

## 4. Conclusion & Implementation Plan
**Step-by-Step Fix Strategy (0 cheating):**
1. **ESLint Config**: Edit `eslint.config.js`. Add `'src/.pages-backup/**'` to the `ignores` array. Remove `@typescript-eslint/no-explicit-any: 'off'` and `@typescript-eslint/ban-ts-comment: 'off'`.
2. **Cookie Banner**: Edit `src/widgets/cookie/CookieConsentBanner.tsx`. Change the outer wrapper to `<aside aria-label="Cookie Banner" className="...">`.
3. **Routing**: 
   - Edit `MainLayout.tsx`: Remove `react-router-dom`. Use `usePathname()`. Replace `{children || outlet}` with `{children}`.
   - Edit `NavDropdown.tsx`: Replace `NavLink` with `Link` (from `next/link` or localized equivalent), use `usePathname()` for active state.
4. **Translations (TS Fixes)**:
   - Change `t('key', 'fallback')` to `t('key')` in `ValuesDeck.tsx` and similar.
   - Replace any remaining `const { i18n } = useTranslation()` with `const locale = useLocale();`.
   - Update `emailService.ts` interface `t: (key: string, values?: Record<string, any>) => string`.
   - Use `t.raw('key')` instead of `{ returnObjects: true }`.
5. **Cleanup Unused Imports**: Run lint and remove unused `useTranslations` or `useLocale` imports in files like `SeoHead.tsx`, `ProjectSummary.tsx`, etc.

## 5. Verification Method
1. Run `npm run typecheck`. Expect exit code 0 (no TS2345, TS2304, or TS2554 errors).
2. Run `npx eslint .`. Expect exit code 0 (no warnings/errors about dummy.tsx, unused vars, or disabled rules).
3. Inspect `CookieConsentBanner.tsx` to verify `<aside aria-label="Cookie Banner">`.
4. Ensure `grep "react-router-dom" src/widgets` returns empty.
