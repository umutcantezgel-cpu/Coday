# Fix Strategy for Milestone 2 (E2E Testing Retry)

Based on the failure feedback, the following fixes should be implemented across the test configurations and specifications:

## 1. `playwright-perf.config.ts`
**Issue:** The `webServer` block is commented out, which breaks automated CI runs because the server is not started automatically.
**Fix:** Uncomment the `webServer` configuration block (lines 21-26).

```typescript
// playwright-perf.config.ts
export default defineConfig({
  // ... existing config
  webServer: {
    command: 'npm run preview',
    url: 'http://localhost:4173',
    reuseExistingServer: !process.env.CI,
    timeout: 180 * 1000,
  },
});
```

## 2. `e2e/performance.spec.ts`
There are several robustness flaws inside the test specification. Apply the following changes to all test blocks:

**Issue A: Failing to catch HTTP 500 or Build Errors**
**Fix:** Capture the response from `page.goto()` and assert that it was successful.
```typescript
const response = await page.goto('/your-route');
expect(response?.ok()).toBeTruthy();
```

**Issue B: Verifying App Render (Meaningful Paint)**
**Fix:** Before calling `getMetrics(page)`, ensure the main content is fully loaded by waiting for a meaningful element (e.g., the primary heading) to become visible. This guarantees that we aren't incorrectly measuring an error page that painted quickly.
```typescript
await expect(page.locator('h1').first()).toBeVisible();
```

**Issue C: False Positives on Blank Pages (LCP = 0)**
**Fix:** Since `window.lcpValue` is initialized to `0`, the test will falsely pass `expect(lcp).toBeLessThan(1500)` if the LCP event never fires. To prevent this, explicitly assert that the LCP value is strictly greater than 0.
```typescript
const { lcp, cls } = await getMetrics(page);
expect(lcp).toBeGreaterThan(0);
expect(lcp).toBeLessThan(1500); // or 2500 for throttled tests
```

### Combined Example Refactoring for a Test Block:
```typescript
test('Services page performance should meet Tier 1 CWV targets', async ({ page }) => {
  const response = await page.goto('/de/services');
  expect(response?.ok()).toBeTruthy();
  
  await expect(page.locator('h1').first()).toBeVisible();
  await page.waitForLoadState('networkidle');
  
  const { lcp, cls } = await getMetrics(page);
  console.log(`Services - LCP: ${lcp}ms, CLS: ${cls}`);
  
  expect(lcp).toBeGreaterThan(0);
  expect(lcp).toBeLessThan(1500);
  expect(cls).toBeLessThan(0.1);
});
```
(Apply the above pattern to all individual test cases in the file, including throttled, scroll-induced, and mobile viewport tests).
