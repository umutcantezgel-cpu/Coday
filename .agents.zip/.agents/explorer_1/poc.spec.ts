import { test, expect } from '@playwright/test';

test('LCP Test', async ({ page }) => {
  // Inject observer before navigation
  await page.addInitScript(() => {
    window.__lcp = 0;
    window.__cls = 0;

    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1];
      window.__lcp = lastEntry.startTime;
    });
    lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true });

    const clsObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!entry.hadRecentInput) {
          window.__cls += entry.value;
        }
      }
    });
    clsObserver.observe({ type: 'layout-shift', buffered: true });
  });

  await page.goto('/', { waitUntil: 'networkidle' });
  
  const metrics = await page.evaluate(() => ({
    lcp: window.__lcp,
    cls: window.__cls
  }));

  console.log('Metrics:', metrics);
  expect(metrics.lcp).toBeLessThan(1500);
  expect(metrics.cls).toBeLessThan(0.1);
});
