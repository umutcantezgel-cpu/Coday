# Playwright Performance Testing Strategy (LCP & CLS)

## Overview
To effectively measure Core Web Vitals (CWV) such as Largest Contentful Paint (LCP) and Cumulative Layout Shift (CLS) in Playwright **without modifying the application source code**, we can inject standard `PerformanceObserver` APIs into the page context before navigation. For advanced testing (throttling, caching), we utilize the Chrome DevTools Protocol (CDP).

## Strategy

1. **Extraction Strategy (`page.addInitScript`)**
   We bypass the need to install `web-vitals` or touch the source code by injecting a lightweight `PerformanceObserver` at the beginning of the test lifecycle using `page.addInitScript()`. This guarantees we capture all performance entries from the very start of navigation.
   We store the cumulative CLS and the latest LCP in `window` objects, which we later extract using `page.evaluate()`.

2. **Emulation Strategy (CDP Session)**
   Playwright's default context doesn't natively expose granular network/CPU throttling or cache toggling. To test Tier 2 scenarios, we use `page.context().newCDPSession(page)` to communicate directly with Chrome. We use commands such as `Network.emulateNetworkConditions`, `Emulation.setCPUThrottlingRate`, and `Network.setCacheDisabled` to simulate degraded environments.

## Recommended Tests for `e2e/performance.spec.ts`

Below is the concrete implementation containing ~5-10 tests spanning both tiers.

```typescript
import { test, expect } from '@playwright/test';

// Helper function to inject observers before navigation
async function injectPerformanceObservers(page) {
  await page.addInitScript(() => {
    // Track LCP
    window.lcpValue = 0;
    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1];
      window.lcpValue = lastEntry.startTime;
    });
    lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true });

    // Track CLS
    window.clsValue = 0;
    const clsObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!entry.hadRecentInput) {
          window.clsValue += entry.value;
        }
      }
    });
    clsObserver.observe({ type: 'layout-shift', buffered: true });
  });
}

test.describe('Tier 1: Happy Path Performance', () => {
  test.beforeEach(async ({ page }) => {
    await injectPerformanceObservers(page);
  });

  test('LCP should be under 1.5s on desktop load', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });
    
    const lcp = await page.evaluate(() => window.lcpValue);
    console.log(`Tier 1 - LCP: ${lcp}ms`);
    expect(lcp).toBeLessThan(1500);
  });

  test('CLS should be under 0.1 on desktop load', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });
    
    // Simulate scroll to ensure layout is stable
    await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    await page.waitForTimeout(1000); // Wait for potential shifts
    
    const cls = await page.evaluate(() => window.clsValue);
    console.log(`Tier 1 - CLS: ${cls}`);
    expect(cls).toBeLessThan(0.1);
  });

  test('LCP and CLS on About page (overall CWV routing)', async ({ page }) => {
    await page.goto('/about', { waitUntil: 'networkidle' });
    
    const lcp = await page.evaluate(() => window.lcpValue);
    const cls = await page.evaluate(() => window.clsValue);
    
    expect(lcp).toBeLessThan(1500);
    expect(cls).toBeLessThan(0.1);
  });
});

test.describe('Tier 2: Boundaries & Corners (Throttling / Cache)', () => {
  let client;

  test.beforeEach(async ({ page }) => {
    client = await page.context().newCDPSession(page);
    await injectPerformanceObservers(page);
  });

  test('LCP handles Slow 3G network conditions gracefully', async ({ page }) => {
    await client.send('Network.enable');
    await client.send('Network.emulateNetworkConditions', {
      offline: false,
      downloadThroughput: (500 * 1024) / 8, // 500 kbps
      uploadThroughput: (500 * 1024) / 8,   // 500 kbps
      latency: 400,
    });

    await page.goto('/', { waitUntil: 'networkidle' });
    const lcp = await page.evaluate(() => window.lcpValue);
    console.log(`Tier 2 (Slow 3G) - LCP: ${lcp}ms`);
    
    // Boundary expectation (e.g., LCP shouldn't exceed 4 seconds even on 3G)
    expect(lcp).toBeLessThan(4000);
  });

  test('LCP stays reasonable when CPU is throttled (4x slowdown)', async ({ page }) => {
    await client.send('Emulation.setCPUThrottlingRate', { rate: 4 });

    await page.goto('/', { waitUntil: 'networkidle' });
    const lcp = await page.evaluate(() => window.lcpValue);
    console.log(`Tier 2 (4x CPU) - LCP: ${lcp}ms`);
    
    expect(lcp).toBeLessThan(3000);
  });

  test('Performance remains stable when cache is disabled', async ({ page }) => {
    await client.send('Network.setCacheDisabled', { cacheDisabled: true });

    await page.goto('/', { waitUntil: 'networkidle' });
    const lcp = await page.evaluate(() => window.lcpValue);
    console.log(`Tier 2 (No Cache) - LCP: ${lcp}ms`);
    
    // First paint might be slightly slower, but still aiming for < 2.0s
    expect(lcp).toBeLessThan(2000);
  });

  test('CLS stays under 0.1 during rapid viewport resizing and scrolling', async ({ page }) => {
    await page.goto('/', { waitUntil: 'networkidle' });
    
    // Force sudden viewport changes to check if layout shifts occur
    await page.setViewportSize({ width: 500, height: 800 });
    await page.waitForTimeout(500);
    await page.evaluate(() => window.scrollTo(0, 1000));
    await page.setViewportSize({ width: 1200, height: 800 });
    await page.waitForTimeout(500);

    const cls = await page.evaluate(() => window.clsValue);
    console.log(`Tier 2 (Resize/Scroll) - CLS: ${cls}`);
    expect(cls).toBeLessThan(0.1);
  });
});
```

## How to Run
Once `e2e/performance.spec.ts` is created:
```bash
npx playwright test e2e/performance.spec.ts
```
*(Ensure the local build/dev server runs without errors since Playwright config depends on `npm run build`.)*
