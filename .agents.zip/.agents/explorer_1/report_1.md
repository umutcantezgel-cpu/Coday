# Performance Testing Strategy using Playwright

## Observation
The goal is to test Core Web Vitals (CWV), specifically LCP (< 1.5s) and CLS (< 0.1), across Tier 1 (happy path) and Tier 2 (throttled/cache-disabled) scenarios without altering the underlying source code.
Currently, `e2e` contains only a basic `home.spec.ts`. The Playwright config is set up to run tests locally via `npm run build && npm run preview` and provides Chromium execution.

## Logic Chain
Since we cannot modify the source code to include the `web-vitals` library natively, we must rely on browser APIs accessible through Playwright.
1. **Metric Extraction:** We can use `page.addInitScript()` to inject a `PerformanceObserver` before the page begins loading. This will monitor `largest-contentful-paint` and `layout-shift` events and store their values in the `window` object.
2. **Waiting for Paint:** We navigate to the target route using `waitUntil: 'networkidle'`, and then read the values from `window` using `page.evaluate()`.
3. **Throttling (Tier 2):** Playwright provides access to the Chrome DevTools Protocol via `page.context().newCDPSession(page)`. We can use this to throttle the CPU (`Emulation.setCPUThrottlingRate`), throttle the network (`Network.emulateNetworkConditions`), or disable cache (`Network.setCacheDisabled`).

## Proposed Tests (`e2e/performance.spec.ts`)
We recommend creating 8 tests encompassing Tier 1 and Tier 2 cases.

### Tier 1: Happy Path (Default Network/CPU, With Cache)
1. **Homepage Performance:** Loads `/` and checks LCP < 1.5s, CLS < 0.1.
2. **Services Overview Performance:** Loads `/services` to check rendering of multiple service cards.
3. **Dashboard Performance:** Loads `/dashboard` to check performance of dynamic graphs and tables.
4. **Analyzer Interactive Performance:** Loads `/analyzer`, checks LCP/CLS.

### Tier 2: Boundaries and Corners
5. **Homepage - CPU Throttled (4x Slowdown):** Checks if the homepage still maintains LCP < 1.5s when JS execution is slower.
6. **Homepage - Network Throttled (Fast 3G):** Checks if the homepage loads fast on mobile networks (simulating 1.6Mbps download, 150ms latency).
7. **Packages Page - Cache Disabled:** Loads `/packages` entirely from the network.
8. **Contact Page - Cache Disabled & CPU Throttled:** A stress test on a form-heavy page.

## Caveats
- Network and CPU throttling using CDP only works reliably in Chromium-based browsers. If cross-browser performance testing is strictly required, Playwright's `route.continue` mechanism can be used for custom network delays, but CPU throttling is Chromium-only.
- `networkidle` is sometimes unpredictable in SPAs where background polling occurs. If `networkidle` timeouts happen, consider waiting for a specific DOM element instead of `networkidle` or use `load` state.
- LCP metrics might not finalize until user interaction. Adding a timeout before extraction ensures the final metric is collected.

## Conclusion
The best strategy to evaluate CWV without modifying implementation source code is to inject `PerformanceObserver` logic into the browser context via Playwright's `addInitScript`. For Tier 2 tests, Playwright's CDP integration allows robust simulation of slow network and CPU constraints. 

```typescript
// e2e/performance.spec.ts
import { test, expect, Page } from '@playwright/test';

// Utility to inject PerformanceObservers
async function injectPerformanceObservers(page: Page) {
  await page.addInitScript(() => {
    window.__lcp = 0;
    window.__cls = 0;

    const lcpObserver = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      if (entries.length > 0) {
        window.__lcp = entries[entries.length - 1].startTime;
      }
    });
    lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true });

    const clsObserver = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!entry.hadRecentInput) {
          window.__cls += (entry as any).value;
        }
      }
    });
    clsObserver.observe({ type: 'layout-shift', buffered: true });
  });
}

// Utility to retrieve metrics
async function getMetrics(page: Page) {
  // Allow time for rendering to settle
  await page.waitForTimeout(1000);
  return await page.evaluate(() => ({
    lcp: window.__lcp,
    cls: window.__cls
  }));
}

test.describe('Tier 1: Happy Path Performance', () => {
  test.beforeEach(async ({ page }) => {
    await injectPerformanceObservers(page);
  });

  const tier1Pages = ['/', '/services', '/dashboard', '/analyzer'];

  for (const path of tier1Pages) {
    test(`Performance for ${path} should meet CWV targets`, async ({ page }) => {
      await page.goto(path, { waitUntil: 'networkidle' });
      const { lcp, cls } = await getMetrics(page);
      
      console.log(`[Tier 1] ${path} - LCP: ${lcp}ms, CLS: ${cls}`);
      expect(lcp).toBeLessThan(1500);
      expect(cls).toBeLessThan(0.1);
    });
  }
});

test.describe('Tier 2: Boundary/Corner Cases Performance', () => {
  test.beforeEach(async ({ page }) => {
    await injectPerformanceObservers(page);
  });

  test('Homepage with 4x CPU Slowdown', async ({ page }) => {
    const client = await page.context().newCDPSession(page);
    await client.send('Emulation.setCPUThrottlingRate', { rate: 4 });
    
    await page.goto('/', { waitUntil: 'networkidle' });
    const { lcp, cls } = await getMetrics(page);
    
    console.log(`[Tier 2] / (4x CPU) - LCP: ${lcp}ms, CLS: ${cls}`);
    expect(lcp).toBeLessThan(1500);
    expect(cls).toBeLessThan(0.1);
  });

  test('Homepage with Fast 3G Network Throttling', async ({ page }) => {
    const client = await page.context().newCDPSession(page);
    await client.send('Network.enable');
    await client.send('Network.emulateNetworkConditions', {
      offline: false,
      downloadThroughput: (1.6 * 1024 * 1024) / 8,
      uploadThroughput: (750 * 1024) / 8,
      latency: 150,
    });

    await page.goto('/', { waitUntil: 'networkidle' });
    const { lcp, cls } = await getMetrics(page);
    
    console.log(`[Tier 2] / (Fast 3G) - LCP: ${lcp}ms, CLS: ${cls}`);
    expect(lcp).toBeLessThan(1500);
    expect(cls).toBeLessThan(0.1);
  });

  test('Packages page with Cache Disabled', async ({ page }) => {
    const client = await page.context().newCDPSession(page);
    await client.send('Network.enable');
    await client.send('Network.setCacheDisabled', { cacheDisabled: true });

    await page.goto('/packages', { waitUntil: 'networkidle' });
    const { lcp, cls } = await getMetrics(page);
    
    console.log(`[Tier 2] /packages (No Cache) - LCP: ${lcp}ms, CLS: ${cls}`);
    expect(lcp).toBeLessThan(1500);
    expect(cls).toBeLessThan(0.1);
  });

  test('Contact page with Cache Disabled & CPU Throttled', async ({ page }) => {
    const client = await page.context().newCDPSession(page);
    await client.send('Network.enable');
    await client.send('Network.setCacheDisabled', { cacheDisabled: true });
    await client.send('Emulation.setCPUThrottlingRate', { rate: 4 });

    await page.goto('/contact', { waitUntil: 'networkidle' });
    const { lcp, cls } = await getMetrics(page);
    
    console.log(`[Tier 2] /contact (No Cache & 4x CPU) - LCP: ${lcp}ms, CLS: ${cls}`);
    expect(lcp).toBeLessThan(1500);
    expect(cls).toBeLessThan(0.1);
  });
});
```

## Verification Method
1. Ensure the code above is placed in `e2e/performance.spec.ts`.
2. Ensure you have a working test environment by running the dev/preview server.
3. Execute `npx playwright test e2e/performance.spec.ts`.
4. Tests will output the LCP and CLS to the console and assert them against the limits. 
