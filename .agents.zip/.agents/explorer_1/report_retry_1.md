# Handoff Report: Fix Strategy for Performance Tests

## 1. Observation
- **`playwright-perf.config.ts`**: Lines 21-26 contain a commented-out `webServer` block, which means Playwright will not automatically start the app server (`npm run preview`) during CI runs.
- **`e2e/performance.spec.ts`**: 
  - `window.lcpValue` is initialized to `0` in `injectPerformanceObserver`.
  - The LCP assertions (e.g., `expect(lcp).toBeLessThan(1500)`) will pass even if the LCP value remains `0` (i.e., when no LCP event fires).
  - Most tests call `await page.goto('/path')` without capturing the response or asserting that the HTTP status is successful (e.g., `expect(response?.ok()).toBeTruthy()`).
  - The tests rely solely on `await page.waitForLoadState('networkidle')` before measuring metrics, without verifying if a meaningful element (like the `<main>` tag) is actually visible on the page.

## 2. Logic Chain
- **CI Automation**: Uncommenting the `webServer` block in `playwright-perf.config.ts` is required for Playwright to correctly spin up the app on `localhost:4173` in CI environments.
- **Response Validation**: By assigning `const response = await page.goto(...)` and asserting `expect(response?.ok()).toBeTruthy()`, we ensure the test immediately fails if the server returns a 500 Internal Server Error or fails to build, fixing the critical robustness flaw.
- **Render Validation**: A 200 OK status doesn't guarantee the React application mounted correctly. By asserting `await expect(page.locator('main').first()).toBeVisible()` before capturing metrics, we ensure the page actually rendered a structural DOM element, rather than remaining blank.
- **LCP False Positives**: An LCP metric must be a positive number. Asserting `expect(lcp).toBeGreaterThan(0)` guarantees that an LCP event was captured by the `PerformanceObserver`. If the page renders completely blank and no LCP fires, the test will fail as expected.

## 3. Caveats
- Waiting for `<main>` assumes every page under test uses a `<main>` element. A quick check of the source code confirms `<main role="main">` or `id="main-content"` is used in the application layout (`src/widgets/layout/MainLayout.tsx`, `src/root.tsx`), making it a reliable selector.
- Network idle is still useful to wait for post-hydration requests, so `page.waitForLoadState('networkidle')` should be kept alongside the visibility assertion.

## 4. Conclusion
Apply the following fix strategy:
1. **Uncomment `webServer`** in `playwright-perf.config.ts`.
2. **Update `e2e/performance.spec.ts`**:
   - For **every** test containing a `page.goto` call, capture the response and assert `expect(response?.ok()).toBeTruthy()`.
   - Before calling `getMetrics(page)`, insert: `await expect(page.locator('main').first()).toBeVisible()`.
   - Update all LCP assertions to also ensure the value is positive: `expect(lcp).toBeGreaterThan(0)`.

## 5. Verification Method
- **Run the tests**: Execute `npx playwright test e2e/performance.spec.ts -c playwright-perf.config.ts`.
- **Negative tests**: 
  - To test the response assertion, temporarily change the `baseURL` to a non-existent port or throw an error in a page loader. The test should fail at `response?.ok()`.
  - To test the LCP check, temporarily return `null` from a component to render a blank page. The test should fail at the `toBeVisible` or `toBeGreaterThan(0)` assertion.
