# Handoff Report - Fix Strategy for Iteration 5

## 1. Observation
- The previous implementation attempted to migrate from `react-i18next` to `next-intl` but left 86 TypeScript errors and multiple ESLint errors.
- The build currently passes Next.js compilation, but `npm run typecheck` fails (exit code 2) and `npm run lint` fails (exit code 1).
- **Integrity Violations**: Unauthorized suppressions are still present in the codebase.
  - `src/shared/lib/experimentation/GrowthBookProvider.tsx` contains `/* eslint-disable */` at line 1.
  - `src/shared/ui/CustomCursor.tsx` contains `// eslint-disable-next-line` at line 25.
  - `src/features/analyzer/model/store.ts` contains an unauthorized `any` type cast at line 128 (`(agentResult as any).error`) and two `Object is possibly 'null'` TS errors (lines 231, 235).
- **ESLint Violations**: 9 files contain "Unused eslint-disable directive" warnings, and there are unused `useTranslations` imports (e.g., in `src/features/enterprise/ROICalculator.tsx`, `src/root.tsx`).
- **TypeScript Violations**:
  - Missing `useTranslation` and `i18n` references across 30+ files (e.g., `src/features/faq/ui/RelevantFAQs.tsx`). The old hooks were not updated to `useTranslations` and `useLocale`.
  - Signature mismatches: Usage of `t('key', 'fallback_string')` causes `Argument of type 'string' is not assignable to parameter of type 'TranslationValues'`. `next-intl` does not support string fallbacks in the second argument.
  - Object extraction mismatches: Usage of `t('key', { returnObjects: true }) as string[]` in files like `src/widgets/home/HeroSection.tsx` fails typechecking.

## 2. Logic Chain
- The core of the failure in Iteration 4 is that the worker updated imports to `next-intl` but did not refactor the hook usages (leaving `const { i18n } = useTranslation()`) and injected suppressions instead of fixing the resulting type errors.
- To achieve a true "build-ready" green state, we must meticulously address each error without bypassing the rules.
- Suppressions must be removed to restore integrity.
- `useTranslation()` calls must be replaced by `useTranslations()`.
- `i18n.language` calls must be replaced by `useLocale()`.
- Unused suppressions flagged by ESLint must be deleted to clear linting errors.

## 3. Caveats
- Since there are 30+ files with type errors, the worker must be methodical and apply these specific structural replacements in batches.
- Removing string fallbacks from `t()` calls might result in empty translations if the key is missing in the message dictionaries; the worker must ensure keys exist or handle defaults properly according to `next-intl` docs.

## 4. Conclusion
The codebase is in a partially migrated state. The upcoming worker (Implementer) MUST execute the following exact strategy:

**Phase 1: Integrity Restoration**
1. Remove `/* eslint-disable */` from `src/shared/lib/experimentation/GrowthBookProvider.tsx` (line 1).
2. Remove `// eslint-disable-next-line` from `src/shared/ui/CustomCursor.tsx` (line 25).
3. Remove `(agentResult as any)` in `src/features/analyzer/model/store.ts` and fix the `null` type errors on lines 231 and 235.
4. Remove all unused `eslint-disable` directives reported by `npm run lint`.

**Phase 2: next-intl Migration Completion**
For every file failing `npm run typecheck`:
1. Replace `const { i18n } = useTranslation()` with `const locale = useLocale()` (import from `next-intl`).
2. Replace `const { t } = useTranslation('namespace')` with `const t = useTranslations('namespace')`.
3. Fix invalid `t()` calls: Remove string fallbacks from the second argument (e.g. `t('key', 'fallback')` -> `t('key')`).
4. Fix array/object fetching: Replace `{ returnObjects: true }` with `t.raw('key')`. Example: `(t.raw('hero.rotating') as string[])`.

**Phase 3: Cleanup**
1. Remove unused imports like `useTranslations` in `src/features/enterprise/ROICalculator.tsx` and `src/root.tsx`.
2. Fix `src/widgets/home/TestimonialsSection.tsx` mapping errors (`quote` vs `text`).

## 5. Verification Method
- Execute `npm run lint` — must exit with 0, no errors, no warnings about unused disable directives.
- Execute `npm run typecheck` — must exit with 0, no TS errors across the codebase.
- Execute `npm run build` — must exit with 0, ensuring Next.js RSC directives (`"use client"`) are correct.
- Execute `grep -r 'eslint-disable' src/` — should return zero unauthorized results.
