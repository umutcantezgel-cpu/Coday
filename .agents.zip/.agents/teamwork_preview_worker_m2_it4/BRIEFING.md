# BRIEFING — 2026-05-23T19:20:00-07:00

## Mission
Fix i18n implementation and testing to pass Reviewer and Forensic Auditor.

## 🔒 My Identity
- Archetype: Teamwork agent
- Roles: implementer, qa, specialist
- Working directory: /Users/umurey/agency-domination/.agents/teamwork_preview_worker_m2_it4
- Original parent: 51754b0f-71f8-4768-b1fa-9c534c75ae65
- Milestone: Milestone 2 (Iteration 4)

## 🔒 Key Constraints
- NEVER push directly to main.
- NEVER modify next.config.ts, middleware.ts, .env.*, package.json dependencies without explicit confirmation.
- NEVER run destructive commands without explicit user approval.
- Keep solutions maintainable by a single developer.
- TypeScript strict mode, React Server Components by default, Tailwind inline.
- LCP < 2.0s, INP < 150ms, CLS < 0.05, First Load JS < 100KB, Total JS < 250KB.
- No localStorage for sensitive data, no inline <style>/<script> without nonce, no direct DB from client.
- DO NOT CHEAT. All implementations must be genuine. No mocked `vi.mock('next-intl')` for `SkipLink.test.tsx`.

## Current Parent
- Conversation ID: 51754b0f-71f8-4768-b1fa-9c534c75ae65
- Updated: not yet

## Task Summary
- **What to build**: Fix `SkipLink.test.tsx`, `SkipLink.tsx`, `HeroSection.tsx`, and other files using `react-i18next` or `react-router-dom` to use `next-intl` and Next.js App Router conventions.
- **Success criteria**: Tests, typecheck, and lint pass. No `vi.mock('next-intl')` in `SkipLink.test.tsx`.
- **Interface contracts**: PROJECT.md / SCOPE.md
- **Code layout**: App Router (`app/[locale]/...`), `next-intl`.

## Key Decisions Made
- [TBD]

## Artifact Index
- [TBD]

## Change Tracker
- **Files modified**: None yet
- **Build status**: Unknown
- **Pending issues**: None

## Quality Status
- **Build/test result**: Unknown
- **Lint status**: Unknown
- **Tests added/modified**: None

## Loaded Skills
- None yet
