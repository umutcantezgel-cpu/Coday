import os
import glob
import re

src_dir = '/Users/umurey/agency-domination/src'

for filepath in glob.glob(src_dir + '/**/*.tsx', recursive=True) + glob.glob(src_dir + '/**/*.ts', recursive=True):
    with open(filepath, 'r') as f:
        content = f.read()

    original = content
    modified = False

    # Fix useLocation from next/link to usePathname from next/navigation
    if "from 'next/link'" in content or 'from "next/link"' in content:
        content = re.sub(r"(import\s+\{.*?)\buseLocation\b(.*?\}\s+from\s+['\"]next/link['\"];)", r"\1\2", content)
        content = re.sub(r"(import\s+\{.*?)\buseNavigate\b(.*?\}\s+from\s+['\"]next/link['\"];)", r"\1\2", content)
        content = re.sub(r"(import\s+\{.*?)\buseOutlet\b(.*?\}\s+from\s+['\"]next/link['\"];)", r"\1\2", content)
        content = re.sub(r"(import\s+\{.*?)\bOutlet\b(.*?\}\s+from\s+['\"]next/link['\"];)", r"\1\2", content)
        # Clean up empty imports like import { , } from 'next/link';
        content = re.sub(r"import\s+\{\s*,?\s*\}\s+from\s+['\"]next/link['\"];", "", content)
        content = re.sub(r",\s*,", ",", content)
        content = re.sub(r"\{\s*,", "{", content)
        content = re.sub(r",\s*\}", "}", content)
        
        # Add next/navigation if needed
        if 'useLocation(' in original or 'useNavigate(' in original:
            if 'next/navigation' not in content:
                content = "import { usePathname, useRouter } from 'next/navigation';\n" + content
            else:
                if 'usePathname' not in content and 'useLocation(' in original:
                    content = re.sub(r"(import\s+\{)(.*?)(\}\s+from\s+['\"]next/navigation['\"];)", r"\1usePathname, \2\3", content)
                if 'useRouter' not in content and 'useNavigate(' in original:
                    content = re.sub(r"(import\s+\{)(.*?)(\}\s+from\s+['\"]next/navigation['\"];)", r"\1useRouter, \2\3", content)

    # Replace usages
    content = content.replace("useLocation()", "usePathname()")
    content = content.replace("useNavigate()", "useRouter()")

    # Fix const { t } = useTranslations() to const t = useTranslations()
    content = re.sub(r"const\s+\{\s*t\s*\}\s*=\s*useTranslations", "const t = useTranslations", content)
    content = re.sub(r"const\s+\{\s*t,\s*i18n\s*\}\s*=\s*useTranslations", "const t = useTranslations", content)
    content = re.sub(r"const\s+\{\s*i18n,\s*t\s*\}\s*=\s*useTranslations", "const t = useTranslations", content)
    content = re.sub(r"const\s+\{\s*i18n\s*\}\s*=\s*useTranslations", "const locale = useLocale", content)
    
    # Fix i18n usages (i18n.language -> locale)
    # If they were using i18n, we probably need useLocale from next-intl
    if 'i18n.language' in content and 'useLocale' not in content:
        if "from 'next-intl'" in content:
            content = re.sub(r"(import\s+\{)(.*?)(\}\s+from\s+['\"]next-intl['\"];)", r"\1useLocale, \2\3", content)
        else:
            content = "import { useLocale } from 'next-intl';\n" + content
        if "const t = useTranslations" in content and "const locale = useLocale()" not in content:
            content = re.sub(r"(const\s+t\s*=\s*useTranslations[^\n]*\n)", r"\1  const locale = useLocale();\n", content)
    
    content = content.replace("i18n.language", "locale")

    if content != original:
        with open(filepath, 'w') as f:
            f.write(content)
