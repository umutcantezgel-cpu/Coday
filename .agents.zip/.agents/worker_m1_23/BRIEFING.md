# BRIEFING — 2026-05-24T13:20:50Z

## Mission
Exclude legacy folders from `tsconfig.json` so that `npm run typecheck` and the Next.js build completely ignore them.

## 🔒 My Identity
- Archetype: Implementer
- Roles: implementer, qa, specialist
- Working directory: /Users/umurey/agency-domination/.agents/worker_m1_23
- Original parent: eded67fc-301e-4028-8edb-7c9eb13d793c
- Milestone: worker_m1_23

## 🔒 Key Constraints
- NEVER push directly to `main`
- NEVER modify next.config.ts, middleware.ts, .env.*, package.json without explicit confirmation
- NEVER run destructive commands without explicit user approval
- Verify typecheck, lint, build before handoff

## Current Parent
- Conversation ID: eded67fc-301e-4028-8edb-7c9eb13d793c
- Updated: not yet

## Task Summary
- **What to build**: Exclude `src/legacy` (and other legacy paths) in `tsconfig.json` so that `npm run typecheck` passes.
- **Success criteria**: `tsconfig.json` contains `src/legacy` in `exclude` array, and `npm run typecheck` works.
- **Interface contracts**: PROJECT.md
- **Code layout**: src/legacy

## Key Decisions Made
- [initial decision]

## Artifact Index
- [path] — [purpose]
