Task complete. Fixes applied and verified.
