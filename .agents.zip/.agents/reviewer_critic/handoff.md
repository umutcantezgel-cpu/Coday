# Handoff Report: Technical SEO & Schema.org Refactoring Review

## 1. Observation
1. Verified the findings in `worker_seo/handoff.md`. `SeoHead.tsx` and `JsonLd.tsx` were correctly moved to `src/shared/seo/` and all imports updated, respecting module boundaries.
2. The static sitemap files remain in `public/`.
3. In `src/shared/seo/JsonLd.tsx` (lines 708-711), the component renders the JSON-LD schema by directly embedding stringified JSON inside a `<script>` tag without any escaping for HTML elements:
   ```tsx
   return (
     <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
   );
   ```
4. In `src/shared/seo/SeoHead.tsx` (line 30), `BASE_URL` is assigned from `import.meta.env.VITE_SITE_URL || 'https://www.codayweb.de'`. Then, `canonicalUrl` is constructed via `${BASE_URL}${canonicalPath}` (line 73).

## 2. Logic Chain
- Moving SEO utilities to `src/shared/seo` and fixing imports successfully conforms to the interface contracts and decoupled structure requested.
- However, rendering `JSON.stringify(jsonLd)` as a direct child of a `<script>` element is a known Cross-Site Scripting (XSS) vulnerability. If any of the user-provided or dynamic schema data (e.g. `article.headline`, `job.description`, or even URL segments) contains the string `</script>`, it will prematurely close the script tag and allow execution of injected scripts. React does not auto-escape `</script>` tags within string children of script elements.
- For `BASE_URL`, if a user provides an environment variable with a trailing slash (e.g., `VITE_SITE_URL="https://example.com/"`), the resulting `canonicalUrl` would contain double slashes (e.g., `https://example.com//about`), which is harmful for SEO. It lacks trailing slash normalization.

## 3. Caveats
- The build task (`npm run build`) fails, but this is caused by `vite-plugin-image-optimizer` failing to open `build/client/apple-touch-icon.png`, an unrelated plugin configuration issue that existed prior to this refactor. The SEO refactor itself passes all tests (`npm run test`).
- The XSS vector depends on whether any `SchemaData` values or route parameters are sourced from untrusted user input (e.g. a blog CMS). Even if fully static today, the component is fundamentally unsafe.

## 4. Conclusion
While the module boundary refactor is correct, the implementation introduces a critical XSS vulnerability and a minor robustness issue regarding URL generation. I am issuing a REQUEST_CHANGES to the implementer to safely serialize the JSON-LD script and sanitize the `BASE_URL` environment variable.

## 5. Verification Method
1. Run `npm run test` (passes for SEO files).
2. Manually inspect `src/shared/seo/JsonLd.tsx` at line 709 for the `dangerouslySetInnerHTML` implementation (or string replacement of `<` with `\u003c` or `&lt;`).
3. Check `src/shared/seo/SeoHead.tsx` at line 30 for trailing slash trimming of `BASE_URL`.
